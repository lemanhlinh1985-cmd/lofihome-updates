using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

[assembly: AssemblyTitle("LOFIHOME JDPaint")]
[assembly: AssemblyDescription("JDPaint DXF companion using the original LOFIHOME licence and geometry runtime")]
[assembly: AssemblyCompany("LOFIHOME")]
[assembly: AssemblyProduct("LOFIHOME JDPaint")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.2.0")]

namespace LofiHome.Jdp
{
    internal static class Program
    {
        // Pin the inspected 1.0.26 runtime. A Corel updater must not silently
        // replace an internal reflection contract used by this integration.
        private const string HostSha256 = "b51a71f7db2815106bf853c68ec9ee0898672d0c9dae202fbe62225c219084cc";
        private const string WindowTitle = "LOFIHOME • JDPaint 0.1.2";
        private const int MaxRequestCharacters = 64 * 1024 * 1024;
        private const int MaxContentCharacters = 48 * 1024 * 1024;
        private const BindingFlags InstanceMembers = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        private static readonly JavaScriptSerializer Json = new JavaScriptSerializer
        {
            MaxJsonLength = MaxRequestCharacters,
            RecursionLimit = 100
        };

        // These existing actions do not initialize the Corel COM bridge.
        // Export is handled separately, with the ORIGINAL licence Demand().
        private static readonly HashSet<string> ForwardActions = new HashSet<string>(StringComparer.Ordinal)
        {
            "ready", "panel_ready", "source_layout_load", "source_layout_save",
            "license_state", "license_activate", "fit_window",
            "panel_export_config", "panel_import_config", "save_preset",
            "delete_preset", "export_presets", "import_presets", "zalo"
        };

        private static readonly HashSet<string> ExportExtensions = new HashSet<string>(StringComparer.Ordinal)
        {
            "dxf", "svg", "json"
        };

        private static Form host;
        private static WebView2 view;
        private static Type hostType;
        private static Type licenseType;
        private static MethodInfo originalStart;
        private static MethodInfo originalMessage;
        private static MethodInfo originalReply;
        private static MethodInfo originalSavePath;
        private static MethodInfo licenseDemand;
        private static FieldInfo licenseField;
        private static FieldInfo busyField;

        [STAThread]
        private static void Main()
        {
            try
            {
                bool ownsMutex;
                // Match the original panel's mutex and shared profile policy.
                using (var mutex = new Mutex(true, "Local\\LOFIHOME_Corel_" + Environment.UserName, out ownsMutex))
                {
                    if (!ownsMutex)
                    {
                        MessageBox.Show(
                            "Một bảng LOFIHOME đang mở. Hãy đóng bảng đó rồi mở lại LOFIHOME JDPaint.",
                            WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    try
                    {
                        Application.EnableVisualStyles();
                        Application.SetCompatibleTextRenderingDefault(false);
                        InitializeHost();
                        Application.Run(host);
                    }
                    finally
                    {
                        mutex.ReleaseMutex();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Unwrap(ex).Message, WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void InitializeHost()
        {
            string root = AppDomain.CurrentDomain.BaseDirectory;
            string runtimePath = Path.Combine(root, "LOFIHOME.Corel.exe");
            if (!File.Exists(runtimePath))
                throw new InvalidOperationException("Thiếu bộ chạy LOFIHOME.Corel.exe. Hãy giải nén toàn bộ gói JDPaint trước khi mở.");

            string hash;
            using (var input = File.OpenRead(runtimePath))
            using (var sha = SHA256.Create())
                hash = BitConverter.ToString(sha.ComputeHash(input)).Replace("-", "").ToLowerInvariant();
            if (!String.Equals(hash, HostSha256, StringComparison.Ordinal))
                throw new InvalidOperationException("Bộ chạy LOFIHOME không đúng phiên bản của gói JDPaint này. Hãy dùng lại toàn bộ gói đã cung cấp; không chép bộ cập nhật Corel vào đây.");

            InitializeWebViewRuntime(root);

            var assembly = Assembly.LoadFrom(runtimePath);
            hostType = assembly.GetType("Host", true);
            licenseType = assembly.GetType("LofiLicense", true);
            originalStart = RequireMethod(hostType, "Start", Type.EmptyTypes);
            originalMessage = RequireMethod(hostType, "Message", new[] { typeof(object), typeof(CoreWebView2WebMessageReceivedEventArgs) });
            originalReply = RequireMethod(hostType, "Reply", new[] { typeof(object) });
            originalSavePath = RequireMethod(hostType, "SavePath", new[] { typeof(string), typeof(string) });
            licenseDemand = RequireMethod(licenseType, "Demand", Type.EmptyTypes);
            licenseField = RequireField(hostType, "license");
            busyField = RequireField(hostType, "busy");

            host = (Form)Activator.CreateInstance(hostType, InstanceMembers, null, new object[] { 0 }, null);
            host.Text = WindowTitle;
            host.Enabled = false;
            view = (WebView2)RequireField(hostType, "view").GetValue(host);

            // The original Shown handler only invokes Start(). Replace that
            // handler so interception is installed before the user can export.
            MethodInfo originalShown = RequireMethod(hostType, "<.ctor>b__0", new[] { typeof(object), typeof(EventArgs) });
            var shownDelegate = (EventHandler)Delegate.CreateDelegate(typeof(EventHandler), host, originalShown);
            host.Shown -= shownDelegate;
            host.Shown += StartHost;
        }

        private static void InitializeWebViewRuntime(string root)
        {
            // The supplied runtime stores native loaders in x86/x64 rather
            // than the SDK's default runtimes/win-*/native directories.
            // Select the loader for this process before ANY environment API.
            string architecture = Environment.Is64BitProcess ? "x64" : "x86";
            string loaderFolder = Path.GetFullPath(Path.Combine(root, architecture));
            string loaderPath = Path.Combine(loaderFolder, "WebView2Loader.dll");
            if (!File.Exists(loaderPath))
                throw new InvalidOperationException(
                    "Thiếu thư viện trong bộ cài: " + loaderPath + "\n\n"
                    + "Hãy giải nén toàn bộ gói LOFIHOME JDPaint, rồi mở MO_LOFIHOME_JDP.cmd.");

            try
            {
                CoreWebView2Environment.SetLoaderDllFolderPath(loaderFolder);
                string runtimeVersion = CoreWebView2Environment.GetAvailableBrowserVersionString(null);
                if (String.IsNullOrWhiteSpace(runtimeVersion))
                    throw new InvalidOperationException(
                        "Không tìm thấy Microsoft Edge WebView2 Runtime. Cài bản Evergreen Runtime từ Microsoft rồi mở lại LOFIHOME.");
            }
            catch (WebView2RuntimeNotFoundException ex)
            {
                throw new InvalidOperationException(
                    "Không tìm thấy Microsoft Edge WebView2 Runtime trên máy. "
                    + "Cài bản Evergreen Runtime từ Microsoft rồi mở lại LOFIHOME.", ex);
            }
            catch (DllNotFoundException ex)
            {
                throw new InvalidOperationException(
                    "Không nạp được thư viện giao diện: " + loaderPath + "\n\n"
                    + "Hãy giải nén toàn bộ gói đã sửa. Nếu vẫn lỗi, gửi ảnh nguyên thông báo này.\n\n"
                    + ex.Message, ex);
            }
            catch (BadImageFormatException ex)
            {
                throw new InvalidOperationException(
                    "Thư viện giao diện không đúng kiến trúc " + architecture + " hoặc đã bị hỏng. "
                    + "Hãy giải nén lại toàn bộ gói đã sửa.\n\n" + loaderPath, ex);
            }
        }

        private static async void StartHost(object sender, EventArgs args)
        {
            try
            {
                await InvokeTask(originalStart, host);
                if (view.CoreWebView2 == null)
                    throw new InvalidOperationException("Không khởi tạo được giao diện. Máy cần Microsoft Edge WebView2 Runtime và .NET Framework 4.6.2 trở lên.");

                var handler = (EventHandler<CoreWebView2WebMessageReceivedEventArgs>)Delegate.CreateDelegate(
                    typeof(EventHandler<CoreWebView2WebMessageReceivedEventArgs>), host, originalMessage);
                view.CoreWebView2.WebMessageReceived -= handler;
                view.CoreWebView2.WebMessageReceived += ReceiveMessage;
                host.Enabled = true;
                host.Activate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(host, Unwrap(ex).Message, WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                host.Close();
            }
        }

        private static async void ReceiveMessage(object sender, CoreWebView2WebMessageReceivedEventArgs args)
        {
            if (!IsTrustedOrigin(args.Source))
                return;

            string replyId = "";
            try
            {
                string raw = args.WebMessageAsJson;
                // reply_id is the final field generated by corel_adapter.js.
                // Recover only the bounded callback identifier for an oversize
                // message, so its promise can fail instead of hanging forever.
                replyId = ReadCallbackFromTail(raw);
                if (raw.Length > MaxRequestCharacters)
                    throw new InvalidOperationException("Bản vẽ quá lớn cho một lần xuất. Hãy giảm số mẫu hoặc xuất từng phần.");

                var message = Json.DeserializeObject(raw) as Dictionary<string, object>;
                if (message == null)
                    throw new InvalidOperationException("Yêu cầu không hợp lệ.");
                replyId = ReadString(message, "reply_id", "");
                if (replyId.Length > 160)
                    throw new InvalidOperationException("Mã phản hồi không hợp lệ.");
                string action = ReadString(message, "action", "");

                if (action == "export" || action == "panel_item_dxf")
                {
                    object payloadValue;
                    var payload = message.TryGetValue("payload", out payloadValue)
                        ? payloadValue as Dictionary<string, object> : null;
                    if (payload == null)
                        throw new InvalidOperationException("Thiếu dữ liệu xuất bản vẽ.");
                    await ExportFile(action, payload, replyId);
                    return;
                }

                if (!ForwardActions.Contains(action))
                    throw new InvalidOperationException("Lệnh này cần kết nối CorelDRAW và không dùng trong bộ JDPaint. Hãy xuất DXF rồi nhập bản vẽ vào JDPaint.");

                // Existing settings, presets, activation and licence-state
                // handling execute in the unchanged original host.
                originalMessage.Invoke(host, new object[] { sender, args });
            }
            catch (Exception ex)
            {
                await ReportFailure(replyId, Unwrap(ex).Message);
            }
        }

        private static async Task ExportFile(string action, Dictionary<string, object> payload, string replyId)
        {
            if ((bool)busyField.GetValue(host))
                throw new InvalidOperationException("Đang thực hiện lệnh trước, vui lòng chờ.");

            string extension = action == "panel_item_dxf" ? "dxf" : ReadString(payload, "format", "");
            if (!ExportExtensions.Contains(extension))
                throw new InvalidOperationException("Định dạng xuất không hỗ trợ. Chọn DXF, SVG hoặc JSON.");
            string content = ReadString(payload, "content", "");
            if (content.Length == 0)
                throw new InvalidOperationException("Không có dữ liệu để xuất.");
            if (content.Length > MaxContentCharacters)
                throw new InvalidOperationException("Bản vẽ quá lớn. Hãy xuất từng phần nhỏ hơn.");
            string name = ReadString(payload, "name", "LOFIHOME_JDP");
            if (name.Length > 200)
                name = name.Substring(0, 200);
            name = Path.GetFileName(name);
            if (String.IsNullOrWhiteSpace(name))
                name = "LOFIHOME_JDP";

            string path;
            busyField.SetValue(host, true);
            try
            {
                // No licence or trial logic is duplicated or changed. The
                // exact original LofiLicense.Demand() must succeed first.
                object license = licenseField.GetValue(host);
                if (license == null)
                {
                    license = Activator.CreateInstance(licenseType, InstanceMembers, null,
                        new object[] { AppDomain.CurrentDomain.BaseDirectory }, null);
                    licenseField.SetValue(host, license);
                }
                licenseDemand.Invoke(license, null);

                // Keep the original save dialog. Unlike original Export(),
                // using SavePath explicitly distinguishes cancel from success.
                path = (string)originalSavePath.Invoke(host, new object[] { extension, name });
                if (!String.IsNullOrEmpty(path))
                    File.WriteAllText(path, content, new UTF8Encoding(false));
            }
            finally
            {
                busyField.SetValue(host, false);
            }

            // Release busy before any JS completion can trigger another action.
            if (String.IsNullOrEmpty(path))
            {
                await Reply(new Dictionary<string, object>
                {
                    { "type", "jdp_export_result" }, { "ok", false },
                    { "cancelled", true }, { "format", extension },
                    { "reply_id", replyId }, { "message", "Đã hủy lưu tệp." }
                });
                await Reply(new Dictionary<string, object>
                {
                    { "type", "message" }, { "message", "Đã hủy lưu tệp." }
                });
                await Complete(replyId, false, "Đã hủy lưu tệp.");
                return;
            }

            await Reply(new Dictionary<string, object>
            {
                { "type", "jdp_export_result" }, { "ok", true },
                { "cancelled", false }, { "format", extension },
                { "reply_id", replyId }, { "path", path },
                { "message", "Đã lưu " + path }
            });
            await Reply(new Dictionary<string, object>
            {
                { "type", "message" }, { "message", "Đã lưu " + path }
            });
            await Complete(replyId, true, "");
        }

        private static bool IsTrustedOrigin(string source)
        {
            Uri uri;
            return Uri.TryCreate(source, UriKind.Absolute, out uri)
                && String.Equals(uri.Scheme, "https", StringComparison.OrdinalIgnoreCase)
                && String.Equals(uri.Host, "lofihome.local", StringComparison.OrdinalIgnoreCase)
                && uri.IsDefaultPort
                && String.Equals(uri.AbsolutePath, "/html/cnc/index.html", StringComparison.OrdinalIgnoreCase);
        }

        private static string ReadCallbackFromTail(string raw)
        {
            if (String.IsNullOrEmpty(raw))
                return "";
            string tail = raw.Substring(Math.Max(0, raw.Length - 2048));
            Match match = Regex.Match(tail, "\"reply_id\"\\s*:\\s*\"(?<id>corel-[a-z0-9]+-[0-9]+)\"\\s*}\\s*$", RegexOptions.CultureInvariant);
            return match.Success ? match.Groups["id"].Value : "";
        }

        private static string ReadString(Dictionary<string, object> values, string key, string fallback)
        {
            object value;
            if (!values.TryGetValue(key, out value) || value == null)
                return fallback;
            if (!(value is string))
                throw new InvalidOperationException("Giá trị " + key + " không hợp lệ.");
            return (string)value;
        }

        private static async Task ReportFailure(string replyId, string message)
        {
            try
            {
                if (!String.IsNullOrEmpty(replyId))
                    await Complete(replyId, false, message);
                else
                    await Reply(new Dictionary<string, object> { { "type", "error" }, { "message", message } });
            }
            catch
            {
                // The window may have been closed while awaiting WebView2.
            }
        }

        private static Task Reply(object value)
        {
            return InvokeTask(originalReply, host, value);
        }

        private static Task Complete(string replyId, bool ok, string message)
        {
            if (String.IsNullOrEmpty(replyId) || view.CoreWebView2 == null || host.IsDisposed)
                return Task.FromResult(0);
            string script = "if(window.corelDone)window.corelDone(" + Json.Serialize(replyId) + ","
                + (ok ? "true" : "false") + "," + Json.Serialize(message ?? "") + ");";
            return view.CoreWebView2.ExecuteScriptAsync(script);
        }

        private static Task InvokeTask(MethodInfo method, object target, params object[] arguments)
        {
            return (Task)method.Invoke(target, arguments);
        }

        private static MethodInfo RequireMethod(Type type, string name, Type[] arguments)
        {
            MethodInfo result = type.GetMethod(name, InstanceMembers, null, arguments, null);
            if (result == null)
                throw new InvalidOperationException("Bộ chạy không tương thích: thiếu " + type.Name + "." + name + ".");
            return result;
        }

        private static FieldInfo RequireField(Type type, string name)
        {
            FieldInfo result = type.GetField(name, InstanceMembers);
            if (result == null)
                throw new InvalidOperationException("Bộ chạy không tương thích: thiếu " + type.Name + "." + name + ".");
            return result;
        }

        private static Exception Unwrap(Exception error)
        {
            while (error is TargetInvocationException && error.InnerException != null)
                error = error.InnerException;
            return error;
        }
    }
}
