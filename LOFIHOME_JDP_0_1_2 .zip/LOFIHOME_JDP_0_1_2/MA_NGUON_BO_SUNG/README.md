# LOFIHOME JDP Windows wrapper

This launcher is an integration layer for the version-pinned LOFIHOME Corel 1.0.26 runtime supplied in the project. The original EXE, DLLs, public licence key, activation code, machine identification, trial bookkeeping and licence verification remain unchanged.

## Why the wrapper exists

The original host can open its WebView2 interface without CorelDRAW, but its message dispatcher eagerly connects to CorelDRAW before processing `export` and `panel_item_dxf`. The generic save operation itself does not use CorelDRAW. This wrapper substitutes only those two dispatch paths:

1. Call the original `LofiLicense.Demand()`.
2. Call the original `Host.SavePath()` dialog.
3. If cancelled, report cancellation without claiming that a file was saved.
4. Otherwise write the requested DXF/SVG/JSON with UTF-8 without BOM and report the saved path.

The existing activation/settings/preset actions are forwarded to the original host. Corel drawing and MAP actions are rejected in this companion. The allowed WebView origin is restricted to `https://lofihome.local/html/cnc/index.html`.

## Runtime

Place `LOFIHOME.JDP.exe` beside the original `LOFIHOME.Corel.exe`, its DLLs and `license_public.xml`. Preserve the original `x86` and `x64` WebView2 loader directories. Launch the JDP EXE, not the HTML file in an external browser.

The original host is pinned by SHA-256:

`b51a71f7db2815106bf853c68ec9ee0898672d0c9dae202fbe62225c219084cc`

Windows requires .NET Framework 4.6.2 or newer and Microsoft Edge WebView2 Runtime. The wrapper targets `net462`, AnyCPU with Prefer32Bit disabled. It requests no administrator privilege.

The original per-user mutex is preserved, so an existing LOFIHOME Corel panel must be closed before the JDP companion opens. Settings, presets, WebView2 profile, licence state and trial state retain the original locations. The wrapper does not delete or reset any of them.

## Build

Build with the .NET SDK and the official Microsoft.NETFramework.ReferenceAssemblies.net462 package. Point `LofiRuntimeDirectory` at the original runtime DLL directory if it is not at the default local analysis path:

```sh
dotnet build LOFIHOME.JDP.csproj -c Release -p:LofiRuntimeDirectory=/absolute/path/to/original/runtime
```

No original program is executed by the build. The output is in `bin/Release/net462/`.

## UI completion contract

The existing `window.corelDone(id, ok, message)` callback is preserved. A successful export acknowledges the request with `ok: true`. Cancellation acknowledges with `ok: false` and `Đã hủy lưu tệp.`, so the existing promise rejects and cannot trigger a saved-file success path.

Before acknowledgment the wrapper sends `lofiCNCReply` with `type: "jdp_export_result"`. This result includes `ok`, `cancelled`, `format`, `reply_id` and, on successful write, `path`. Success notifications must be based on this explicit result. A cancellation also emits the message `Đã hủy lưu tệp.`

Incoming messages are limited to 64 Mi characters and export content to 48 Mi characters. Only `dxf`, `svg` and `json` are accepted. Errors and licence refusal reject the existing request callback.

## Verification limits

The integration is derived from static inspection of the original .NET methods and is compiled for Windows. A native smoke test still needs a Windows machine with WebView2 and the original valid licence/trial state. A real JDPaint import test is separate from DXF structure validation.


## Startup correction (0.1.2)

The package contains authentic native loaders in `app/x64` and `app/x86`. Before any environment API or host construction, the companion selects the matching folder with `CoreWebView2Environment.SetLoaderDllFolderPath` using the process bitness. A `GetAvailableBrowserVersionString` preflight distinguishes a loader failure from a missing Evergreen Runtime. The wrapper window displays version 0.1.2. No original runtime or licensing binaries are modified.

Reference: https://learn.microsoft.com/en-us/dotnet/api/microsoft.web.webview2.core.corewebview2environment.setloaderdllfolderpath
