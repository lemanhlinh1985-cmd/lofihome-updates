(function () {
  'use strict';
  const bridge = window.sketchup.cnc_action;
  const host = window.CorelHost;
  let busy = false;

  function reply(type, message, extra) {
    if (window.lofiCNCReply) window.lofiCNCReply(Object.assign({type, message}, extra || {}));
  }
  function finishPanel(action, p, ok, message) {
    reply('panel_operation_done', message, {action, request_id:p.request_id, ok});
    label('panelCreate', 'Xuất vách cho JDPaint');
  }
  function label(id, text) { const e=document.getElementById(id); if(e)e.textContent=text; }
  function hide(id) { const e=document.getElementById(id); if(e)e.style.setProperty('display','none','important'); }
  function r12(text) { return window.LofiJdpDxf.toR12(text); }
  async function save(format, content, name) {
    if (format==='dxf') content=r12(content);
    // Every generated file goes through the Windows host and the original
    // LOFIHOME licence check. There is deliberately no browser-download fallback.
    await host.send('export', {format, content, name:name || 'LOFIHOME_JDP'});
  }
  function drawing(p) {
    const packet=host.packet(p);
    return window.LofiCNCPanel.dxf({contours:packet.contours, config:packet.config,
      width:packet.width, height:packet.height});
  }
  async function source(p, format) {
    const built=await host.sourcePacket(p);
    if(format==='json') return save('json',JSON.stringify(p,null,2),built.name);
    if(format!=='dxf' && format!=='svg') throw Error('Bản JDP xuất đường nét DXF hoặc SVG.');
    return save(format,window.LofiCNCPanel[format](built),built.name);
  }
  function pickDxf() {
    return new Promise((resolve,reject)=>{
      const input=document.createElement('input'); input.type='file'; input.accept='.dxf';
      input.style.display='none'; document.body.appendChild(input);
      const clean=()=>input.remove();
      input.addEventListener('cancel',()=>{clean();resolve(null);},{once:true});
      input.addEventListener('change',async()=>{
        const file=input.files && input.files[0];
        if(!file){clean();resolve(null);return;}
        try {
          if(file.size>50*1024*1024)throw Error('Đường bao DXF cần nhỏ hơn 50 MB.');
          const text=await file.text(); clean(); resolve({text,name:file.name});
        } catch(e) { clean();reject(e); }
      },{once:true});
      input.click();
    });
  }
  async function capture(action) {
    const file=await pickDxf(); if(!file)return;
    const parsed=window.LofiJdpDxf.closedLoops(file.text,0.05);
    const G=window.LofiCNCGeometry;
    const loops=parsed.loops.slice().sort((a,b)=>Math.abs(G.area(b))-Math.abs(G.area(a)));
    if(!loops.length)throw Error('DXF không có đường bao khép kín.');
    const outer=loops[0], holes=loops.slice(1);
    if(holes.some(h=>!G.fits(h,outer,0.001)))
      throw Error('Chọn một đường bao ngoài cùng các lỗ bên trong. Tách các vùng rời thành tệp DXF riêng.');
    if(action==='capture_face' && holes.length)
      throw Error('Đường bao có lỗ: hãy dùng Nhập đường bao DXF trong phần Thiết kế vách của thư viện 304 mẫu.');
    const box=G.bounds(outer),width=box.x1-box.x0,height=box.y1-box.y0;
    if(!(width>0 && height>0))throw Error('Đường bao cần có chiều rộng và chiều cao lớn hơn 0.');
    const shift=l=>l.map(p=>[p[0]-box.x0,p[1]-box.y0]);
    reply(action==='panel_capture_face'?'panel_outline':'outline',
      'Đã nhập đường bao '+file.name+' · '+width.toFixed(2)+' × '+height.toFixed(2)+' mm; đưa về gốc tọa độ.'+
      (parsed.warnings && parsed.warnings.length ? ' '+parsed.warnings.join(' ') : ''),
      {points:shift(outer),holes:holes.map(shift),width,height,source:file.name});
  }
  const blocked=new Set(['corel_create','corel_update','corel_export_vectors','corel_save',
    'load_selected','source_load_selected','panel_load_selected','source_native_insert',
    'panel_place_insert','panel_place_commit','panel_place_failed','panel_item_skp',
    'panel_export_skp','export_skp','map_apply','map_read','split_plate','line_cleanup']);

  window.sketchup.cnc_action=function (json) {
    let data;
    try { data=JSON.parse(json); } catch(e){reply('error','Không đọc được lệnh thiết kế.');return;}
    const action=data.action,p=data.payload || {};
    if(blocked.has(action)) {
      reply('error','Chức năng chọn đối tượng trong Corel không dùng trong bản JDP. Hãy lưu thông số hoặc xuất DXF để nhập vào JDPaint.');return;
    }
    const handled=['export','panel_item_dxf','source_export','source_insert','source_update',
      'create','update','panel_create','panel_update','panel_item_create','capture_face','panel_capture_face'];
    if(handled.indexOf(action)<0){bridge(json);return;}
    if(busy){
      const message='Hoàn tất hộp thoại đang mở trước khi thực hiện lệnh tiếp theo.';
      if(action==='panel_create'||action==='panel_update')finishPanel(action,p,false,message);
      else reply('error',message);
      return;
    }
    busy=true;
    Promise.resolve().then(async()=>{
      if(action==='capture_face'||action==='panel_capture_face')return capture(action);
      if(action==='export')return save(p.format,p.content,p.name);
      if(action==='panel_item_dxf')return save('dxf',p.content,p.name);
      if(action==='source_export')return source(p,p.format);
      if(action==='source_insert'||action==='source_update')return source(p,'dxf');
      if(action==='panel_create'||action==='panel_update'){
        try {
          await save('dxf',drawing(p),p.name||(p.config&&p.config.name));
          finishPanel(action,p,true,'Đã lưu DXF. Trong JDPaint, chọn File → Import → 2D Drawing.');
        }catch(e){finishPanel(action,p,false,e.message);}
        return;
      }
      return save('dxf',drawing(p),p.name||(p.config&&p.config.name));
    }).catch(e=>reply('error',e.message)).finally(()=>{busy=false;});
  };

  document.addEventListener('DOMContentLoaded',()=>{
    document.title='LOFIHOME · JDPaint';
    const header=document.querySelector('header');
    const build=header.querySelector('.build');
    if(build)build.textContent='JDPaint · DXF R12 · v0.1';
    const sub=header.querySelector('small');
    if(sub)sub.textContent='Tạo mẫu → Xuất DXF (mm) → Nhập vào JDPaint';
    ['corelMaps','corelUpdate','corelCheckUpdates','splitPlate','lineCleanup','update','loadSelected','exportSkp',
      'originalUpdate','originalLoad','originalSkp','originalNative','panelUpdate','panelExportSkp',
      'insertExportSkp','borderExportNative','insertPlace','panelCaptureRegions','insertWallCleanup']
      .forEach(hide);
    label('create','Xuất thiết kế cho JDPaint');
    label('panelCreate','Xuất vách cho JDPaint');
    label('originalInsert','Xuất mẫu cho JDPaint');
    label('originalDxf','DXF R12 cho JDPaint');
    label('panelDxf','DXF R12 cho JDPaint');
    label('exportDxf','DXF R12 cho JDPaint');
    label('captureFace','Nhập đường bao DXF');
    label('panelCapture','Nhập đường bao DXF');
    label('insertExportDxf','Xuất họa tiết DXF R12');
    label('borderExportDxf','Xuất diềm DXF R12');
    label('panelCreateItems','Xuất họa tiết riêng DXF');
    label('panelLoad','Mở thông số đã lưu');
    const panelLoad=document.getElementById('panelLoad');
    if(panelLoad)panelLoad.onclick=()=>bridge(JSON.stringify({action:'panel_import_config',payload:{}}));
    document.querySelectorAll('select[data-key="plane"],select[data-original="plane"],select[data-panel="plane"]')
      .forEach(e=>{const l=e.closest('label');if(l)l.style.display='none';});
    document.querySelectorAll('[data-panel="custom_place"],[data-key="custom_place"]')
      .forEach(e=>{const l=e.closest('label');if(l)l.style.display='none';});
    const originalNote=document.querySelector('#originalLibrary .original-editor > .original-note');
    if(originalNote)originalNote.textContent='DXF xuất đường biên 2D theo kích thước hiện tại (mm). Thiết lập dao, độ sâu và đường chạy dao trong JDPaint.';
    const exportNote=document.getElementById('exportDxf');
    if(exportNote && exportNote.parentElement.nextElementSibling)
      exportNote.parentElement.nextElementSibling.textContent='DXF R12 có lớp OUTLINE, HOLE và RELIEF. Các tọa độ dùng mm; RELIEF là đường biên 2D, không phải khối nổi 3D.';
    const help=document.createElement('button');help.id='jdpHelp';help.textContent='Cách đưa sang JDP';header.appendChild(help);
    const modal=document.createElement('dialog');modal.id='jdpHelpDialog';
    modal.innerHTML='<form method="dialog"><button class="jdp-close" aria-label="Đóng hướng dẫn">×</button></form>'+
      '<p class="jdp-eyebrow">LOFIHOME → JDPAINT</p><h2>Từ mẫu thiết kế đến bản vẽ JDP</h2>'+
      '<ol><li>Chọn mẫu, nhập kích thước bằng <strong>mm</strong> và kiểm tra hình xem trước.</li>'+
      '<li>Bấm <strong>Xuất cho JDPaint</strong> hoặc <strong>DXF R12 cho JDPaint</strong>, rồi chọn nơi lưu.</li>'+
      '<li>Trong JDPaint, chọn <strong>File → Import → 2D Drawing</strong>, chọn loại <strong>DXF</strong> và mở tệp vừa lưu.</li>'+
      '<li>Kiểm tra kích thước. Tệp <strong>KIEM_TRA_100x100.dxf</strong> đi kèm có khung 100 × 100 mm để thử tỷ lệ.</li>'+
      '<li>Lưu bản vẽ thành <strong>.jdp</strong> trong JDPaint; thiết lập dao và đường chạy dao tại đó.</li></ol>'+
      '<h3>Lưu để sửa tiếp</h3><p>Dùng <strong>Lưu thông số</strong>/<strong>Xuất thông số</strong> trong LOFIHOME. Tệp DXF giữ đường nét; tệp JSON giữ thông số thiết kế.</p>'+
      '<h3>Nhập đường bao tự vẽ</h3><p>Lưu một đường bao ngoài và các lỗ bên trong thành DXF, rồi bấm <strong>Nhập đường bao DXF</strong>. Tọa độ được đọc theo mm và đưa về gốc; hỗ trợ polyline kín. Các vùng rời cần tách thành tệp riêng.</p>'+
      '<h3>Phạm vi bản 0.1</h3><p>Đây là cửa sổ thiết kế và xuất DXF, cần thao tác nhập trong JDPaint. Không đọc đối tượng đang chọn trong JDP, không tạo tệp JDP trực tiếp và không xuất đường chạy dao.</p>'+
      '<p>Khóa và thời hạn dùng thử LOFIHOME được giữ nguyên. Đóng cửa sổ LOFIHOME Corel trước khi mở bản này. Chức năng MAP/vật liệu của Corel không nằm trong gói vector JDP.</p>'+
      '<p class="jdp-test-note">Bản phát hành đầu tiên: đã kiểm tra cấu trúc DXF và luồng giao diện; cần thử nhập trên JDPaint của bạn.</p>';
    document.body.appendChild(modal);help.onclick=()=>modal.showModal();
    const notice=document.createElement('div');notice.id='jdpWorkflow';
    notice.innerHTML='<strong>JDPAINT</strong><span>1. Tạo mẫu</span><span>2. Xuất DXF R12</span><span>3. Nhập 2D Drawing</span><small>Đơn vị: mm · Đường nét 2D</small>';
    header.after(notice);
    window.LofiJdpAdapter={version:'0.1',format:'DXF R12',unit:'mm'};
  });
})();
