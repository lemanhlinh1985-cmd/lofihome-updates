"""Independent R12 validation; run after node test_jdp_dxf.cjs."""
import json
import math
from pathlib import Path
import ezdxf

root = Path(__file__).parent / 'fixtures'
for fixture in json.loads((root / 'index.json').read_text()):
    doc = ezdxf.readfile(root / (fixture['name'] + '.dxf'))
    assert doc.dxfversion == 'AC1009', doc.dxfversion
    audit = doc.audit()
    assert not audit.errors, audit.errors
    assert not audit.fixes, audit.fixes
    entities = list(doc.modelspace())
    assert len(entities) == len(fixture['expected'])
    for entity, expected in zip(entities, fixture['expected']):
        assert entity.dxftype() == 'POLYLINE'
        assert entity.is_2d_polyline
        assert entity.dxf.layer == expected['layer']
        assert entity.dxf.flags == expected['flags']
        assert bool(entity.is_closed) == bool(expected['flags'] & 1)
        assert expected['layer'] in doc.layers
        assert len(entity.vertices) == len(expected['vertices'])
        for vertex, data in zip(entity.vertices, expected['vertices']):
            x, y, z = vertex.dxf.location
            assert x == data[0] and y == data[1] and z == 0, (vertex, data)
            assert vertex.dxf.get('bulge', 0) == (data[2] if len(data) > 2 else 0)
            assert all(math.isfinite(n) for n in (x, y, z))
    print('PASS independent ezdxf:', fixture['name'], 'entities=', len(entities), 'audit errors/fixes=0/0')
