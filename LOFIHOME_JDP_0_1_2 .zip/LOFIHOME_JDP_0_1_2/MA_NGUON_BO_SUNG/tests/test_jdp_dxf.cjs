'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const api = require('../jdp_dxf.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }
function lw(vertices, layer = 'OUTLINE', flags = 1, extra = []) {
  let p = [0, 'LWPOLYLINE', 100, 'AcDbEntity', 8, layer, 100, 'AcDbPolyline', 90, vertices.length, 70, flags].concat(extra);
  vertices.forEach(v => { p.push(10, v[0], 20, v[1]); if (v.length > 2) p.push(42, v[2]); });
  return p;
}
function doc(entities, unit = 4) {
  let p = [0, 'SECTION', 2, 'HEADER'];
  if (unit !== null) p.push(9, '$INSUNITS', 70, unit);
  p.push(0, 'ENDSEC', 0, 'SECTION', 2, 'ENTITIES');
  entities.forEach(e => p.push(...e));
  p.push(0, 'ENDSEC', 0, 'EOF');
  return p.join('\r\n') + '\r\n';
}
const outer = [[-50, -30], [150, -30], [150, 70], [-50, 70]];
const hole = [[-10, -10], [-10, 20], [30, 20], [30, -10]];
const circle = [[-10, 0, 1], [10, 0, 1]];
const fixtureDir = path.join(__dirname, 'fixtures');
fs.mkdirSync(fixtureDir, {recursive: true});
const fixtures = [];
function fixture(name, entities, expected) {
  const input = doc(entities), output = api.toR12(input);
  fs.writeFileSync(path.join(fixtureDir, name + '.dxf'), output, 'ascii');
  fixtures.push({name, expected});
  return {input, output};
}
test('rectangle, nested hole, negative/zero coordinates, units convention', () => {
  const {input, output} = fixture('rectangle_hole', [lw(outer), lw(hole, 'HOLE')], [
    {layer: 'OUTLINE', flags: 1, vertices: outer}, {layer: 'HOLE', flags: 1, vertices: hole}
  ]);
  assert(output.includes('\r\nAC1009\r\n'));
  assert(!output.includes('$INSUNITS'));
  assert(!output.includes('LWPOLYLINE'));
  assert(!/[^\x00-\x7f]/.test(output));
  assert.deepStrictEqual(api.closedLoops(input).loops, [outer, hole]);
  assert.deepStrictEqual(api.closedLoops(output).loops, [outer, hole]);
  assert.strictEqual(api.closedLoops(output).warnings.length, 1);
});
test('positive and negative bulges preserved in R12', () => {
  const clockwise = [[-10, 0, -1], [10, 0, -1]];
  fixture('circle_bulges', [lw(circle, 'RELIEF'), lw(clockwise, 'CUT')], [
    {layer: 'RELIEF', flags: 1, vertices: circle}, {layer: 'CUT', flags: 1, vertices: clockwise}
  ]);
  const ccw = api.closedLoops(doc([lw(circle)]), 0.05).loops[0];
  const cw = api.closedLoops(doc([lw(clockwise)]), 0.05).loops[0];
  assert(ccw[1][1] < 0 && cw[1][1] > 0);
  for (const points of [ccw, cw]) {
    for (let i = 0; i < points.length; i++) {
      const p = points[i], q = points[(i + 1) % points.length];
      assert(Math.abs(Math.hypot(...p) - 10) < 1e-10);
      const chordMidRadius = Math.hypot((p[0] + q[0]) / 2, (p[1] + q[1]) / 2);
      assert(10 - chordMidRadius <= 0.05 + 1e-12);
    }
  }
});
test('major arc bulge uses full arc rather than minor-arc shortcut', () => {
  const points = api.closedLoops(doc([lw([[0, 0, 2], [20, 0, 0], [10, 10, 0]])]), 0.05).loops[0];
  assert(Math.min(...points.map(p => p[1])) < -19.9);
});
test('open flags and PLINEGEN preserved for export, open import rejected', () => {
  const vertices = [[-1.25, 0], [0, -2.5], [3.75, 2.25]];
  const {input, output} = fixture('open_flags', [lw(vertices, 'CUT', 128)], [{layer: 'CUT', flags: 128, vertices}]);
  assert.throws(() => api.closedLoops(input), /chưa đóng/);
  assert.throws(() => api.closedLoops(output), /chưa đóng/);
});
test('R12 legacy POLYLINE input round-trips with exact values', () => {
  const original = api.toR12(doc([lw(circle)]));
  const again = api.toR12(original);
  assert.strictEqual(original, again);
  assert.deepStrictEqual(api.closedLoops(original).loops, api.closedLoops(again).loops);
});
test('explicit repeated closing endpoint handled with warning', () => {
  const input = doc([lw(outer.concat([outer[0]]))]);
  const read = api.closedLoops(input);
  assert.deepStrictEqual(read.loops, [outer]);
  assert(read.warnings.some(w => /đỉnh cuối/.test(w)));
});
test('missing/zero units warn; explicit inch/metre units rejected', () => {
  for (const units of [null, 0]) assert(api.closedLoops(doc([lw(outer)], units)).warnings.length);
  for (const units of [1, 6]) {
    assert.throws(() => api.closedLoops(doc([lw(outer)], units)), /đơn vị khác mm/);
    assert.throws(() => api.toR12(doc([lw(outer)], units)), /đơn vị khác mm/);
  }
});
test('unsupported entities never silently dropped from mixed input', () => {
  for (const entity of ['LINE', 'ARC', 'CIRCLE', 'SPLINE', 'INSERT', 'HATCH', '3DFACE']) {
    const input = doc([lw(outer), [0, entity, 8, '0', 10, 0, 20, 0]]);
    assert.throws(() => api.toR12(input), /Đối tượng chưa hỗ trợ/);
    assert.throws(() => api.closedLoops(input), /Đối tượng chưa hỗ trợ/);
  }
});
test('malformed counts, missing coordinates, zero length, nonfinite rejected', () => {
  let input = doc([lw(outer)]);
  assert.throws(() => api.toR12(input.replace('90\r\n4', '90\r\n3')), /Số đỉnh khai báo/);
  assert.throws(() => api.toR12(input.replace('90\r\n4', '90\r\n0')), /Số đỉnh.*không hợp lệ/);
  assert.throws(() => api.toR12(input.replace('20\r\n-30\r\n', '')), /thiếu tọa độ Y/);
  for (const n of ['NaN', 'Infinity', '-Infinity', '1e999']) assert.throws(() => api.toR12(input.replace('10\r\n-50', '10\r\n' + n)), /hữu hạn/);
  assert.throws(() => api.toR12(doc([lw([[0, 0], [0, 0], [0, 0]])])), /chiều dài/);
  assert.throws(() => api.closedLoops(doc([lw([[0, 0], [10, 0], [20, 0]])])), /diện tích/);
  for (const t of [0, -0.1, NaN, Infinity, '0.05']) assert.throws(() => api.closedLoops(input, t), /Sai số/);
});
test('elevation, extrusion, width and fitted geometry rejected', () => {
  for (const extra of [[38, 1], [39, 1], [43, 2], [210, 1, 220, 0, 230, 0], [67, 1]]) {
    assert.throws(() => api.toR12(doc([lw(outer, 'OUTLINE', 1, extra)])));
  }
  assert.throws(() => api.toR12(doc([lw(outer, 'OUTLINE', 8)])), /polyline 2D/);
});
test('incomplete DXF and unsafe layer names fail rather than repair', () => {
  const input = doc([lw(outer)]);
  assert.throws(() => api.toR12(input.replace(/0\r\nEOF\r\n$/, '')), /EOF/);
  assert.throws(() => api.toR12(input + '1\r\nx\r\n'), /sau EOF/);
  assert.throws(() => api.toR12(doc([lw(outer, 'LỚP')])), /Tên lớp/);
  assert.throws(() => api.toR12(doc([lw(outer, 'X'.repeat(32))])), /Tên lớp/);
  assert.throws(() => api.toR12('AutoCAD Binary DXF\0'), /nhị phân/);
});
test('tiny finite bulge below tolerance stays stable', () => {
  const vertices = outer.map(p => p.slice()); vertices[0].push(1e-310);
  assert.deepStrictEqual(api.closedLoops(doc([lw(vertices)])).loops, [outer]);
});
test('browser global is available without Node module machinery', () => {
  const context = {window: {}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../jdp_dxf.js'), 'utf8'), context);
  assert.strictEqual(typeof context.window.LofiJdpDxf.toR12, 'function');
  assert.strictEqual(context.window.LofiJdpDxf.toR12(doc([lw(outer)])), api.toR12(doc([lw(outer)])));
});
fs.writeFileSync(path.join(fixtureDir, 'index.json'), JSON.stringify(fixtures, null, 2));
console.log('Completed ' + passed + ' focused tests.');
