/*
 * LOFIHOME JDP DXF adapter, 1.0.0
 * Pure data conversion only: no filesystem, host, licence or update calls.
 *
 * toR12(text): converts supported planar LWPOLYLINE/POLYLINE geometry into
 * ASCII AutoCAD R12 POLYLINE/VERTEX records. Numeric coordinates are unchanged.
 * One drawing unit is one millimetre by convention. R12 has no $INSUNITS:
 * this writer deliberately does not pretend that adding it makes R12 metric.
 * An explicitly non-mm input $INSUNITS is rejected, never silently rescaled.
 *
 * closedLoops(text, toleranceMm): reads explicit closed XY contours and
 * approximates bulged arc segments with a maximum chord sagitta of toleranceMm.
 * It does not infer closure, loop nesting, or repair self intersections.
 * Unsupported entity types or non-planar/wide geometry fail the entire read.
 *
 * Group-code references (Autodesk DXF Reference):
 * https://help.autodesk.com/cloudhelp/2024/ENU/AutoCAD-DXF/files/GUID-748FC305-F3F2-4F74-825A-61F04D757A50.htm
 * https://help.autodesk.com/cloudhelp/2023/ENU/AutoCAD-DXF/files/GUID-ABF6B778-BE20-4B49-9B58-A94E64CEFFF3.htm
 * https://help.autodesk.com/cloudhelp/2021/ENU/AutoCAD-DXF/files/GUID-0741E831-599E-4CBF-91E1-8ADBCFD6556D.htm
 */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.LofiJdpDxf = api;
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var MAX_TEXT = 64 * 1024 * 1024, MAX_PAIRS = 2000000;
  var MAX_VERTICES = 500000, MAX_ENTITIES = 20000;
  var NUMBER = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;

  function fail(message) { throw new Error('DXF: ' + message); }
  function finite(n) { return typeof n === 'number' && isFinite(n); }
  function number(value, label) {
    var text = String(value).trim();
    if (!NUMBER.test(text)) fail(label + ' phải là số hữu hạn.');
    var n = Number(text);
    if (!finite(n)) fail(label + ' phải là số hữu hạn.');
    return n;
  }
  function integer(value, label) {
    var n = number(value, label);
    if (Math.floor(n) !== n || Math.abs(n) > 2147483647) fail(label + ' phải là số nguyên hợp lệ.');
    return n;
  }
  function hypot(x, y) {
    var scale = Math.max(Math.abs(x), Math.abs(y));
    return scale === 0 ? 0 : scale * Math.sqrt((x / scale) * (x / scale) + (y / scale) * (y / scale));
  }
  function same(a, b) { return a.x === b.x && a.y === b.y; }
  function numericText(n) {
    if (!finite(n)) fail('Tọa độ xuất không hữu hạn.');
    return n === 0 ? '0' : String(n);
  }
  function pairsFrom(text) {
    if (typeof text !== 'string' || !text.length) fail('Tệp trống hoặc không phải văn bản.');
    if (text.length > MAX_TEXT) fail('Tệp vượt giới hạn đọc 64 MB văn bản.');
    text = text.replace(/^\uFEFF/, '');
    if (text.indexOf('AutoCAD Binary DXF') === 0 || text.indexOf('\x00') !== -1) fail('Chỉ nhận DXF ASCII, không nhận DXF nhị phân.');
    var lines = text.split(/\r\n|\n|\r/), result = [], i;
    while (lines.length && /^\s*$/.test(lines[lines.length - 1])) lines.pop();
    if (lines.length % 2) fail('Thiếu một dòng mã nhóm hoặc giá trị.');
    if (lines.length / 2 > MAX_PAIRS) fail('Quá nhiều mã nhóm DXF.');
    for (i = 0; i < lines.length; i += 2) {
      var codeText = lines[i].trim();
      if (!/^\d+$/.test(codeText)) fail('Mã nhóm không hợp lệ ở dòng ' + (i + 1) + '.');
      var code = Number(codeText);
      if (code > 1071) fail('Mã nhóm vượt phạm vi hỗ trợ ở dòng ' + (i + 1) + '.');
      if (code !== 999) result.push({code: code, value: lines[i + 1].trim(), line: i + 1});
    }
    return result;
  }
  function sections(pairs) {
    var result = {entities: null, units: null}, i = 0, eof = false;
    while (i < pairs.length) {
      var p = pairs[i];
      if (p.code === 0 && p.value === 'EOF') {
        eof = true; i++;
        if (i !== pairs.length) fail('Có dữ liệu sau EOF.');
        break;
      }
      if (p.code !== 0 || p.value !== 'SECTION' || !pairs[i + 1] || pairs[i + 1].code !== 2) fail('Cấu trúc SECTION không hợp lệ.');
      var name = pairs[i + 1].value, start = i + 2, end = start;
      while (end < pairs.length && !(pairs[end].code === 0 && pairs[end].value === 'ENDSEC')) {
        if (pairs[end].code === 0 && (pairs[end].value === 'SECTION' || pairs[end].value === 'EOF')) fail('Thiếu ENDSEC.');
        end++;
      }
      if (end === pairs.length) fail('Thiếu ENDSEC.');
      if (name === 'ENTITIES') {
        if (result.entities !== null) fail('Có nhiều vùng ENTITIES.');
        result.entities = pairs.slice(start, end);
      }
      if (name === 'HEADER') {
        for (var j = start; j < end; j++) {
          if (pairs[j].code === 9 && pairs[j].value === '$INSUNITS') {
            if (result.units !== null || j + 1 >= end || pairs[j + 1].code !== 70) fail('$INSUNITS không hợp lệ hoặc bị lặp.');
            result.units = integer(pairs[j + 1].value, '$INSUNITS');
            if (result.units !== 0 && result.units !== 4) fail('Tệp khai báo đơn vị khác mm. Hãy xuất lại DXF theo mm trước khi nhập.');
          }
        }
      }
      i = end + 1;
    }
    if (!eof) fail('Thiếu dấu kết thúc EOF.');
    if (result.entities === null) fail('Không có vùng ENTITIES.');
    return result;
  }
  function records(pairs) {
    var list = [], current = null;
    for (var i = 0; i < pairs.length; i++) {
      var p = pairs[i];
      if (p.code === 0) {
        current = {type: p.value, fields: []};
        list.push(current);
      } else {
        if (!current) fail('Dữ liệu ENTITIES không bắt đầu bằng mã đối tượng.');
        current.fields.push(p);
      }
    }
    return list;
  }
  function once(fields, code, fallback, label) {
    var found = false, value = fallback;
    for (var i = 0; i < fields.length; i++) if (fields[i].code === code) {
      if (found) fail((label || ('Mã ' + code)) + ' bị lặp.');
      value = fields[i].value; found = true;
    }
    return value;
  }
  function nfield(fields, code, fallback, label) { return number(once(fields, code, fallback, label), label || ('Mã ' + code)); }
  function zero(fields, code, label) { if (nfield(fields, code, 0, label) !== 0) fail(label + ' phải bằng 0 cho biên dạng XY.'); }
  function flags(fields) {
    var value = integer(once(fields, 70, 0), 'Cờ polyline');
    if (value < 0 || (value & ~129) !== 0) fail('Chỉ hỗ trợ polyline 2D thường, không nhận mesh/spline/curve-fit.');
    return value;
  }
  function common(fields) {
    zero(fields, 39, 'Chiều dày DXF');
    zero(fields, 67, 'Paper space');
    if (nfield(fields, 210, 0, 'Pháp tuyến X') !== 0 || nfield(fields, 220, 0, 'Pháp tuyến Y') !== 0 || nfield(fields, 230, 1, 'Pháp tuyến Z') !== 1) fail('Chỉ hỗ trợ pháp tuyến (0, 0, 1).');
    var layout = once(fields, 410, 'Model');
    if (layout && layout.toUpperCase() !== 'MODEL') fail('Chỉ hỗ trợ hình học trong Model space.');
    var layer = once(fields, 8, '0');
    if (!layer) fail('Tên lớp rỗng.');
    return {layer: layer, flags: flags(fields), vertices: []};
  }
  // Metadata that does not alter the supported planar centreline geometry.
  function metadata(code) {
    return code === 5 || code === 6 || code === 8 || code === 48 || code === 60 || code === 62 || code === 67 || code === 100 || code === 102 || code === 210 || code === 220 || code === 230 || code === 330 || code === 347 || code === 370 || code === 390 || code === 410 || code === 420 || code === 430 || code === 440 || code >= 1000;
  }
  function verifyVertices(poly, budget) {
    if (poly.vertices.length < 2) fail('Polyline cần ít nhất hai đỉnh phân biệt.');
    budget.count += poly.vertices.length;
    if (budget.count > MAX_VERTICES) fail('Quá nhiều đỉnh DXF.');
    var distinct = false;
    for (var i = 0; i < poly.vertices.length; i++) {
      var p = poly.vertices[i];
      if (!finite(p.x) || !finite(p.y) || !finite(p.bulge)) fail('Tọa độ hoặc bulge không hữu hạn.');
      if (!same(p, poly.vertices[0])) distinct = true;
      if ((i + 1 < poly.vertices.length || (poly.flags & 1)) && p.bulge && same(p, poly.vertices[(i + 1) % poly.vertices.length])) fail('Cung bulge có hai đầu trùng nhau.');
    }
    if (!distinct) fail('Polyline không có chiều dài.');
  }
  function readLW(record, budget) {
    var f = record.fields, poly = common(f), count = integer(once(f, 90, '', 'Số đỉnh'), 'Số đỉnh');
    if (count < 2 || count > MAX_VERTICES) fail('Số đỉnh LWPOLYLINE không hợp lệ.');
    zero(f, 38, 'Cao độ'); zero(f, 43, 'Bề rộng polyline');
    var v = null;
    function finish() {
      if (!v) return;
      if (v.y === null) fail('Đỉnh LWPOLYLINE thiếu tọa độ Y.');
      poly.vertices.push(v);
    }
    for (var i = 0; i < f.length; i++) {
      var p = f[i], code = p.code;
      if (code === 10) {
        finish(); v = {x: number(p.value, 'Tọa độ X'), y: null, bulge: 0, hasBulge: false};
      } else if (code === 20) {
        if (!v || v.y !== null) fail('Tọa độ Y thiếu X hoặc bị lặp.');
        v.y = number(p.value, 'Tọa độ Y');
      } else if (code === 42) {
        if (!v || v.hasBulge) fail('Bulge thiếu đỉnh hoặc bị lặp.');
        v.bulge = number(p.value, 'Bulge'); v.hasBulge = true;
      } else if (code === 40 || code === 41) {
        if (!v || number(p.value, 'Bề rộng đỉnh') !== 0) fail('Không hỗ trợ polyline có bề rộng.');
      } else if (code === 91) {
        if (!v) fail('Mã định danh đỉnh thiếu tọa độ.');
        integer(p.value, 'Mã định danh đỉnh');
      } else if (code !== 70 && code !== 90 && code !== 38 && code !== 39 && code !== 43 && !metadata(code)) fail('Mã LWPOLYLINE chưa hỗ trợ: ' + code + '.');
    }
    finish();
    if (poly.vertices.length !== count) fail('Số đỉnh khai báo khác số tọa độ LWPOLYLINE.');
    verifyVertices(poly, budget);
    return poly;
  }
  function readOld(list, at, budget) {
    var f = list[at].fields, poly = common(f), i, code;
    [10, 20, 30, 40, 41, 71, 72, 73, 74, 75].forEach(function (c) { zero(f, c, 'Mã POLYLINE ' + c); });
    var follows = integer(once(f, 66, 1), 'Cờ chuỗi đỉnh');
    if (follows !== 0 && follows !== 1) fail('Cờ chuỗi đỉnh không hợp lệ.');
    for (i = 0; i < f.length; i++) {
      code = f[i].code;
      if ([10, 20, 30, 39, 40, 41, 66, 70, 71, 72, 73, 74, 75].indexOf(code) < 0 && !metadata(code)) fail('Mã POLYLINE chưa hỗ trợ: ' + code + '.');
    }
    for (i = at + 1; i < list.length && list[i].type === 'VERTEX'; i++) {
      var vf = list[i].fields;
      [30, 39, 40, 41, 70, 50, 71, 72, 73, 74].forEach(function (c) { zero(vf, c, 'Mã VERTEX ' + c); });
      var vertexLayer = once(vf, 8, poly.layer);
      if (vertexLayer !== poly.layer) fail('Lớp VERTEX khác lớp POLYLINE.');
      for (var j = 0; j < vf.length; j++) {
        code = vf[j].code;
        if ([10, 20, 30, 39, 40, 41, 42, 50, 70, 71, 72, 73, 74, 91].indexOf(code) < 0 && !metadata(code)) fail('Mã VERTEX chưa hỗ trợ: ' + code + '.');
      }
      poly.vertices.push({x: nfield(vf, 10, '', 'Tọa độ X'), y: nfield(vf, 20, '', 'Tọa độ Y'), bulge: nfield(vf, 42, 0, 'Bulge')});
    }
    if (i === list.length || list[i].type !== 'SEQEND') fail('Chuỗi POLYLINE thiếu SEQEND.');
    verifyVertices(poly, budget);
    return {poly: poly, last: i};
  }
  function parse(text) {
    var section = sections(pairsFrom(text)), list = records(section.entities), result = [], budget = {count: 0};
    for (var i = 0; i < list.length; i++) {
      if (result.length >= MAX_ENTITIES) fail('Quá nhiều đường polyline.');
      if (list[i].type === 'LWPOLYLINE') result.push(readLW(list[i], budget));
      else if (list[i].type === 'POLYLINE') {
        var old = readOld(list, i, budget); result.push(old.poly); i = old.last;
      } else fail('Đối tượng chưa hỗ trợ: ' + list[i].type + '. Hãy xuất các đường POLYLINE/LWPOLYLINE 2D.');
    }
    if (!result.length) fail('Không có đường polyline để xử lý.');
    return {polys: result, warnings: section.units === null || section.units === 0 ? ['DXF không khai báo đơn vị; tọa độ được hiểu theo quy ước 1 đơn vị = 1 mm.'] : []};
  }
  function r12Layer(name) {
    // R12 symbol names cannot represent arbitrary Unicode/extended names.
    // Reject instead of renaming or corrupting the user's layer names.
    if (!/^[A-Za-z0-9_$-]{1,31}$/.test(name)) fail('Tên lớp không tương thích ASCII R12: ' + name + '. Dùng tên tối đa 31 ký tự A-Z, 0-9, _, $, -.');
    return name;
  }
  function toR12(text) {
    var parsed = parse(text), layers = ['0'], seen = Object.create(null), out = [];
    seen['0'] = true;
    parsed.polys.forEach(function (poly) {
      r12Layer(poly.layer);
      // R12 symbol names compare without case; avoid ambiguous layer aliases.
      var key = poly.layer.toUpperCase();
      if (!seen[key]) { seen[key] = poly.layer; layers.push(poly.layer); }
      else if (seen[key] !== true && seen[key] !== poly.layer) fail('Hai tên lớp chỉ khác chữ hoa/thường.');
    });
    function put(code, value) { out.push(String(code), String(value)); }
    put(999, 'LOFIHOME JDP: 1 drawing unit = 1 mm; planar contours only.');
    put(0, 'SECTION'); put(2, 'HEADER'); put(9, '$ACADVER'); put(1, 'AC1009');
    put(9, '$LUNITS'); put(70, 2); put(9, '$LUPREC'); put(70, 4);
    put(9, '$INSBASE'); put(10, 0); put(20, 0); put(30, 0); put(0, 'ENDSEC');
    put(0, 'SECTION'); put(2, 'TABLES');
    put(0, 'TABLE'); put(2, 'LTYPE'); put(70, 1);
    put(0, 'LTYPE'); put(2, 'CONTINUOUS'); put(70, 0); put(3, 'Solid line'); put(72, 65); put(73, 0); put(40, 0); put(0, 'ENDTAB');
    put(0, 'TABLE'); put(2, 'LAYER'); put(70, layers.length);
    layers.forEach(function (name) { put(0, 'LAYER'); put(2, name); put(70, 0); put(62, 7); put(6, 'CONTINUOUS'); });
    put(0, 'ENDTAB'); put(0, 'ENDSEC');
    put(0, 'SECTION'); put(2, 'BLOCKS'); put(0, 'ENDSEC');
    put(0, 'SECTION'); put(2, 'ENTITIES');
    parsed.polys.forEach(function (poly) {
      put(0, 'POLYLINE'); put(8, poly.layer); put(66, 1); put(10, 0); put(20, 0); put(30, 0); put(70, poly.flags);
      poly.vertices.forEach(function (v) {
        put(0, 'VERTEX'); put(8, poly.layer); put(10, numericText(v.x)); put(20, numericText(v.y)); put(30, 0);
        if (v.bulge !== 0) put(42, numericText(v.bulge));
        put(70, 0);
      });
      put(0, 'SEQEND'); put(8, poly.layer);
    });
    put(0, 'ENDSEC'); put(0, 'EOF');
    return out.join('\r\n') + '\r\n';
  }
  function closedLoops(text, toleranceMm) {
    if (toleranceMm === undefined) toleranceMm = 0.05;
    if (!finite(toleranceMm) || toleranceMm <= 0) fail('Sai số nội suy phải là số dương hữu hạn theo mm.');
    var parsed = parse(text), loops = [], warnings = parsed.warnings.slice(), count = 0, curved = false, repeated = false;
    parsed.polys.forEach(function (poly) {
      if (!(poly.flags & 1)) fail('Có đường polyline chưa đóng. Hãy đóng đường bao trước khi nhập.');
      var vertices = poly.vertices.slice(), last = vertices[vertices.length - 1];
      if (same(vertices[0], last)) {
        if (last.bulge) fail('Đỉnh đóng trùng có bulge không hợp lệ.');
        vertices.pop(); repeated = true;
      }
      if (vertices.length < 2) fail('Đường bao không đủ đỉnh.');
      var points = [];
      function append(x, y) {
        if (!finite(x) || !finite(y)) fail('Nội suy cung tạo tọa độ không hữu hạn.');
        if (++count > MAX_VERTICES) fail('Nội suy vượt giới hạn đỉnh; tăng sai số hoặc chia bản vẽ.');
        points.push([x, y]);
      }
      for (var i = 0; i < vertices.length; i++) {
        var a = vertices[i], b = vertices[(i + 1) % vertices.length];
        var dx = b.x - a.x, dy = b.y - a.y, length = hypot(dx, dy);
        if (!finite(length) || length === 0) fail('Đường bao có cạnh dài bằng 0 hoặc tọa độ vượt phạm vi số.');
        append(a.x, a.y);
        if (!a.bulge) continue;
        curved = true;
        var bulge = a.bulge, angle = 4 * Math.atan(bulge), absb = Math.abs(bulge);
        // A minor arc whose chord sagitta is already within tolerance needs
        // no intermediate point. This also avoids overflow for tiny bulges.
        if (absb <= 1 && length * absb / 2 <= toleranceMm) continue;
        var radius = length * (absb + 1 / absb) / 4;
        if (!finite(radius) || radius <= 0) fail('Cung bulge có bán kính không hợp lệ.');
        // 2*acos(1-t/r) loses precision for tiny t/r; this identity is stable.
        var step = 4 * Math.asin(Math.sqrt(Math.min(1, toleranceMm / (2 * radius))));
        if (!finite(step) || step <= 0) fail('Sai số quá nhỏ để nội suy cung.');
        var segments = Math.max(1, Math.ceil(Math.abs(angle) / Math.min(Math.PI / 2, step)));
        if (segments > MAX_VERTICES - count + 1) fail('Cung cần quá nhiều đỉnh; tăng sai số nội suy.');
        var offset = (1 / bulge - bulge) / 4;
        var cx = a.x + dx / 2 - dy * offset, cy = a.y + dy / 2 + dx * offset;
        if (!finite(cx) || !finite(cy)) fail('Tâm cung vượt phạm vi số.');
        var start = Math.atan2(a.y - cy, a.x - cx);
        for (var j = 1; j < segments; j++) {
          var theta = start + angle * j / segments;
          append(cx + radius * Math.cos(theta), cy + radius * Math.sin(theta));
        }
      }
      if (points.length < 3) fail('Đường bao cần ít nhất ba điểm sau nội suy.');
      var area2 = 0, origin = points[0], xmin = origin[0], xmax = origin[0], ymin = origin[1], ymax = origin[1];
      for (var k = 0; k < points.length; k++) {
        var p = points[k], q = points[(k + 1) % points.length];
        area2 += (p[0] - origin[0]) * (q[1] - origin[1]) - (q[0] - origin[0]) * (p[1] - origin[1]);
        xmin = Math.min(xmin, p[0]); xmax = Math.max(xmax, p[0]); ymin = Math.min(ymin, p[1]); ymax = Math.max(ymax, p[1]);
      }
      if (!finite(area2) || Math.abs(area2) <= Math.max(1, (xmax - xmin) * (ymax - ymin)) * 1e-12) fail('Đường bao có diện tích bằng 0 hoặc không xác định.');
      loops.push(points);
    });
    if (curved) warnings.push('Các cung bulge đã được nội suy thành đoạn thẳng với sai số tối đa ' + toleranceMm + ' mm.');
    if (repeated) warnings.push('Đã bỏ đỉnh cuối trùng đỉnh đầu; đường bao vẫn đóng.');
    return {loops: loops, warnings: warnings};
  }
  return {version: '1.0.0', toR12: toR12, closedLoops: closedLoops};
});
