@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "LOFI_SOURCE=%~dp0"
set "LOFI_TARGET=%LOCALAPPDATA%\LOFIHOME_JDP\0.1"
if not exist "%LOFI_SOURCE%app\LOFIHOME.JDP.exe" (
  echo Hay giai nen TOAN BO tep ZIP truoc khi cai.
  pause
  exit /b 1
)
echo Dang cai LOFIHOME - JDPaint vao thu muc rieng cua ban...
if /I "%LOFI_SOURCE%"=="%LOFI_TARGET%\" goto shortcut
rem Append a dot so the quoted source does not end in a backslash.
robocopy "%LOFI_SOURCE%." "%LOFI_TARGET%" /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS /NP
set "LOFI_COPY_EXIT=%ERRORLEVEL%"
if %LOFI_COPY_EXIT% GEQ 8 (
  echo Khong sao chep duoc day du. Ma loi Robocopy: %LOFI_COPY_EXIT%.
  echo Hay chup thong bao loi phia tren de duoc ho tro.
  pause
  exit /b 1
)
:shortcut
powershell -NoLogo -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'LOFIHOME - JDPaint.lnk')); $s.TargetPath=Join-Path $env:LOFI_TARGET 'app\LOFIHOME.JDP.exe'; $s.WorkingDirectory=Join-Path $env:LOFI_TARGET 'app'; $s.IconLocation=Join-Path $env:LOFI_TARGET 'app\LOFIHOME.Corel.exe'; $s.Description='LOFIHOME - Tao mau va xuat DXF cho JDPaint'; $s.Save()"
if errorlevel 1 echo Chua tao duoc shortcut; co the mo MO_LOFIHOME_JDP.cmd truc tiep.
echo Da cai xong. Shortcut: LOFIHOME - JDPaint.
echo Dong cua so LOFIHOME Corel truoc khi mo ban JDP.
start "LOFIHOME JDPaint" "%LOFI_TARGET%\app\LOFIHOME.JDP.exe"
exit /b 0
