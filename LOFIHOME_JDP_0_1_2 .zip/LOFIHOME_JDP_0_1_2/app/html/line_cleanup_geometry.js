(function (root) {
  'use strict';
  var G=root.LofiCNCGeometry,EPS=1e-6;
  function distance(a,b) {return Math.hypot(a[0]-b[0],a[1]-b[1]);}
  function cross(a,b,c) {return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
  function onSegment(p,a,b) {
    return Math.abs(cross(a,b,p))<=EPS*distance(a,b) && p[0]>=Math.min(a[0],b[0])-EPS && p[0]<=Math.max(a[0],b[0])+EPS && p[1]>=Math.min(a[1],b[1])-EPS && p[1]<=Math.max(a[1],b[1])+EPS;
  }
  function validate(loop) {
    if (!Array.isArray(loop)||loop.length<3||loop.length>35000) throw Error('Đường viền cần từ 3 đến 35.000 điểm.');
    loop.forEach(function (p,i) {
      if (!Array.isArray(p)||p.length!==2||!p.every(function (x) {return Number.isFinite(x)&&Math.abs(x)<=10001;})) throw Error('Tọa độ đường viền không hợp lệ.');
      if (distance(p,loop[(i+1)%loop.length])<EPS) throw Error('Có cạnh quá ngắn hoặc điểm trùng. Giảm độ mịn.');
    });
    if (Math.abs(G.area(loop))<.0001) throw Error('Đường viền không có diện tích.');
    // Sweep edge bounding boxes; include touching and overlapping segments,
    // which ordinary proper-crossing tests would miss.
    var edges=loop.map(function (a,i) {
      var b=loop[(i+1)%loop.length];return {a:a,b:b,i:i,x0:Math.min(a[0],b[0]),x1:Math.max(a[0],b[0]),y0:Math.min(a[1],b[1]),y1:Math.max(a[1],b[1])};
    }).sort(function (a,b) {return a.x0-b.x0;}),active=[];
    edges.forEach(function (e) {
      active=active.filter(function (f) {return f.x1>=e.x0-EPS;});
      active.forEach(function (f) {
        if (Math.abs(e.i-f.i)===1||Math.abs(e.i-f.i)===loop.length-1||e.y1<f.y0-EPS||f.y1<e.y0-EPS) return;
        if ((cross(e.a,e.b,f.a)*cross(e.a,e.b,f.b)<0&&cross(f.a,f.b,e.a)*cross(f.a,f.b,e.b)<0)||onSegment(e.a,f.a,f.b)||onSegment(e.b,f.a,f.b)||onSegment(f.a,e.a,e.b)||onSegment(f.b,e.a,e.b)) throw Error('Đường viền tự cắt hoặc chạm nhau. Giảm góc ngưỡng làm mịn.');
      });
      active.push(e);
    });
  }
  function smooth(loop,angle,segments,keep) {
    validate(loop);
    var output=[];
    loop.forEach(function (p,i) {
      var a=loop[(i+loop.length-1)%loop.length],b=loop[(i+1)%loop.length],la=distance(a,p),lb=distance(p,b);
      var cosine=((p[0]-a[0])*(b[0]-p[0])+(p[1]-a[1])*(b[1]-p[1]))/(la*lb);
      var turn=Math.acos(Math.max(-1,Math.min(1,cosine)))*180/Math.PI;
      if ((keep && keep(p,i))||turn<.0001||turn>angle+1e-9||angle===0) {output.push(p.slice());return;}
      // Equal physical trimming distances retain tangent direction even when
      // the source has unequal segments or nonuniform instance scaling.
      var trim=Math.min(la,lb)*.25;
      var start=[p[0]+(a[0]-p[0])*trim/la,p[1]+(a[1]-p[1])*trim/la];
      var end=[p[0]+(b[0]-p[0])*trim/lb,p[1]+(b[1]-p[1])*trim/lb];
      for (var k=0;k<=segments;k++) {
        var t=k/segments,u=1-t;
        output.push([u*u*start[0]+2*u*t*p[0]+t*t*end[0],u*u*start[1]+2*u*t*p[1]+t*t*end[1]]);
      }
    });
    validate(output);return output;
  }
  function edgeDistance(p,a,b){
    var x=b[0]-a[0],y=b[1]-a[1],d=x*x+y*y,t=d?Math.max(0,Math.min(1,((p[0]-a[0])*x+(p[1]-a[1])*y)/d)):0;
    return Math.hypot(p[0]-a[0]-t*x,p[1]-a[1]-t*y);
  }
  function bounds(loop){
    return loop.reduce(function(b,p){return [Math.min(b[0],p[0]),Math.min(b[1],p[1]),Math.max(b[2],p[0]),Math.max(b[3],p[1])];},[Infinity,Infinity,-Infinity,-Infinity]);
  }
  function touches(p,edges){return edges.some(function(e){return p[0]>=e[2] && p[0]<=e[3] && p[1]>=e[4] && p[1]<=e[5] && edgeDistance(p,e[0],e[1])<.00011;});}
  function midpoint(a,b){return [(a[0]+b[0])/2,(a[1]+b[1])/2];}
  function segmentBox(p,q){return [Math.min(p[0],q[0]),Math.min(p[1],q[1]),Math.max(p[0],q[0]),Math.max(p[1],q[1])];}
  function intersectsBox(a,b,pad){return a[0]<=b[2]+pad && a[1]<=b[3]+pad && a[2]+pad>=b[0] && a[3]+pad>=b[1];}
  // Keep the established predicates and tolerances, but visit only edges whose
  // boxes can contribute. Indexes belong to this calculation, never to mutable
  // model arrays, so later edits cannot reuse stale geometry.
  function edgeIndex(loop){
    var edges=loop.map(function(a,i){var b=loop[(i+1)%loop.length];return {a:a,b:b,box:segmentBox(a,b)};});
    function node(list){
      var box=list.reduce(function(b,e){return [Math.min(b[0],e.box[0]),Math.min(b[1],e.box[1]),Math.max(b[2],e.box[2]),Math.max(b[3],e.box[3])];},[Infinity,Infinity,-Infinity,-Infinity]);
      if(list.length<=12)return {box:box,edges:list};
      var axis=box[2]-box[0]>=box[3]-box[1]?0:1;
      list.sort(function(a,b){return a.box[axis]+a.box[axis+2]-b.box[axis]-b.box[axis+2];});
      var mid=list.length>>1;return {box:box,left:node(list.slice(0,mid)),right:node(list.slice(mid))};
    }
    var tree=node(edges.slice());
    function some(box,pad,predicate){
      function visit(n){
        if(!intersectsBox(box,n.box,pad))return false;
        if(n.edges)return n.edges.some(function(e){return intersectsBox(box,e.box,pad)&&predicate(e);});
        return visit(n.left)||visit(n.right);
      }
      return visit(tree);
    }
    function inside(q){
      var hit=false;
      some([q[0],q[1],Infinity,q[1]],0,function(e){var a=e.a,b=e.b;if((a[1]>q[1])!==(b[1]>q[1]) && q[0]<(b[0]-a[0])*(q[1]-a[1])/(b[1]-a[1])+a[0])hit=!hit;return false;});
      return hit;
    }
    return {box:tree.box,edges:edges,some:some,inside:inside};
  }
  function properCross(a,b,c,d){return cross(a,b,c)*cross(a,b,d)<-1e-8 && cross(c,d,a)*cross(c,d,b)<-1e-8;}
  function fitsIndexed(hole,outer,gap){
    var tol=gap-1e-6,pad=Math.max(0,tol);
    return hole.edges.every(function(e){
      return outer.inside(e.a) && !outer.some(e.box,pad,function(f){
        return properCross(e.a,e.b,f.a,f.b) || edgeDistance(e.a,f.a,f.b)<tol || edgeDistance(f.a,e.a,e.b)<tol;
      });
    });
  }
  function separatedIndexed(a,b,gap){
    var aa=a.box,bb=b.box;
    if(aa[2]+gap<=bb[0] || bb[2]+gap<=aa[0] || aa[3]+gap<=bb[1] || bb[3]+gap<=aa[1])return true;
    if(b.inside(a.edges[0].a)||a.inside(b.edges[0].a))return false;
    var tol=gap-1e-5,pad=Math.max(0,tol);
    return a.edges.every(function(e){return !b.some(e.box,pad,function(f){
      return properCross(e.a,e.b,f.a,f.b) || edgeDistance(e.a,f.a,f.b)<tol || edgeDistance(f.a,e.a,e.b)<tol;
    });});
  }
  function topology(loops,gap){
    var indexes=loops.map(edgeIndex),outer=indexes[0],holes=indexes.slice(1);
    holes.forEach(function(h,i){
      if(!fitsIndexed(h,outer,gap))throw Error('Lỗ chạm hoặc vượt đường bao sau làm mịn. Giảm góc ngưỡng.');
      for(var j=0;j<i;j++)if(!separatedIndexed(h,holes[j],gap))throw Error('Các lỗ chạm nhau sau làm mịn. Giảm góc ngưỡng.');
    });
  }
  // An arc may not curve into another opening or separate a tangent contact.
  // Search original segments once, including both holes and material islands.
  function separationCheck(loops){
    var segments=[];
    loops.forEach(function(loop){loop.forEach(function(a,i){var b=loop[(i+1)%loop.length];segments.push({a:a,b:b,i:i,loop:loop,box:segmentBox(a,b)});});});
    function tree(list){
      var box=list.reduce(function(b,e){return [Math.min(b[0],e.box[0]),Math.min(b[1],e.box[1]),Math.max(b[2],e.box[2]),Math.max(b[3],e.box[3])];},[Infinity,Infinity,-Infinity,-Infinity]);
      if(list.length<=12)return {box:box,edges:list};
      var axis=box[2]-box[0]>box[3]-box[1]?0:1;
      list.sort(function(a,b){return a.box[axis]+a.box[axis+2]-b.box[axis]-b.box[axis+2];});
      var mid=Math.floor(list.length/2);
      return {box:box,left:tree(list.slice(0,mid)),right:tree(list.slice(mid))};
    }
    var root=tree(segments);
    return function(loop,i,displacement){
      var a=loop[i],b=loop[(i+1)%loop.length],box=segmentBox(a,b),pad=2*displacement+.0003;
      function close(node){
        if(!intersectsBox(box,node.box,pad))return false;
        if(!node.edges)return close(node.left)||close(node.right);
        return node.edges.some(function(e){
          var delta=Math.abs(i-e.i);
          if(e.loop===loop && (delta<=1 || delta===loop.length-1))return false;
          if(!intersectsBox(box,e.box,pad))return false;
          return (cross(a,b,e.a)*cross(a,b,e.b)<0 && cross(e.a,e.b,a)*cross(e.a,e.b,b)<0) ||
            Math.min(edgeDistance(a,e.a,e.b),edgeDistance(b,e.a,e.b),edgeDistance(e.a,a,b),edgeDistance(e.b,a,b))<=pad;
        });
      }
      return !close(root);
    };
  }
  // Fit through the endpoints and a neighbour. A fourth point independently
  // confirms the circle and the direction of travel before DXF gets a bulge.
  function circleFit(a,b,c,d,s){
    var ux=b[0]-a[0],uy=b[1]-a[1],vx=c[0]-a[0],vy=c[1]-a[1],den=2*(ux*vy-uy*vx);
    if(Math.abs(den)<1e-8)return null;
    var u2=ux*ux+uy*uy,v2=vx*vx+vy*vy,cx=a[0]+(u2*vy-v2*uy)/den,cy=a[1]+(ux*v2-vx*u2)/den;
    var radius=Math.hypot(a[0]-cx,a[1]-cy);
    if(Math.abs(Math.hypot(d[0]-cx,d[1]-cy)-radius)>Math.min(.001,s.tolerance*.1))return null;
    function sweep(p,q){return Math.atan2((p[0]-cx)*(q[1]-cy)-(p[1]-cy)*(q[0]-cx),(p[0]-cx)*(q[0]-cx)+(p[1]-cy)*(q[1]-cy));}
    var turns=[sweep(a,b),sweep(b,c),sweep(c,d)];
    if(!turns.every(function(v){return v*turns[0]>0 && Math.abs(v)<=s.angle*Math.PI/180+1e-8 && Math.abs(v)<Math.PI/3;}))return null;
    return {x:cx,y:cy,r:radius,sweep:sweep};
  }
  function fitEdge(loop,i,s){
    var n=loop.length,p=loop[i],q=loop[(i+1)%n],a=loop[(i+n-1)%n],b=loop[(i+2)%n];
    if(n<5)return null;
    return circleFit(a,p,q,b,s) || circleFit(p,q,b,loop[(i+3)%n],s) || circleFit(q,p,a,loop[(i+n-2)%n],s);
  }
  function angleAt(a,p,b){
    return Math.atan2(cross(a,p,b),(p[0]-a[0])*(b[0]-p[0])+(p[1]-a[1])*(b[1]-p[1]));
  }
  function tangentAngle(a,p,b){
    var incoming=Math.atan2(p[1]-a[1],p[0]-a[0]),left=Math.hypot(a[0]-p[0],a[1]-p[1]),right=Math.hypot(b[0]-p[0],b[1]-p[1]);
    return incoming+angleAt(a,p,b)*left/(left+right);
  }
  function clampBetween(v,a,b){return Math.max(Math.min(a,b),Math.min(Math.max(a,b),v));}
  function curveSamples(loop,i,s,box,clear){
    var n=loop.length,p=loop[i],q=loop[(i+1)%n],a=loop[(i+n-1)%n],b=loop[(i+2)%n],len=Math.hypot(q[0]-p[0],q[1]-p[1]);
    var fir=angleAt(a,p,q),sec=angleAt(p,q,b),limit=s.angle*Math.PI/180;
    if(n<5 || len<.0004)return [];
    var fit=fitEdge(loop,i,s);
    if(fit){
      var delta=fit.sweep(p,q),bulge=Math.tan(delta/4),sag=Math.abs(bulge)*len/2;
      var step=2*Math.acos(Math.max(-1,1-Math.min(fit.r,s.tolerance)/fit.r));
      var count=Math.max(sag>.001?2:1,Math.ceil(Math.abs(delta)/step),Math.ceil(Math.abs(delta)*s.segments/(Math.PI/2)));
      if(count>256)throw Error('Cung vượt giới hạn điểm; tăng dung sai.');
      if(count===1 || !clear(loop,i,sag+.0001))return [];
      var start=Math.atan2(p[1]-fit.y,p[0]-fit.x),circle=[];
      for(var j=1;j<count;j++){
        var theta=start+delta*j/count,v=[fit.x+fit.r*Math.cos(theta),fit.y+fit.r*Math.sin(theta)];
        if(v[0]<box[0] || v[0]>box[2] || v[1]<box[1] || v[1]>box[3]){circle=[];break;}
        circle.push(v);
      }
      if(circle.length)return circle;
    }
    // Elliptical and drafting-spline polylines rarely have four points on a
    // single circle. Interpolate gently turning spans with a common tangent.
    // Collinear runs and a long straight beside a short fillet stay straight.
    if(Math.abs(fir)>limit || Math.abs(sec)>limit || Math.min(Math.abs(fir),Math.abs(sec))<.0001 ||
       len>3*Math.max(Math.hypot(a[0]-p[0],a[1]-p[1]),Math.hypot(b[0]-q[0],b[1]-q[1])))return [];
    var t=tangentAngle(a,p,q),u=tangentAngle(p,q,b);
    var c=[p[0]+len*Math.cos(t)/3,p[1]+len*Math.sin(t)/3],d=[q[0]-len*Math.cos(u)/3,q[1]-len*Math.sin(u)/3];
    for(var axis=0;axis<2;axis++){c[axis]=clampBetween(c[axis],p[axis],q[axis]);d[axis]=clampBetween(d[axis],p[axis],q[axis]);}
    var excursion=Math.max(edgeDistance(c,p,q),edgeDistance(d,p,q));
    if(excursion<.001 || !clear(loop,i,excursion))return [];
    var points=[];
    function flatten(start,cp,cq,end,depth){
      if(depth>0 && Math.max(edgeDistance(cp,start,end),edgeDistance(cq,start,end))<s.tolerance-.0001){points.push(end);return;}
      if(depth>=8)throw Error('Đường cong quá nhiều đoạn. Tăng dung sai làm mịn.');
      var ab=midpoint(start,cp),bc=midpoint(cp,cq),cd=midpoint(cq,end),left=midpoint(ab,bc),right=midpoint(bc,cd),mid=midpoint(left,right);
      flatten(start,ab,left,mid,depth+1);flatten(mid,right,cd,end,depth+1);
    }
    flatten(p,c,d,q,0);points.pop();return points;
  }
  function refineArcs(loop,s,edges,clear){
    var out=[],box=bounds(loop);
    loop.forEach(function(p,i){
      out.push(p);
      var q=loop[(i+1)%loop.length];
      if(touches(p,edges)||touches(q,edges))return;
      curveSamples(loop,i,s,box,clear).forEach(function(point){
        var v=point.map(function(x){return Math.round(x*10000)/10000;}),last=out[out.length-1];
        if(Math.hypot(v[0]-last[0],v[1]-last[1])>=.0001 && Math.hypot(v[0]-q[0],v[1]-q[1])>=.0001)out.push(v);
      });
      if(out.length>35000)throw Error('Cung quá nhiều điểm; tăng dung sai.');
    });
    return out;
  }
  function dxfBulges(loops,settings,inside){
    var clear=separationCheck(loops);
    return function(loop,index){
      var p=loop[index],q=loop[(index+1)%loop.length];
      if(inside && (!inside(p)||!inside(q)))return 0;
      var fit=fitEdge(loop,index,settings);
      if(!fit)return 0;
      var delta=fit.sweep(p,q),bulge=Math.tan(delta/4),length=Math.hypot(q[0]-p[0],q[1]-p[1]),sag=Math.abs(bulge)*length/2;
      if(sag<.00015 || sag>settings.tolerance-.0001 || !clear(loop,index,sag))return 0;
      // Never add a new axis extremum between two stored vertices. The SKP
      // and DXF then retain identical loop extents, winding and cut contacts.
      var angle=Math.atan2(q[1]-p[1],q[0]-p[0]),a=angle-delta/2,b=angle+delta/2;
      if(Math.cos(a)*Math.cos(b)<-1e-9 || Math.sin(a)*Math.sin(b)<-1e-9)return 0;
      return bulge;
    };
  }
  function build(row,angle,segments) {
    if (!Number.isFinite(angle)||angle<0||angle>90||!Number.isInteger(segments)||segments<2||segments>12) throw Error('Góc ngưỡng 0–90 độ; độ mịn 2–12 đoạn.');
    if (!row||!Array.isArray(row.loops)||!row.loops.length||row.loops.length>2001) throw Error('Thiếu đường bao mặt cần làm mịn.');
    row.loops.forEach(validate);
    var settings={angle:angle,segments:segments,tolerance:.08/segments},clear=separationCheck(row.loops);
    var loops=row.loops.map(function(loop){
      var refined=angle>0?refineArcs(loop,settings,[],clear):loop.map(function(p){return p.slice();});
      validate(refined);return refined;
    });
    if (loops.reduce(function (sum,l) {return sum+l.length;},0)>35000) throw Error('Kết quả quá 35.000 điểm. Giảm độ mịn.');
    var outer=loops[0],holes=loops.slice(1);
    topology(loops,.0001);
    // Captured coordinates retain six decimals, unlike integer-grid panel
    // contours. Only conform vertices that lie on the actual triangle edge.
    var mesh=G.triangulate(outer,holes,1e-11);
    for (var i=0;i<mesh.triangles.length;i+=3) {
      var a=mesh.triangles[i],b=mesh.triangles[i+1],c=mesh.triangles[i+2];
      if (cross(mesh.points[a],mesh.points[b],mesh.points[c])<0) {mesh.triangles[i+1]=c;mesh.triangles[i+2]=b;}
    }
    return mesh;
  }
  root.LofiLineCleanupGeometry={build:build,smooth:smooth,validate:validate,refineArcs:refineArcs,separationCheck:separationCheck,dxfBulges:dxfBulges,edgeIndex:edgeIndex,fitsIndexed:fitsIndexed,separatedIndexed:separatedIndexed,topology:topology};
})(typeof window==='undefined'?globalThis:window);
