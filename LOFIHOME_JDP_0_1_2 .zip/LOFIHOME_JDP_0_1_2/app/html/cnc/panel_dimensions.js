(function(root){
  'use strict';
  function number(value){return String(Math.round(value*100)/100);}
  function size(width,height){return number(width)+' × '+number(height)+' mm';}
  function rows(config){
    if(!config.custom_regions)return [{index:0,width:config.width,height:config.height}];
    var sx=config.width/config.region_basis[0],sy=config.height/config.region_basis[1];
    return config.custom_regions.map(function(region,index){
      var box=root.LofiCNCGeometry.bounds(region.outer);
      return {index:index,width:(box.x1-box.x0)*sx,height:(box.y1-box.y0)*sy};
    });
  }
  function create(hooks){
    var element=document.createElement('section');element.id='panelDimensionInfo';
    element.innerHTML='<strong>Kích thước từng tấm · ngang × cao</strong><div id="panelDimensionList"></div><small id="panelDimensionNote">Biên cong/gấp khúc: kích thước bao ngoài.</small><div id="panelStockReference"><svg viewBox="0 0 1200 4000" role="img" aria-label="Tấm phôi ngang 1200 mm, cao 4000 mm"><rect x="10" y="10" width="1180" height="3980" fill="#eee0ce" stroke="#a97343" stroke-width="20"/></svg><div><strong>Tấm phôi tham chiếu</strong><div id="panelStockSize">1200 mm × 4000 mm</div><small>Ngang × cao</small></div></div>';
    var stock=element.querySelector('#panelStockReference');stock.remove();
    var list=element.querySelector('#panelDimensionList');
    list.addEventListener('click',function(event){var button=event.target.closest('[data-dimension-region]');if(button)hooks.choose(Number(button.dataset.dimensionRegion),event.shiftKey);});
    list.addEventListener('keydown',function(event){var button=event.target.closest('[data-dimension-region]');if(button&&(event.key==='Enter'||event.key===' ')){event.preventDefault();hooks.choose(Number(button.dataset.dimensionRegion),event.shiftKey);}});
    function update(config,selection){
      var scroll=list.scrollTop;
      list.innerHTML='';rows(config).forEach(function(row){
        var item=document.createElement(config.custom_regions?'button':'span');
        item.className='panel-dimension-row';item.dataset.dimensionIndex=row.index;
        item.dataset.width=row.width;item.dataset.height=row.height;
        item.textContent='Tấm '+(row.index+1)+': '+size(row.width,row.height);
        item.title='Ngang '+number(row.width)+' mm · Cao '+number(row.height)+' mm';
        if(config.custom_regions){item.dataset.dimensionRegion=row.index;item.setAttribute('aria-pressed',String(selection.indexOf(row.index)>=0));}
        list.appendChild(item);
      });
      list.scrollTop=scroll;
      element.querySelector('#panelDimensionNote').hidden=config.outline==='rectangle';
    }
    return {element:element,stockElement:stock,update:update};
  }
  root.LofiPanelDimensions={number:number,size:size,rows:rows,create:create};
})(typeof window==='undefined'?globalThis:window);
