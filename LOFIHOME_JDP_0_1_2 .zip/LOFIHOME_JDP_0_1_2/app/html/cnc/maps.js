﻿(function(){
  'use strict';
  document.addEventListener('DOMContentLoaded',async()=>{
    const dialog=document.createElement('dialog');dialog.id='mapsDialog';
    dialog.innerHTML='<div class="map-head"><strong>LOFIHOME MAP 1.0.13 · 0398 228 229</strong><button id="mapClose">Đóng</button></div><div class="map-content"><section><p>Chọn đối tượng trong CorelDRAW, rồi bấm mẫu MAP để tô ngay.</p><input id="mapSearch" type="search" placeholder="Tìm tên vật liệu…"><div id="mapGrid"></div></section><section class="map-controls"><img id="mapPreview" alt="Vật liệu đã chọn"><h3 id="mapName">Chọn vật liệu</h3><label>Kiểu phủ MAP<select id="mapFit"><option value="cover">Phủ kín đối tượng · không lặp</option><option value="tile">Lặp theo khổ MAP</option></select></label><div class="fields"><label>Khổ lặp ngang (mm)<input id="mapWidth" type="number" min="2.54" max="1524" step="any"></label><label>Khổ lặp cao (mm)<input id="mapHeight" type="number" min="2.54" max="1524" step="any"></label><label>Xoay (°)<input id="mapAngle" type="number" value="0" step="any"></label><label>Dịch X (mm)<input id="mapX" type="number" value="0" step="any"></label><label>Dịch Y (mm)<input id="mapY" type="number" value="0" step="any"></label></div><label><input id="mapRatio" type="checkbox" checked> Giữ tỷ lệ ảnh</label><label><input id="mapMirror" type="checkbox"> Đối xứng khi lặp vân</label><div class="row"><button id="mapRotate">Xoay +90°</button><button id="mapReset">Khổ gốc</button></div><button id="mapApply" class="primary">Áp dụng thông số MAP</button><button id="mapRead">Lấy MAP từ hình đang chọn</button><small id="mapNote">Bấm một mẫu để tô vào đối tượng đang chọn. MAP được nhúng vào bản vẽ CDR.</small><p id="mapStatus" role="status" aria-live="polite"></p></section></div>';
    document.body.appendChild(dialog);
    const $=id=>document.getElementById(id);
    let items=[],selected=null,busy=false;
    // Corel's native pattern tile limits, in millimetres (document unit = mm).
    const MIN_TILE=2.54,MAX_TILE=1524;
    const clean=v=>Number(Number(v).toFixed(3));
    const fmt=v=>Number(v).toLocaleString('vi-VN',{maximumFractionDigits:3});
    const sizeOf=m=>{
      const s=m.size_mm||m.texture_size_mm;
      return s&&s.length===2&&s.every(v=>Number.isFinite(Number(v))&&Number(v)>0)?s.map(Number):[1200,1200];
    };
    function defaultSize(m){
      const s=sizeOf(m),scale=Math.min(Math.max(1,MIN_TILE/Math.min(...s)),MAX_TILE/Math.max(...s));
      return s.map(v=>clean(v*scale));
    }
    for(const id of ['mapWidth','mapHeight']){$(id).min=MIN_TILE;$(id).max=MAX_TILE;}
    $('mapReset').textContent='Khổ mặc định';
    function syncMode(){
      const cover=$('mapFit').value==='cover';
      for(const id of ['mapWidth','mapHeight','mapRatio','mapMirror']){
        $(id).closest('label').hidden=cover;$(id).disabled=busy||cover;
      }
    }
    function note(){
      syncMode();if(!selected)return;
      if($('mapFit').value==='cover'){
        $('mapNote').textContent='Một ảnh phủ kín mỗi đối tượng, giữ tỷ lệ ảnh và cắt phần dư theo biên. Không lặp thành dải. Giữ nguyên kích thước, đường bao và các lỗ của hình.';
        return;
      }
      const s=sizeOf(selected),w=Number($('mapWidth').value),h=Number($('mapHeight').value);
      $('mapNote').textContent='Khổ vật liệu gốc: '+fmt(s[0])+' × '+fmt(s[1])+' mm. '+
        'Khổ lặp MAP: '+fmt(w)+' × '+fmt(h)+' mm. '+
        'Khổ mặc định giữ tỷ lệ ảnh và vừa giới hạn Corel (2,54–1.524 mm). Chỉnh khổ lặp chỉ đổi vân, giữ nguyên kích thước đối tượng.';
    }
    $('mapClose').onclick=()=>dialog.close();
    function select(m){
      selected=m;$('mapPreview').src='../../materials/'+m.preview;$('mapName').textContent=m.name;
      const size=defaultSize(m);$('mapWidth').value=size[0];$('mapHeight').value=size[1];note();
      for(const card of $('mapGrid').querySelectorAll('button')){
        const active=card.dataset.mapId===String(m.id);card.setAttribute('aria-pressed',String(active));
        card.style.outline=active?'2px solid #087c69':'';
      }
    }
    function lock(value){
      busy=value;dialog.setAttribute('aria-busy',String(value));
      for(const control of dialog.querySelectorAll('.map-controls input,.map-controls select,.map-controls button,#mapGrid button'))control.disabled=value;
      syncMode();
    }
    async function send(action,p,name){
      if(busy)return false;
      lock(true);$('mapStatus').textContent=action==='map_apply'?'Đang tô '+name+'…':'Đang đọc MAP…';
      try{
        await CorelHost.send(action,p);
        $('mapStatus').textContent=action==='map_apply'?'Đã tô '+name+' vào đối tượng đang chọn. Ctrl+Z để hoàn tác.':'Đã lấy thông số MAP.';
        return true;
      }catch(e){$('mapStatus').textContent=e.message||'Không thực hiện được lệnh. Chọn đối tượng trong Corel rồi thử lại.';return false;}
      finally{lock(false);}
    }
    function apply(){
      if(busy||!selected)return Promise.resolve(false);
      const cover=$('mapFit').value==='cover',ids=cover?['mapAngle','mapX','mapY']:['mapWidth','mapHeight','mapAngle','mapX','mapY'];
      if(!cover&&['mapWidth','mapHeight'].some(id=>Number($(id).value)<MIN_TILE||Number($(id).value)>MAX_TILE)){
        $('mapStatus').textContent='Khổ lặp MAP phải từ 2,54 đến 1.524 mm. Bấm “Khổ mặc định” để lấy khổ vừa Corel và giữ tỷ lệ ảnh.';return Promise.resolve(false);
      }
      if(ids.some(id=>!$(id).value||!Number.isFinite(Number($(id).value))||!$(id).checkValidity())){
        $('mapStatus').textContent='Kiểm tra lại kích thước và góc MAP.';return Promise.resolve(false);
      }
      const base=defaultSize(selected);
      return send('map_apply',{id:selected.id,fit:$('mapFit').value,width:cover?base[0]:Number($('mapWidth').value),height:cover?base[1]:Number($('mapHeight').value),angle:Number($('mapAngle').value),x:Number($('mapX').value),y:Number($('mapY').value),mirror:!cover&&$('mapMirror').checked},selected.name);
    }
    function render(){
      const q=$('mapSearch').value.toLocaleLowerCase('vi');
      $('mapGrid').replaceChildren(...items.filter(m=>(m.name+' '+(m.search_terms||'')).toLocaleLowerCase('vi').includes(q)).map(m=>{
        const b=document.createElement('button'),img=document.createElement('img'),label=document.createElement('span');
        b.type='button';b.dataset.mapId=String(m.id);b.disabled=busy;
        const active=selected&&String(selected.id)===String(m.id);b.setAttribute('aria-pressed',String(!!active));b.style.outline=active?'2px solid #087c69':'';
        b.title='Tô '+m.name+' vào đối tượng đang chọn';img.loading='lazy';img.src='../../materials/'+m.preview;img.alt='';label.textContent=m.name;b.append(img,label);
        b.onclick=()=>{if(busy)return;if(!selected||selected.id!==m.id)select(m);apply();};
        return b;
      }));
    }
    $('mapSearch').oninput=render;
    $('mapFit').onchange=note;
    $('mapWidth').onchange=()=>{if(selected&&$('mapRatio').checked){const s=sizeOf(selected);$('mapHeight').value=clean(Number($('mapWidth').value)*s[1]/s[0]);}note();};
    $('mapHeight').onchange=()=>{if(selected&&$('mapRatio').checked){const s=sizeOf(selected);$('mapWidth').value=clean(Number($('mapHeight').value)*s[0]/s[1]);}note();};
    $('mapRotate').onclick=()=>{$('mapAngle').value=(Number($('mapAngle').value)+90)%360;};
    $('mapReset').onclick=()=>{if(selected)select(selected);$('mapAngle').value=0;$('mapX').value=0;$('mapY').value=0;$('mapMirror').checked=false;};
    $('mapApply').onclick=apply;
    $('mapRead').onclick=()=>send('map_read',{});
    window.addEventListener('lofi-cnc-reply',e=>{
      if(e.detail.type!=='map_config')return;
      const c=e.detail.config,m=items.find(m=>m.id===c.id);if(!m)return;
      $('mapFit').value=c.fit==='cover'?'cover':'tile';select(m);[['mapWidth','width'],['mapHeight','height'],['mapAngle','angle'],['mapX','x'],['mapY','y']].forEach(([id,key])=>$(id).value=c[key]||0);$('mapMirror').checked=!!c.mirror;note();
    });
    try{items=(await(await fetch('../../materials/catalog.json')).json()).items;render();if(items.length)select(items[0]);}
    catch(e){$('mapStatus').textContent='Không nạp được thư viện MAP: '+e.message;}
  });
})();
