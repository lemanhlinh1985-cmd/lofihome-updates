'use strict';

var G = LofiCNCGeometry,
  $ = function $(id) {
    return document.getElementById(id);
  };
var config = G.normalize(G.defaults),
  model = null,
  presets = [],
  selectedMotif = -1,
  zoom = 1,
  timer = null,
  drag = null;
function status(message) {
  var error = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  $('status').textContent = message;
  $('status').classList.toggle('error', error);
}
function send(action) {
  var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (window.sketchup && typeof window.sketchup.cnc_action === 'function') window.sketchup.cnc_action(JSON.stringify({
    action: action,
    payload: payload
  }));else status('Mở chương trình bằng LOFIHOME.JDP.exe để dùng chức năng này.', true);
}
function syncFields() {
  document.querySelectorAll('[data-key]').forEach(function (e) {
    if (e.type === 'checkbox') e.checked = !!config[e.dataset.key];else e.value = config[e.dataset.key];
  });
}
function loadConfig(value) {
  try {
    var next = G.normalize(value);
    G.build(next);
    config = next;
    selectedMotif = -1;
    zoom = 1;
    syncFields();
    renderPatterns();
    update();
  } catch (e) {
    status(e.message, true);
  }
}
function renderPatterns() {
  var q = $('search').value.trim().toLocaleLowerCase(),
    category = $('category').value;
  $('patterns').textContent = '';
  G.catalog.filter(function (p) {
    return (category === 'Tất cả' || p.category === category) && p.name.toLocaleLowerCase().includes(q);
  }).forEach(function (p) {
    var button = document.createElement('button');
    button.className = 'pattern' + (config.pattern === p.id ? ' selected' : '');
    button.innerHTML = '<svg viewBox="-.6 -.6 1.2 1.2" aria-hidden="true"><path d="' + G.path(G.shape(p.id)) + '" fill="#b58245" stroke="#644122" stroke-width=".015"/></svg>';
    var label = document.createElement('span');
    label.textContent = p.name;
    button.appendChild(label);
    button.onclick = function () {
      config.pattern = p.id;
      renderPatterns();
      update();
    };
    $('patterns').appendChild(button);
  });
}
function update() {
  clearTimeout(timer);
  try {
    model = G.build(config);
    config = model.config;
    renderPreview();
    renderMotifs();
    $('metrics').textContent = config.width + ' × ' + config.height + ' × ' + config.thickness + ' mm · ' + model.holes + ' lỗ đục · Diện tích vật liệu ' + (model.area / 1e6).toFixed(3) + ' m²';
    var issue = model.warnings.join(' ');
    status(issue || 'Mẫu hợp lệ. Có thể dựng vách hoặc xuất đường biên CNC.', !!issue);
    ['create', 'update', 'exportSvg', 'exportDxf'].forEach(function (id) {
      return $(id).disabled = !!issue;
    });
  } catch (e) {
    model = null;
    status(e.message, true);
    ['create', 'update', 'exportSvg', 'exportDxf'].forEach(function (id) {
      return $(id).disabled = true;
    });
  }
}
function schedule() {
  clearTimeout(timer);
  timer = setTimeout(update, 120);
}
function renderPreview() {
  if (!model) return;
  var w = model.width,
    h = model.height,
    pad = Math.max(w, h) * .07,
    vw = (w + pad * 2) / zoom,
    vh = (h + pad * 2) / zoom;
  var markup = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + [(w - vw) / 2, (h - vh) / 2, vw, vh].join(' ') + '"><g transform="translate(0 ' + h + ') scale(1 -1)"><path d="' + model.mesh.loops.map(G.path).join(' ') + '" fill="' + config.material + '" fill-rule="evenodd" stroke="#6e512b" stroke-width="' + Math.max(w, h) / 900 + '"/>';
  model.raised.forEach(function (r) {
    return markup += '<path d="' + G.path(r.mesh.loops[0]) + '" fill="#efcf88" stroke="#a9752a" stroke-width="2"/>';
  });
  config.inserts.forEach(function (m, i) {
    var radius = Math.max(w, h) / 65;
    markup += '<circle data-motif-index="' + i + '" cx="' + m.x + '" cy="' + m.y + '" r="' + radius + '" fill="' + (i === selectedMotif ? '#0b8dba' : '#fff') + '" fill-opacity=".85" stroke="#0b8dba" stroke-width="2"/>';
  });
  markup += '</g></svg>';
  $('preview').innerHTML = markup;
  $('patternName').textContent = G.catalog.find(function (p) {
    return p.id === config.pattern;
  }).name;
}
function renderMotifs() {
  var root = $('motifs');
  root.textContent = '';
  config.inserts.forEach(function (m, i) {
    var b = document.createElement('button');
    b.textContent = i + 1 + '. ' + G.catalog.find(function (p) {
      return p.id === m.pattern;
    }).name;
    b.className = i === selectedMotif ? 'selected' : '';
    b.onclick = function () {
      selectedMotif = i;
      renderMotifs();
      renderPreview();
    };
    root.appendChild(b);
  });
  var item = config.inserts[selectedMotif];
  $('motifEditor').hidden = !item;
  if (item) document.querySelectorAll('[data-motif]').forEach(function (e) {
    return e.value = item[e.dataset.motif];
  });
}
function arrange(axis) {
  var n = config.inserts.length;
  if (!n) return;
  config.inserts.forEach(function (m, i) {
    m.x = axis === 'x' ? config.frame + (config.width - 2 * config.frame) * (i + 1) / (n + 1) : config.width / 2;
    m.y = axis === 'y' ? config.frame + (config.height - 2 * config.frame) * (i + 1) / (n + 1) : config.height / 2;
  });
  update();
}
function mutateMotif(fn) {
  var item = config.inserts[selectedMotif];
  if (!item) return;
  fn(item);
  update();
}
function renderPresets() {
  var root = $('presets');
  root.textContent = '';
  $('presetCount').textContent = '(' + presets.length + ')';
  presets.forEach(function (p) {
    var row = document.createElement('div');
    row.className = 'preset';
    var load = document.createElement('button');
    load.textContent = p.name;
    load.onclick = function () {
      return loadConfig(p.config);
    };
    var remove = document.createElement('button');
    remove.textContent = 'Xóa';
    remove.className = 'danger';
    remove.onclick = function () {
      if (confirm('Xóa mẫu đã lưu: ' + p.name + '?')) send('delete_preset', {
        id: p.id
      });
    };
    row.append(load, remove);
    root.appendChild(row);
  });
  if (!presets.length) root.textContent = 'Bấm Lưu mẫu để lưu cấu hình đang chỉnh.';
}
window.lofiCNCReply = function (data) {
  window.dispatchEvent(new CustomEvent('lofi-cnc-reply', {
    detail: data
  }));
  if (data.type === 'presets') {
    presets = data.items || [];
    renderPresets();
  }
  if (data.type === 'config') loadConfig(data.config);
  if (data.type === 'outline') {
    loadConfig(Object.assign({}, config, {
      outline: 'custom',
      custom_outer: data.points,
      width: data.width,
      height: data.height,
      thickness: data.thickness == null ? config.thickness : data.thickness,
      custom_placement: data.placement, custom_place: !!data.placement
    }));
  }
  if (data.message && data.type !== 'panel_outline') status(data.message, data.type === 'error');
};
document.querySelectorAll('[data-key]').forEach(function (e) {
  return e.addEventListener('input', function () {
    config[e.dataset.key] = e.type === 'checkbox' ? e.checked : e.getAttribute('type') === 'number' ? Number(e.value) : e.value;
    schedule();
  });
});
document.querySelectorAll('[data-motif]').forEach(function (e) {
  return e.addEventListener('input', function () {
    var item = config.inserts[selectedMotif];
    if (item) {
      item[e.dataset.motif] = e.getAttribute('type') === 'number' ? Number(e.value) : e.value;
      schedule();
    }
  });
});
$('search').oninput = renderPatterns;
$('category').onchange = renderPatterns;
$('reset').onclick = function () {
  return loadConfig(G.defaults);
};
$('centerPattern').onclick = function () {
  config.offset_x = 0;
  config.offset_y = 0;
  syncFields();
  update();
};
$('loadSelected').onclick = function () {
  return send('load_selected');
};
$('captureFace').onclick = function () {
  return send('capture_face');
};
$('savePreset').onclick = function () {
  update();
  if (model && !model.warnings.length) send('save_preset', {
    name: config.name,
    config: config
  });
};
$('exportPresets').onclick = function () {
  return send('export_presets');
};
$('importPresets').onclick = function () {
  return send('import_presets');
};
$('create').onclick = function () {
  update();
  if (model && !model.warnings.length) send('create', model);
};
$('update').onclick = function () {
  update();
  if (model && !model.warnings.length) send('update', model);
};
$('exportSvg').onclick = function () {
  update();
  if (model && !model.warnings.length) send('export', {
    format: 'svg',
    content: G.svg(model)
  });
};
$('exportDxf').onclick = function () {
  update();
  if (model && !model.warnings.length) send('export', {
    format: 'dxf',
    content: G.dxf(model)
  });
};
$('exportSkp').onclick = function () {
  return send('export_skp');
};
G.catalog.filter(function (p) {
  return p.id !== 'solid';
}).forEach(function (p) {
  var o = document.createElement('option');
  o.value = p.id;
  o.textContent = p.name;
  $('motifPattern').appendChild(o);
});
$('motifPattern').value = 'petal6';
$('addMotif').onclick = function () {
  if (config.inserts.length >= 12) {
    status('Tối đa 12 họa tiết chèn.', true);
    return;
  }
  config.inserts.push({
    id: 'motif-' + Date.now(),
    pattern: $('motifPattern').value,
    x: config.width / 2,
    y: config.height / 2,
    size: Math.min(config.width - 2 * config.frame, config.height - 2 * config.frame) * .45,
    angle: 0,
    mode: 'cut',
    depth: 5
  });
  selectedMotif = config.inserts.length - 1;
  update();
};
$('duplicateMotif').onclick = function () {
  if (config.inserts.length >= 12) {
    status('Tối đa 12 họa tiết chèn.', true);
    return;
  }
  var m = config.inserts[selectedMotif];
  if (m) {
    config.inserts.push(Object.assign({}, m, {
      id: 'motif-' + Date.now(),
      x: Math.min(config.width - m.size / 2, m.x + m.size + config.web)
    }));
    selectedMotif = config.inserts.length - 1;
    update();
  }
};
$('removeMotif').onclick = function () {
  if (selectedMotif >= 0) config.inserts.splice(selectedMotif, 1);
  selectedMotif = -1;
  update();
};
$('rotateMotif').onclick = function () {
  return mutateMotif(function (m) {
    return m.angle = (m.angle + 90) % 360;
  });
};
$('mirrorMotif').onclick = function () {
  return mutateMotif(function (m) {
    m.x = config.width - m.x;
    m.angle = -m.angle;
  });
};
$('arrangeVertical').onclick = function () {
  return arrange('y');
};
$('arrangeHorizontal').onclick = function () {
  return arrange('x');
};
$('zoomIn').onclick = function () {
  zoom = Math.min(4, zoom * 1.25);
  renderPreview();
};
$('zoomOut').onclick = function () {
  zoom = Math.max(.5, zoom / 1.25);
  renderPreview();
};
$('fit').onclick = function () {
  zoom = 1;
  renderPreview();
};
$('preview').addEventListener('pointerdown', function (e) {
  var t = e.target.closest('[data-motif-index]');
  if (!t) return;
  selectedMotif = Number(t.dataset.motifIndex);
  drag = {
    pointer: e.pointerId
  };
  $('preview').setPointerCapture(e.pointerId);
  renderMotifs();
  e.preventDefault();
});
$('preview').addEventListener('pointermove', function (e) {
  if (!drag || !model) return;
  var svg = $('preview').querySelector('svg'),
    point = svg.createSVGPoint();
  point.x = e.clientX;
  point.y = e.clientY;
  var p = point.matrixTransform(svg.getScreenCTM().inverse()),
    m = config.inserts[selectedMotif];
  m.x = Math.round(Math.max(0, Math.min(config.width, p.x)));
  m.y = Math.round(Math.max(0, Math.min(config.height, config.height - p.y)));
  schedule();
});
$('preview').addEventListener('pointerup', function () {
  if (drag) {
    drag = null;
    update();
  }
});
$('preview').addEventListener('pointercancel', function () {
  drag = null;
  update();
});
syncFields();
renderPatterns();
renderPresets();
update();
send('ready');
