(function(){
  'use strict';
  const callbacks=new Map(),captures=new Map();let sequence=0;
  function host(action,payload){
    // A double click must not send a second capture while Corel is replying.
    // Coalesce only the same read action; mutations are never retried or merged.
    const capture=action==='panel_capture_face'||action==='capture_face';
    if(capture&&captures.has(action))return captures.get(action);
    const pending=new Promise((resolve,reject)=>{const id='corel-'+Date.now().toString(36)+'-'+(++sequence);callbacks.set(id,{resolve,reject});if(window.chrome&&chrome.webview)chrome.webview.postMessage({action,payload:payload||{},reply_id:id});else{callbacks.delete(id);reject(Error('Mở giao diện bằng LOFIHOME Corel để sử dụng.'));}});
    if(capture){captures.set(action,pending);const clear=()=>{if(captures.get(action)===pending)captures.delete(action);};pending.then(clear,clear);}
    return pending;
  }
  window.corelDone=function(id,ok,message){const p=callbacks.get(id);if(!p)return;callbacks.delete(id);ok?p.resolve():p.reject(Error(message||'Không thực hiện được lệnh.'));};
  function reply(data){if(window.lofiCNCReply)window.lofiCNCReply(data);}
  async function asset(id){
    if(!window.LofiOriginalCNCCatalog.some(e=>e.id===id))throw Error('Mã mẫu không hợp lệ.');
    async function load(folder){await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=folder+'/'+id+'.js';s.onload=resolve;s.onerror=()=>reject(Error('Không nạp được dữ liệu mẫu '+id));document.head.appendChild(s);});}
    if(!window.LofiCNCShapes||!LofiCNCShapes[id])await load('source_shapes');
    if(window.LofiUniformInsertIndex[id]&&!LofiCNCShapes[id].even)await load('uniform');
    return LofiCNCShapes[id];
  }
  async function sourcePacket(p){
    const source=await asset(p.id),entry=LofiOriginalCNCCatalog.find(e=>e.id===p.id),contours=[];
    if(!Number.isInteger(p.columns)||!Number.isInteger(p.rows)||p.columns<1||p.rows<1||p.columns*p.rows>100)throw Error('Số hàng/cột từ 1, tổng tối đa 100 mẫu.');
    for(let row=0;row<p.rows;row++)for(let col=0;col<p.columns;col++){
      const item={id:p.id,mode:'union',width:p.width,height:p.height,x:(col+.5)*p.width+col*p.gap_x,y:(row+.5)*p.height+row*p.gap_y,angle:p.angle||0,mirror:!!p.mirror,even_insert:!!p.even_insert};
      LofiCNCPanel.itemParts(item,source).forEach(s=>contours.push({loops:[s.outer].concat(s.holes),z:0}));
    }
    return {contours,config:p,kind:'source_config',name:entry.name,width:p.columns*p.width+(p.columns-1)*p.gap_x,height:p.rows*p.height+(p.rows-1)*p.gap_y};
  }
  function packet(p,kind){
    let contours=p.contours;
    if(!contours&&p.solids)contours=p.solids.map(s=>({loops:s.loops,z:s.z||0}));
    if(!contours&&p.mesh)contours=[{loops:p.mesh.loops,z:0}].concat((p.raised||[]).map(s=>({loops:s.mesh.loops,z:1})));
    if(!contours||!contours.length)throw Error('Không có đường bao để tạo vector.');
    const cfg=p.config||{},setting=cfg.smoothing;
    if(setting&&setting.mode==='arcs'&&LofiPanelSmoothing.active(setting)){
      const fit=LofiPanelSmoothing.dxfBulges(contours.flatMap(s=>s.loops),setting);
      contours=contours.map(s=>Object.assign({},s,{bulges:s.loops.map(l=>l.map((_,i)=>fit(l,i)))}));
    }
    return {contours,config:cfg,kind:kind||'panel_config',name:p.name||(p.config&&p.config.name)||'LOFIHOME CNC',width:p.width,height:p.height,request_id:p.request_id||'vector-'+Date.now().toString(36)+'-'+(++sequence)};
  }
  async function dispatch(action,p){
    if(action==='panel_create'||action==='panel_update'){
      let ok=false,message='';try{await host(action==='panel_update'?'corel_update':'corel_create',packet(p));ok=true;message='Đã tạo vector trong CorelDRAW. Ctrl+Z để hoàn tác.';}catch(e){message=e.message;}finally{reply({type:'panel_operation_done',request_id:p.request_id,action,ok,message});}return;
    }
    if(action==='create'||action==='update')return host(action==='update'?'corel_update':'corel_create',packet(p,'config'));
    if(action==='source_insert'||action==='source_update')return host(action==='source_update'?'corel_update':'corel_create',packet(await sourcePacket(p),'source_config'));
    if(action==='source_export'){
      const built=await sourcePacket(p);
      if(p.format==='skp')return host('corel_export_vectors',packet(built,'source_config'));
      return host('export',{format:p.format,name:built.name,content:p.format==='json'?JSON.stringify(p,null,2):LofiCNCPanel[p.format](built)});
    }
    if(action==='panel_item_create')return host('corel_create',packet(p,'standalone_item'));
    if(action==='panel_item_skp')return host('corel_export_vectors',packet(p,'standalone_item'));
    if(['export_skp','panel_export_skp'].includes(action))return host('corel_save',{});
    if(action==='source_layout_load'){
      // The initial default remains valid when there is no saved user layout.
      return host(action,{});
    }
    return host(action,p);
  }
  window.sketchup={cnc_action:function(json){const data=JSON.parse(json);Promise.resolve().then(()=>dispatch(data.action,data.payload||{})).catch(e=>reply({type:'error',message:e.message}));}};
  window.sketchup.cnc_window_fit=function(json){const data=JSON.parse(json);if(data.force)host('fit_window',{}).catch(e=>reply({type:'error',message:e.message}));};
  window.CorelHost={send:host,packet,asset,sourcePacket};
  document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('input[data-key],input[data-motif]').forEach(e=>{const key=e.dataset.key||e.dataset.motif;if(['rotation','angle'].indexOf(key)<0){e.removeAttribute('min');e.removeAttribute('max');e.step='any';}});
    const original=window.lofiCNCReply;
    window.lofiCNCReply=function(data){
      if(data.type==='source_layout'&&!data.layout)return;
      if(data.type==='corel_capture'){
        try{
          const loops=data.loops.slice().sort((a,b)=>Math.abs(LofiCNCGeometry.area(b))-Math.abs(LofiCNCGeometry.area(a)));
          const outer=loops[0],holes=loops.slice(1);
          if(holes.some(h=>!LofiCNCGeometry.fits(h,outer,.001)))throw Error('Chọn một đường bao ngoài cùng các lỗ nằm bên trong.');
          data={type:data.reply_type,points:outer,holes,width:data.width,height:data.height,source:data.source,message:data.message};
        }catch(e){data={type:'error',message:e.message};}
      }
      original(data);
    };
    // Corel already provides its own node editor, split and cursor tools.
    // Hide only host-specific tools; geometry controls and 2D/3D previews remain.
    ['splitPlate','lineCleanup','insertPlace','originalNative','panelCaptureRegions','insertWallCleanup'].forEach(id=>{const e=document.getElementById(id);if(e)e.style.setProperty('display','none','important');});
    const header=document.querySelector('header');
    const maps=document.createElement('button');maps.textContent='MAP / Vật liệu';maps.id='corelMaps';header.appendChild(maps);maps.onclick=()=>document.getElementById('mapsDialog').showModal();
    const zalo=document.createElement('button');zalo.textContent='Nhóm Zalo';header.appendChild(zalo);zalo.onclick=()=>host('zalo',{}).catch(e=>reply({type:'error',message:e.message}));
    const license=document.createElement('button');license.textContent='Khóa / Dùng thử';header.appendChild(license);
    const modal=document.createElement('dialog');modal.style.cssText='width:540px;padding:24px;border:1px solid #cad5df;border-radius:10px';
    modal.innerHTML='<h2>Khóa LOFIHOME · Dùng thử 15 ngày</h2><p>Hết hạn dùng thử, liên hệ 0398 228 229 để được cấp key. Gửi mã máy bên dưới cho chủ sở hữu, rồi nhập key được cấp để tiếp tục sử dụng.</p><p id="corelLicenseState"></p><label>Mã máy<input id="corelMachine" readonly style="width:100%"></label><label>Key do chủ sở hữu cấp<textarea id="corelLicenseKey" rows="6" style="width:100%"></textarea></label><button id="corelActivate">Kích hoạt</button> <button id="corelLicenseClose">Đóng</button>';
    document.body.appendChild(modal);document.getElementById('corelLicenseClose').onclick=()=>modal.close();
    license.onclick=()=>{modal.showModal();host('license_state',{}).catch(e=>document.getElementById('corelLicenseState').textContent=e.message);};
    document.getElementById('corelActivate').onclick=()=>host('license_activate',{key:document.getElementById('corelLicenseKey').value}).catch(e=>document.getElementById('corelLicenseState').textContent=e.message);
    window.addEventListener('lofi-cnc-reply',e=>{if(e.detail.type==='license_state'){document.getElementById('corelLicenseState').textContent=e.detail.state.message;document.getElementById('corelMachine').value=e.detail.state.machine;}});
  });
})();
