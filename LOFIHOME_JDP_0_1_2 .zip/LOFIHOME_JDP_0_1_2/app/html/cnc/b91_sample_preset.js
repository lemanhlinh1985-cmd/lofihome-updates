(function(){
 'use strict';
 var id='patterns__dvd24_b091';
 var entry=(window.LofiOriginalCNCCatalog||[]).find(function(e){return e.id===id;});
 if(!entry||!window.LofiPanelUI||document.getElementById('b91PanelOptions'))return;
 var width=document.querySelector('[data-panel="width"]');
 var height=document.querySelector('[data-panel="height"]');
 var module=document.querySelector('[data-panel="module"]');
 if(!width||!height||!module||!width.closest('.fields'))return;
 var applying=false,editing=false;
 function config(){return LofiPanelUI.getConfig();}
 function active(c){return c&&c.id===id;}
 function apply(c){
  if(applying||!active(c))return;
  applying=true;
  try{window.lofiCNCReply({type:'panel_config',config:c});}
  finally{applying=false;}
  show();
 }
 function preset(){
  if(!active(config())||!entry.panel_preset)return;
  apply(JSON.parse(JSON.stringify(entry.panel_preset)));
 }
 var box=document.createElement('div');box.id='b91PanelOptions';
 box.style.cssText='margin:8px 0;padding:9px;border:1px solid #bbdacf;border-radius:5px;background:#f2faf6';
 function checkbox(name,text){
  var label=document.createElement('label'),input=document.createElement('input');
  label.style.cssText='display:block;margin:5px 0';input.type='checkbox';input.id=name;
  label.appendChild(input);label.appendChild(document.createTextNode(' '+text));box.appendChild(label);return input;
 }
 var whole=checkbox('b91KeepLayout','Giữ nguyên bố cục mẫu');
 var lock=checkbox('b91KeepRatio','Giữ tỷ lệ mẫu');
 var note=document.createElement('small');note.style.display='block';box.appendChild(note);
 width.closest('.fields').after(box);
 function show(){
  var c=config(),isB91=active(c),full=isB91&&c.b91_single_panel!==false;
  box.hidden=!isB91;whole.checked=c.b91_single_panel!==false;lock.checked=c.b91_lock_ratio!==false;
  note.textContent=full?'Một vách nguyên mẫu. Đổi rộng/cao sẽ co giãn toàn bố cục. Bỏ Giữ tỷ lệ mẫu để chỉnh riêng từng chiều. Khung gốc đã có trong mẫu.':'Đang lặp hoa văn theo Cỡ mô-đun. Bật Giữ nguyên bố cục mẫu để lấy lại một vách hoàn chỉnh.';
  if(full){
   if(!module.dataset.b91PreviousDisabled)module.dataset.b91PreviousDisabled=module.disabled?'yes':'no';
   module.disabled=true;
  }else if(module.dataset.b91PreviousDisabled){
   var previous=module.dataset.b91PreviousDisabled==='yes';delete module.dataset.b91PreviousDisabled;
   // KK runs first. Hand back the pre-B91 state without unlocking KK itself;
   // otherwise its later exit would remember our temporary lock as permanent.
   if(module.dataset.kkPreviousDisabled)module.dataset.kkPreviousDisabled=previous?'yes':'no';
   else module.disabled=previous;
  }
 }
 whole.onchange=function(){
  var c=config();if(!active(c))return;
  c.b91_single_panel=whole.checked;
  if(whole.checked){c.offset_x=0;c.offset_y=0;}
  else{c.offset_x=-c.module/2;c.offset_y=-c.module*entry.height/entry.width/2;}
  apply(c);
 };
 lock.onchange=function(){
  var c=config();if(!active(c))return;
  c.b91_lock_ratio=lock.checked;
  if(lock.checked)c.width=+(c.height*entry.width/entry.height).toFixed(6);
  apply(c);
 };
 document.addEventListener('input',function(e){
  if(editing||applying||(e.target!==width&&e.target!==height))return;
  var c=config();if(!active(c)||c.b91_lock_ratio===false)return;
  var n=Number(e.target.value);if(!Number.isFinite(n)||!(n>0))return;
  var other=e.target===width?height:width;
  var value=e.target===width?n*entry.height/entry.width:n*entry.width/entry.height;
  editing=true;
  try{other.value=+value.toFixed(6);other.dispatchEvent(new Event('input',{bubbles:true}));}
  finally{editing=false;}
 },true);
 window.addEventListener('lofi-source-select',function(e){
  if(e.detail&&e.detail.item&&e.detail.item.id===id&&!e.detail.loaded&&!applying&&active(config()))preset();
  show();
 });
 window.addEventListener('lofi-cnc-reply',function(e){if(e.detail&&e.detail.type==='panel_config')show();});
 var reset=document.getElementById('panelReset');
 if(reset){var oldReset=reset.onclick;reset.onclick=function(e){if(active(config()))preset();else if(oldReset)oldReset.call(this,e);};}
 show();
})();
