function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
(function (root) {
  'use strict';

  var catalog = [['square', 'Ô vuông', 'Hình học'], ['diamond', 'Quả trám', 'Hình học'], ['circle', 'Lỗ tròn', 'Hình học'], ['ellipse', 'Ô bầu dục', 'Hình học'], ['hexagon', 'Tổ ong', 'Hình học'], ['octagon', 'Bát giác', 'Hình học'], ['triangle', 'Tam giác', 'Hình học'], ['roundrect', 'Ô bo góc', 'Hình học'], ['petal4', 'Hoa bốn cánh', 'Hoa văn'], ['petal6', 'Hoa sáu cánh', 'Hoa văn'], ['petal8', 'Hoa tám cánh', 'Hoa văn'], ['star4', 'Sao bốn cánh', 'Hoa văn'], ['star6', 'Sao sáu cánh', 'Hoa văn'], ['star8', 'Sao tám cánh', 'Hoa văn'], ['leaf', 'Lá thon', 'Lá / Diềm'], ['leafwide', 'Lá bầu', 'Lá / Diềm'], ['arch', 'Vòm cửa', 'Lá / Diềm'], ['lantern', 'Đèn lồng', 'Lá / Diềm'], ['wave', 'Sóng mềm', 'Lá / Diềm'], ['cross', 'Chữ thập', 'Hình học'], ['slotv', 'Nan dọc', 'Lá / Diềm'], ['sloth', 'Nan ngang', 'Lá / Diềm'], ['fan', 'Cánh quạt', 'Hoa văn'], ['solid', 'Tấm đặc', 'Hình học']].map(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 3),
      id = _ref2[0],
      name = _ref2[1],
      category = _ref2[2];
    return {
      id: id,
      name: name,
      category: category
    };
  });
  var defaults = {
    name: 'Vách CNC LOFIHOME',
    pattern: 'petal4',
    width: 650,
    height: 1500,
    thickness: 18,
    frame: 40,
    module: 150,
    web: 12,
    rotation: 0,
    offset_x: 0,
    offset_y: 0,
    mirror: false,
    region: 'all',
    outline: 'rectangle',
    plane: 'xz',
    material: '#c69b62',
    inserts: []
  };
  function num(v, min, max, name) {
    v = Number(v);
    if (!Number.isFinite(v) || v < min || v > max) throw Error(name + (min===Number.MIN_VALUE ? ' phải là số lớn hơn 0.' : ' ngoài phạm vi hợp lệ.'));
    return v;
  }
  function normalize(input) {
    var c = Object.assign({}, defaults, input || {});
    for (var _i = 0, _arr = [['width', Number.MIN_VALUE, Infinity, 'Rộng'], ['height', Number.MIN_VALUE, Infinity, 'Cao'], ['thickness', Number.MIN_VALUE, Infinity, 'Độ dày'], ['frame', Number.MIN_VALUE, Infinity, 'Khung'], ['module', Number.MIN_VALUE, Infinity, 'Mô-đun'], ['web', Number.MIN_VALUE, Infinity, 'Nan tối thiểu'], ['rotation', -360, 360, 'Góc'], ['offset_x', -Infinity, Infinity, 'Dịch X'], ['offset_y', -Infinity, Infinity, 'Dịch Y']]; _i < _arr.length; _i++) {
      var _arr$_i = _slicedToArray(_arr[_i], 4),
        k = _arr$_i[0],
        min = _arr$_i[1],
        max = _arr$_i[2],
        label = _arr$_i[3];
      c[k] = num(c[k], min, max, label);
    }
    if (c.frame * 2 >= Math.min(c.width, c.height)) throw Error('Khung phải nhỏ hơn nửa kích thước tấm.');
    if (!catalog.some(function (p) {
      return p.id === c.pattern;
    })) throw Error('Mẫu CNC không hợp lệ.');
    if (!['all', 'border', 'center', 'vertical', 'horizontal'].includes(c.region)) throw Error('Vùng bố trí không hợp lệ.');
    if (!['rectangle', 'arch', 'custom'].includes(c.outline)) throw Error('Biên dạng không hợp lệ.');
    c.name = String(c.name || defaults.name).slice(0, 100);
    c.material = /^#[0-9a-f]{6}$/i.test(c.material) ? c.material : defaults.material;
    c.plane = c.plane === 'xy' ? 'xy' : 'xz';
    c.mirror = !!c.mirror;
    c.inserts = Array.isArray(c.inserts) ? c.inserts.slice(0, 12).map(function (m, i) {
      return {
        id: String(m.id || 'motif' + i),
        pattern: catalog.some(function (p) {
          return p.id === m.pattern && p.id !== 'solid';
        }) ? m.pattern : 'petal6',
        x: num(m.x, 0, c.width, 'X họa tiết'),
        y: num(m.y, 0, c.height, 'Y họa tiết'),
        size: num(m.size, Number.MIN_VALUE, Infinity, 'Cỡ họa tiết'),
        angle: num(m.angle || 0, -360, 360, 'Góc họa tiết'),
        mode: m.mode === 'raised' ? 'raised' : 'cut',
        depth: num(m.depth === undefined ? 5 : m.depth, Number.MIN_VALUE, Infinity, 'Độ nổi')
      };
    }) : [];
    if (c.outline === 'custom') c.custom_outer = validateLoop(c.custom_outer, 'Biên dạng Face');
    return c;
  }
  function area(p) {
    return p.reduce(function (s, a, i) {
      var b = p[(i + 1) % p.length];
      return s + a[0] * b[1] - b[0] * a[1];
    }, 0) / 2;
  }
  function orient(p, ccw) {
    return area(p) > 0 === ccw ? p.slice() : p.slice().reverse();
  }
  function cross(a, b, c) {
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  }
  function intersects(a, b, c, d) {
    return cross(a, b, c) * cross(a, b, d) < -1e-8 && cross(c, d, a) * cross(c, d, b) < -1e-8;
  }
  function validateLoop(p, label) {
    // Match the native Corel capture and panel's 5000-point contour budget.
    // Large smooth curves legitimately have more than 500 sampled vertices.
    if (!Array.isArray(p) || p.length < 3 || p.length > 5000) throw Error(label + ': cần 3–5000 đỉnh.');
    p = p.map(function (q) {
      if (!Array.isArray(q) || q.length !== 2 || !q.every(Number.isFinite)) throw Error(label + ': tọa độ không hợp lệ.');
      return q.slice();
    }).filter(function (q, i, a) {
      return !i || Math.hypot(q[0] - a[i - 1][0], q[1] - a[i - 1][1]) > 1e-6;
    });
    if (Math.hypot(p[0][0] - p[p.length - 1][0], p[0][1] - p[p.length - 1][1]) < 1e-6) p.pop();
    var changed = true;
    while (changed && p.length > 3) {
      changed = false;
      for (var i = 0; i < p.length; i++) {
        var a = p[(i + p.length - 1) % p.length],
          b = p[i],
          c = p[(i + 1) % p.length];
        if (Math.abs(cross(a, b, c)) < 1e-8 && segmentDistance(b, a, c) < 1e-6) {
          p.splice(i, 1);
          changed = true;
          break;
        }
      }
    }
    if (Math.abs(area(p)) < 1e-4) throw Error(label + ': diện tích bằng 0.');
    var edges = p.map(function (a, i) {
      var b = p[(i + 1) % p.length];
      return {x0:Math.min(a[0],b[0]),x1:Math.max(a[0],b[0]),y0:Math.min(a[1],b[1]),y1:Math.max(a[1],b[1])};
    });
    for (var _i2 = 0; _i2 < p.length; _i2++) for (var j = _i2 + 2; j < p.length; j++) {
      if (_i2 === 0 && j === p.length - 1) continue;
      var e1=edges[_i2],e2=edges[j];
      if(e1.x1<e2.x0 || e2.x1<e1.x0 || e1.y1<e2.y0 || e2.y1<e1.y0)continue;
      if (intersects(p[_i2], p[(_i2 + 1) % p.length], p[j], p[(j + 1) % p.length])) throw Error(label + ': đường tự cắt.');
    }
    return orient(p, true);
  }
  function bounds(p) {
    return {
      x0: Math.min.apply(Math, _toConsumableArray(p.map(function (q) {
        return q[0];
      }))),
      x1: Math.max.apply(Math, _toConsumableArray(p.map(function (q) {
        return q[0];
      }))),
      y0: Math.min.apply(Math, _toConsumableArray(p.map(function (q) {
        return q[1];
      }))),
      y1: Math.max.apply(Math, _toConsumableArray(p.map(function (q) {
        return q[1];
      })))
    };
  }
  function inside(q, p) {
    var hit = false;
    for (var i = 0, j = p.length - 1; i < p.length; j = i++) {
      var a = p[i],
        b = p[j];
      if (a[1] > q[1] !== b[1] > q[1] && q[0] < (b[0] - a[0]) * (q[1] - a[1]) / (b[1] - a[1]) + a[0]) hit = !hit;
    }
    return hit;
  }
  function segmentDistance(p, a, b) {
    var dx = b[0] - a[0],
      dy = b[1] - a[1],
      t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy || 1)));
    return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy);
  }
  function fits(hole, outer, gap) {
    return hole.every(function (q) {
      return inside(q, outer) && outer.every(function (a, i) {
        return segmentDistance(q, a, outer[(i + 1) % outer.length]) >= gap - 1e-6;
      });
    }) && !hole.some(function (a, i) {
      return outer.some(function (b, j) {
        return intersects(a, hole[(i + 1) % hole.length], b, outer[(j + 1) % outer.length]) || segmentDistance(b, a, hole[(i + 1) % hole.length]) < gap - 1e-6;
      });
    });
  }
  function separated(a, b, gap) {
    var aa = bounds(a),
      bb = bounds(b);
    if (aa.x1 + gap <= bb.x0 || bb.x1 + gap <= aa.x0 || aa.y1 + gap <= bb.y0 || bb.y1 + gap <= aa.y0) return true;
    if (inside(a[0], b) || inside(b[0], a)) return false;
    return a.every(function (p, i) {
      return b.every(function (q, j) {
        return !intersects(p, a[(i + 1) % a.length], q, b[(j + 1) % b.length]) && segmentDistance(p, q, b[(j + 1) % b.length]) >= gap - 1e-5 && segmentDistance(q, p, a[(i + 1) % a.length]) >= gap - 1e-5;
      });
    });
  }
  function radial(n, radius) {
    return Array.from({
      length: n
    }, function (_, i) {
      var a = 2 * Math.PI * i / n,
        r = radius(a, i);
      return [Math.cos(a) * r, Math.sin(a) * r];
    });
  }
  function shape(id) {
    if (id === 'square' || id === 'solid') return [[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]];
    if (id === 'diamond') return [[0, -.5], [.5, 0], [0, .5], [-.5, 0]];
    if (id === 'hexagon') return radial(6, function () {
      return .5;
    });
    if (id === 'octagon') return radial(8, function () {
      return .5;
    });
    if (id === 'triangle') return radial(3, function () {
      return .5;
    });
    if (id === 'cross') return [[-.18, -.5], [.18, -.5], [.18, -.18], [.5, -.18], [.5, .18], [.18, .18], [.18, .5], [-.18, .5], [-.18, .18], [-.5, .18], [-.5, -.18], [-.18, -.18]];
    if (id === 'roundrect') return radial(64, function (a) {
      return .5 / Math.pow(Math.pow(Math.abs(Math.cos(a)), 5) + Math.pow(Math.abs(Math.sin(a)), 5), .2);
    });
    if (id === 'arch') return [[-.5, -.5], [.5, -.5]].concat(Array.from({
      length: 25
    }, function (_, i) {
      return [.5 * Math.cos(Math.PI * i / 24), .5 * Math.sin(Math.PI * i / 24)];
    }));
    if (id === 'leaf' || id === 'leafwide') {
      var w = id === 'leaf' ? .32 : .5;
      return Array.from({
        length: 25
      }, function (_, i) {
        return [w * Math.sin(Math.PI * i / 24), .5 - i / 24];
      }).concat(Array.from({
        length: 23
      }, function (_, i) {
        return [-w * Math.sin(Math.PI * (23 - i) / 24), .5 - (23 - i) / 24];
      }));
    }
    if (id === 'fan') return [[0, -.4]].concat(Array.from({
      length: 33
    }, function (_, i) {
      var a = Math.PI * i / 32;
      return [.5 * Math.cos(a), -.4 + .85 * Math.sin(a)];
    }));
    if (id === 'wave') return Array.from({
      length: 25
    }, function (_, i) {
      var y = i / 24 - .5;
      return [.25 + .12 * Math.sin(y * Math.PI * 2), y];
    }).concat(Array.from({
      length: 25
    }, function (_, i) {
      var y = .5 - i / 24;
      return [-.25 + .12 * Math.sin(y * Math.PI * 2), y];
    }));
    if (id === 'lantern') return radial(48, function (a) {
      return .43 + .07 * Math.cos(4 * a);
    });
    if (id.startsWith('star')) {
      var count = Number(id.slice(4));
      return radial(count * 2, function (a, i) {
        return i % 2 ? .23 : .5;
      });
    }
    if (id.startsWith('petal')) {
      var _count = Number(id.slice(5));
      return radial(64, function (a) {
        return .37 + .13 * Math.cos(_count * a);
      });
    }
    var p = radial(48, function () {
      return .5;
    });
    if (id === 'ellipse') p = p.map(function (_ref3) {
      var _ref4 = _slicedToArray(_ref3, 2),
        x = _ref4[0],
        y = _ref4[1];
      return [x * .64, y];
    });
    if (id === 'slotv') p = p.map(function (_ref5) {
      var _ref6 = _slicedToArray(_ref5, 2),
        x = _ref6[0],
        y = _ref6[1];
      return [x * .28, y];
    });
    if (id === 'sloth') p = p.map(function (_ref7) {
      var _ref8 = _slicedToArray(_ref7, 2),
        x = _ref8[0],
        y = _ref8[1];
      return [x, y * .28];
    });
    return p;
  }
  function transformed(p, w, h, x, y, angle, mirror) {
    var a = angle * Math.PI / 180,
      c = Math.cos(a),
      s = Math.sin(a);
    var q = p.map(function (_ref9) {
      var _ref0 = _slicedToArray(_ref9, 2),
        u = _ref0[0],
        v = _ref0[1];
      u *= mirror ? -1 : 1;
      return [u * c - v * s, u * s + v * c];
    });
    var b = bounds(q),
      scale = Math.max(1, b.x1 - b.x0, b.y1 - b.y0);
    q = q.map(function (_ref1) {
      var _ref10 = _slicedToArray(_ref1, 2),
        u = _ref10[0],
        v = _ref10[1];
      return [(u - (b.x0 + b.x1) / 2) * w / scale, (v - (b.y0 + b.y1) / 2) * h / scale];
    });
    return validateLoop(q.map(function (_ref11) {
      var _ref12 = _slicedToArray(_ref11, 2),
        u = _ref12[0],
        v = _ref12[1];
      return [u + x, v + y];
    }), 'Họa tiết');
  }
  function conformTriangles(points, triangles, surfaceTolerance) {
    var collinear=surfaceTolerance || 1e-7;
    var sorted = [0, 1].map(function (axis) {
        return points.map(function (_, i) {
          return i;
        }).sort(function (a, b) {
          return points[a][axis] - points[b][axis];
        });
      }),
      cache = new Map();
    var lower = function lower(axis, value) {
      var ids = sorted[axis];
      var lo = 0,
        hi = ids.length;
      while (lo < hi) {
        var mid = lo + hi >>> 1;
        if (points[ids[mid]][axis] < value) lo = mid + 1;else hi = mid;
      }
      return lo;
    };
    function splits(a, b) {
      if (a > b) return splits(b, a).slice().reverse();
      var key = a + ',' + b;
      if (cache.has(key)) return cache.get(key);
      var p = points[a],
        q = points[b],
        dx = q[0] - p[0],
        dy = q[1] - p[1],
        length2 = dx * dx + dy * dy;
      var ranges = [0, 1].map(function (axis) {
        return [lower(axis, Math.min(p[axis], q[axis]) - 1e-7), lower(axis, Math.max(p[axis], q[axis]) + 1e-7)];
      });
      var axis = ranges[0][1] - ranges[0][0] < ranges[1][1] - ranges[1][0] ? 0 : 1,
        found = [];
      for (var k = ranges[axis][0]; k < ranges[axis][1]; k++) {
        var i = sorted[axis][k];
        if (i === a || i === b) continue;
        var r = points[i],
          t = ((r[0] - p[0]) * dx + (r[1] - p[1]) * dy) / length2;
        if (t > 1e-10 && t < 1 - 1e-10 && Math.abs(cross(p, q, r)) < collinear * Math.sqrt(length2)) found.push([t, i]);
      }
      var result = found.sort(function (u, v) {
        return u[0] - v[0];
      }).map(function (v) {
        return v[1];
      });
      cache.set(key, result);
      return result;
    }
    var pending = [],
      result = [];
    for (var i = 0; i < triangles.length; i += 3) pending.push(triangles.slice(i, i + 3));
    var subdivided=surfaceTolerance && new Set();
    while (pending.length) {
      var t = pending.pop();
      if (Math.abs(cross.apply(void 0, _toConsumableArray(t.map(function (i) {
        return points[i];
      })))) < (surfaceTolerance?1e-14:1e-9)) continue;
      var divided = false;
      for (var j = 0; j < 3; j++) {
        var a = t[j],
          b = t[(j + 1) % 3],
          c = t[(j + 2) % 3],
          middle = splits(a, b);
        if (!middle.length) continue;
        if(subdivided){
          // Close but distinct captured vertices can otherwise subdivide each
          // other's new edges indefinitely. Keep the source on any ambiguity.
          var key=t.slice().sort(function(a,b){return a-b;}).join(',');
          if(subdivided.has(key))throw Error('Hai cạnh gần trùng không thể chia thành mặt kín.');
          subdivided.add(key);
        }
        var chain = [a].concat(_toConsumableArray(middle), [b]);
        for (var k = 0; k < chain.length - 1; k++) pending.push([chain[k], chain[k + 1], c]);
        divided = true;
        break;
      }
      if (!divided) result.push.apply(result, _toConsumableArray(t));
    }
    return result;
  }
  function triangulate(outer, holes, surfaceTolerance) {
    var ec = root.earcut;
    if (!ec) throw Error('Chưa nạp bộ dựng hình CNC.');
    var loops = [orient(outer, true)].concat(holes.map(function (h) {
        return orient(h, false);
      })),
      flat = [],
      starts = [],
      points = [];
    loops.forEach(function (p, i) {
      if (i) starts.push(points.length);
      p.forEach(function (q) {
        points.push(q);
        flat.push.apply(flat, _toConsumableArray(q));
      });
    });
    var triangles = conformTriangles(points, ec.default(flat, starts, 2),surfaceTolerance);
    if (ec.deviation(flat, starts, 2, triangles) > 1e-7) throw Error('Biên dạng không dựng được mặt kín.');
    return {
      loops: loops,
      points: points,
      triangles: triangles
    };
  }
  function build(input) {
    var c = normalize(input),
      w = c.width,
      h = c.height;
    var outer = [[0, 0], [w, 0], [w, h], [0, h]];
    if (c.outline === 'arch') {
      var rise = Math.min(w / 2, h * .35);
      outer = [[0, 0], [w, 0], [w, h - rise]].concat(Array.from({
        length: 33
      }, function (_, i) {
        return [w / 2 + w / 2 * Math.cos(Math.PI * i / 32), h - rise + rise * Math.sin(Math.PI * i / 32)];
      }));
    }
    if (c.outline === 'custom') {
      var b = bounds(c.custom_outer);
      outer = c.custom_outer.map(function (_ref13) {
        var _ref14 = _slicedToArray(_ref13, 2),
          x = _ref14[0],
          y = _ref14[1];
        return [(x - b.x0) * w / (b.x1 - b.x0), (y - b.y0) * h / (b.y1 - b.y0)];
      });
    }
    outer = validateLoop(outer, 'Viền tấm');
    var cuts = [],
      raised = [],
      warnings = [];
    var _iterator = _createForOfIteratorHelper(c.inserts),
      _step;
    try {
      var _loop2 = function _loop2() {
          var item = _step.value;
          var p = transformed(shape(item.pattern), item.size, item.size, item.x, item.y, item.angle, false);
          if (!fits(p, outer, Math.max(2, c.web))) {
            warnings.push('Một họa tiết nằm sát hoặc ngoài viền; đã bỏ qua.');
            return 0;
          }
          if (cuts.concat(raised.map(function (r) {
            return r.loop;
          })).some(function (q) {
            return !separated(p, q, c.web);
          })) {
            warnings.push('Hai họa tiết quá gần nhau; đã bỏ qua một mẫu.');
            return 0;
          }
          if (item.mode === 'raised') raised.push({
            loop: p,
            depth: item.depth
          });else cuts.push(p);
        },
        _ret2;
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        _ret2 = _loop2();
        if (_ret2 === 0) continue;
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    var iw = w - 2 * c.frame,
      ih = h - 2 * c.frame,
      nx = Math.max(1, Math.floor(iw / c.module)),
      ny = Math.max(1, Math.floor(ih / c.module)),
      cw = iw / nx,
      ch = ih / ny;
    if (nx * ny > 500) throw Error('Quá 500 ô hoa văn. Tăng kích thước mô-đun.');
    if (c.pattern !== 'solid' && Math.min(cw, ch) <= c.web + 3) throw Error('Mô-đun quá nhỏ so với bề rộng nan.');
    var reserved = cuts.concat(raised.map(function (r) {
      return r.loop;
    }));
    if (c.pattern !== 'solid') for (var row = 0; row < ny; row++) {
      var _loop = function _loop() {
          if (c.region === 'border' && row !== 0 && row !== ny - 1 && col !== 0 && col !== nx - 1) return 0;
          if (c.region === 'center' && (row === 0 || row === ny - 1 || col === 0 || col === nx - 1)) return 0;
          if (c.region === 'vertical' && col !== Math.floor(nx / 2)) return 0;
          if (c.region === 'horizontal' && row !== Math.floor(ny / 2)) return 0;
          var p = transformed(shape(c.pattern), cw - c.web, ch - c.web, c.frame + (col + .5) * cw + c.offset_x, c.frame + (row + .5) * ch + c.offset_y, c.rotation, c.mirror);
          if (fits(p, outer, c.frame) && reserved.every(function (q) {
            return separated(p, q, c.web);
          })) cuts.push(p);
        },
        _ret;
      for (var col = 0; col < nx; col++) {
        _ret = _loop();
        if (_ret === 0) continue;
      }
    }
    var mesh = triangulate(outer, cuts),
      net = Math.abs(area(outer)) - cuts.reduce(function (sum, p) {
        return sum + Math.abs(area(p));
      }, 0);
    if (mesh.points.length > 35000) throw Error('Mẫu quá nhiều điểm. Tăng kích thước mô-đun.');
    return {
      config: c,
      mesh: mesh,
      raised: raised.map(function (r) {
        return {
          mesh: triangulate(r.loop, []),
          depth: r.depth
        };
      }),
      width: w,
      height: h,
      thickness: c.thickness,
      holes: cuts.length,
      area: net,
      volume: net * c.thickness,
      warnings: _toConsumableArray(new Set(warnings))
    };
  }
  function path(p) {
    return 'M' + p.map(function (q) {
      return q.map(function (v) {
        return Number(v.toFixed(4));
      }).join(',');
    }).join('L') + 'Z';
  }
  function svg(data) {
    var w = data.width,
      h = data.height;
    var out = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + 'mm" height="' + h + 'mm" viewBox="0 0 ' + w + ' ' + h + '"><g transform="translate(0 ' + h + ') scale(1 -1)">';
    data.mesh.loops.forEach(function (p, i) {
      return out += '<path id="' + (i ? 'cut-' + i : 'outline') + '" d="' + path(p) + '" fill="none" stroke="' + (i ? '#d63031' : '#111') + '" stroke-width="0.2"/>';
    });
    data.raised.forEach(function (r, i) {
      return out += '<path id="relief-' + i + '" d="' + path(r.mesh.loops[0]) + '" fill="none" stroke="#1976d2" stroke-width="0.2"/>';
    });
    return out + '</g></svg>';
  }
  function dxf(data) {
    var s = ['0', 'SECTION', '2', 'HEADER', '9', '$INSUNITS', '70', '4', '0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES'];
    var add = function add(p, layer) {
      s.push('0', 'LWPOLYLINE', '100', 'AcDbEntity', '8', layer, '100', 'AcDbPolyline', '90', String(p.length), '70', '1');
      p.forEach(function (_ref15) {
        var _ref16 = _slicedToArray(_ref15, 2),
          x = _ref16[0],
          y = _ref16[1];
        return s.push('10', x.toFixed(4), '20', y.toFixed(4));
      });
    };
    data.mesh.loops.forEach(function (p, i) {
      return add(p, i ? 'CUT' : 'OUTLINE');
    });
    data.raised.forEach(function (r) {
      return add(r.mesh.loops[0], 'RELIEF');
    });
    s.push('0', 'ENDSEC', '0', 'EOF');
    return s.join('\r\n') + '\r\n';
  }
  root.LofiCNCGeometry = {
    catalog: catalog,
    defaults: defaults,
    normalize: normalize,
    shape: shape,
    build: build,
    area: area,
    path: path,
    svg: svg,
    dxf: dxf,
    validateLoop: validateLoop,
    bounds: bounds,
    separated: separated,
    fits: fits,
    triangulate: triangulate
  };
})(typeof window === 'undefined' ? globalThis : window);
