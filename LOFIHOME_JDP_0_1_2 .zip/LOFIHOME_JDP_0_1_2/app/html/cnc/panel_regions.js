(function(root){
  'use strict';
  var P=root.LofiCNCPanel,G=root.LofiCNCGeometry,C=root.ClipperLib,S=10000;
  var normalizeOne=P.normalize,buildOne=P.build;
  function clone(v){return JSON.parse(JSON.stringify(v));}
  function paths(loops){return loops.map(function(l){return l.map(function(p){return {X:Math.round(p[0]*S),Y:Math.round(p[1]*S)};});});}
  function loops(p){return p.map(function(l){return l.map(function(v){return [v.X/S,v.Y/S];});});}
  function boolean(a,b,type){
    if(!a.length)return type==='union'?b:[];
    if(!b.length&&type!=='union')return type==='difference'?a:[];
    var clip=new C.Clipper(C.Clipper.ioStrictlySimple),out=[];
    clip.AddPaths(a,C.PolyType.ptSubject,true);if(b.length)clip.AddPaths(b,C.PolyType.ptClip,true);
    if(!clip.Execute(C.ClipType['ct'+type[0].toUpperCase()+type.slice(1)],out,C.PolyFillType.pftNonZero,C.PolyFillType.pftNonZero))throw Error('Không ghép được các vùng.');
    return out;
  }
  function area(p){return Math.abs(p.reduce(function(a,l){return a+C.Clipper.Area(l);},0))/S/S;}
  function winding(l,positive){return (G.area(l)>0)===positive?l:l.slice().reverse();}
  function shape(r){return paths([winding(r.outer,true)].concat(r.holes.map(function(h){return winding(h,false);})));}
  function contains(p,loop){return C.Clipper.PointInPolygon({X:Math.round(p[0]*S),Y:Math.round(p[1]*S)},paths([loop])[0])!==0;}
  function boundedCells(packet){
    var input=packet.segments;
    if(!Array.isArray(input)||input.length>4000)throw Error('Tối đa 4000 đoạn line cho một lần đọc vùng.');
    var segments=[],seen={};
    input.forEach(function(s){
      if(!Array.isArray(s)||s.length!==2||s.some(function(p){return !Array.isArray(p)||p.length!==2||p.some(function(v){return !Number.isFinite(v);});}))throw Error('Line không hợp lệ.');
      var key=s.map(function(p){return p.map(function(v){return Math.round(v*S);}).join(',');}).sort().join('|');
      if(seen[key]||Math.hypot(s[0][0]-s[1][0],s[0][1]-s[1][1])<.0001)return;
      seen[key]=true;segments.push({a:s[0],b:s[1],ts:[0,1]});
    });
    function sub(a,b){return [a[0]-b[0],a[1]-b[1]];}
    function cross(a,b){return a[0]*b[1]-a[1]*b[0];}
    function dot(a,b){return a[0]*b[0]+a[1]*b[1];}
    function add(s,t){if(t>=-1e-8&&t<=1+1e-8)s.ts.push(Math.max(0,Math.min(1,t)));}
    for(var i=0;i<segments.length;i++)for(var j=i+1;j<segments.length;j++){
      var a=segments[i],b=segments[j],u=sub(a.b,a.a),v=sub(b.b,b.a),d=sub(b.a,a.a),den=cross(u,v);
      if(Math.abs(den)>1e-10){var t=cross(d,v)/den,q=cross(d,u)/den;if(t>=-1e-8&&t<=1+1e-8&&q>=-1e-8&&q<=1+1e-8){add(a,t);add(b,q);}}
      else if(Math.abs(cross(d,u))<.00001*Math.hypot(u[0],u[1])){
        add(a,dot(d,u)/dot(u,u));add(a,dot(sub(b.b,a.a),u)/dot(u,u));
        add(b,dot(sub(a.a,b.a),v)/dot(v,v));add(b,dot(sub(a.b,b.a),v)/dot(v,v));
      }
    }
    var nodes=[],indices={},edges=[],edgeKeys={};
    function node(p){var key=p.map(function(v){return Math.round(v*S);}).join(',');if(indices[key]===undefined){indices[key]=nodes.length;nodes.push({p:key.split(',').map(function(v){return Number(v)/S;}),links:[]});}return indices[key];}
    segments.forEach(function(s){
      var ts=s.ts.sort(function(a,b){return a-b;}).filter(function(v,i,a){return !i||v-a[i-1]>1e-9;});
      for(var k=1;k<ts.length;k++){
        var ends=[ts[k-1],ts[k]].map(function(t){return node([s.a[0]+(s.b[0]-s.a[0])*t,s.a[1]+(s.b[1]-s.a[1])*t]);});
        if(ends[0]===ends[1])continue;var key=ends.slice().sort(function(a,b){return a-b;}).join(':');if(edgeKeys[key])continue;
        edgeKeys[key]=true;var id=edges.length;edges.push(ends);ends.forEach(function(n){nodes[n].links.push(id);});
      }
    });
    // A dangling line or bridge has no enclosed area. Keep it out of the face
    // walk, without extending it or changing the user's original drawing.
    var discovery=[],low=[],time=0,bridges={};
    function visit(n,parent){discovery[n]=low[n]=++time;nodes[n].links.forEach(function(e){if(e===parent)return;var pair=edges[e],m=pair[0]===n?pair[1]:pair[0];if(!discovery[m]){visit(m,e);low[n]=Math.min(low[n],low[m]);if(low[m]>discovery[n])bridges[e]=true;}else low[n]=Math.min(low[n],discovery[m]);});}
    nodes.forEach(function(_,n){if(!discovery[n])visit(n,-1);});
    var links=nodes.map(function(node,n){return node.links.filter(function(e){return !bridges[e];}).map(function(e){return edges[e][0]===n?edges[e][1]:edges[e][0];}).sort(function(a,b){return Math.atan2(nodes[a].p[1]-node.p[1],nodes[a].p[0]-node.p[0])-Math.atan2(nodes[b].p[1]-node.p[1],nodes[b].p[0]-node.p[0]);});});
    var walked={},cycles=[];
    links.forEach(function(list,a){list.forEach(function(b){
      if(walked[a+':'+b])return;var u=a,v=b,ring=[],guard=0;
      do{walked[u+':'+v]=true;ring.push(nodes[u].p);var next=links[v],w=next[(next.indexOf(u)+next.length-1)%next.length];u=v;v=w;if(++guard>edges.length*2)throw Error('Không khép được vùng.');}while(u!==a||v!==b);
      if(G.area(ring)>.001)cycles.push(G.validateLoop(ring,'Vùng chia bằng line'));
    });});
    var regions=cycles.map(function(outer,i){
      var children=cycles.filter(function(h,j){return j!==i&&Math.abs(G.area(h))<Math.abs(G.area(outer))&&G.fits(h,outer,.00001);});
      children=children.filter(function(h){return !children.some(function(other){return h!==other&&Math.abs(G.area(other))>Math.abs(G.area(h))&&G.fits(h,other,.00001);});});
      return {outer:winding(outer,true),holes:children.map(function(h){return winding(h,false);})};
    });
    var masks=(packet.faces||[]).map(function(f){return paths(f.map(function(l,i){return winding(l,i===0);}));}).reduce(function(a,b){return boolean(a,b,'union');},[]);
    if(masks.length)regions=regions.filter(function(r){return area(boolean(shape(r),masks,'intersection'))>area(shape(r))-.001;});
    if(!regions.length)throw Error('Chưa có vùng kín. Nối line tới đường biên rồi đọc lại.');
    if(regions.length>64)throw Error('Tối đa 64 vùng; chọn ít vùng hơn.');
    regions.sort(function(a,b){var x=G.bounds(a.outer),y=G.bounds(b.outer);return y.y1-x.y1||x.x0-y.x0;});
    return {regions:regions,ignored_lines:Object.keys(bridges).length};
  }
  function normalize(input){
    input=input||{};
    if(input.custom_regions===undefined)return normalizeOne(input);
    var plain=Object.assign({},input);delete plain.custom_regions;
    var c=normalizeOne(plain),rs=input.custom_regions;
    if(c.outline!=='custom'||!Array.isArray(rs)||!rs.length||rs.length>64)throw Error('Bản chia vùng không hợp lệ.');
    var basis=input.region_basis;
    if(input.region_panel!==undefined && (input.region_panel!==true || rs.length!==1 || input._region_local!==true))throw Error('Thông số tấm tách vùng không hợp lệ.');
    if(!Array.isArray(basis)||basis.length!==2||basis.some(function(v){return !Number.isFinite(v)||v<(input.region_panel===true?1:50)||v>10000;}))throw Error('Kích thước gốc của vùng không hợp lệ.');
    c.region_basis=basis.slice();var ids={},occupied=[];
    c.custom_regions=rs.map(function(r,i){
      if(!r||typeof r.id!=='string'||ids[r.id])throw Error('Mã vùng bị trùng hoặc không hợp lệ.');ids[r.id]=true;
      var outer=G.validateLoop(r.outer,'Biên vùng '+(i+1)),holes=(r.holes||[]).map(function(h){return G.validateLoop(h,'Lỗ trong vùng');}),box=G.bounds(outer);
      if(box.x0<-.001||box.y0<-.001||box.x1>basis[0]+.001||box.y1>basis[1]+.001)throw Error('Vùng nằm ngoài bản vẽ.');
      var region={id:r.id,outer:outer,holes:holes},current=shape(region);
      if(area(boolean(current,occupied,'intersection'))>.001)throw Error('Các vùng chồng diện tích lên nhau.');occupied=boolean(occupied,current,'union');
      if(!r.config||r.config.custom_regions!==undefined)throw Error('Thông số vùng không hợp lệ.');
      region.config=normalizeOne(localConfig(c,region,r.config));return region;
    });
    if(c.custom_regions.reduce(function(n,r){return n+r.outer.length+r.holes.reduce(function(a,h){return a+h.length;},0);},0)>12000)throw Error('Các vùng quá nhiều điểm.');
    return c;
  }
  function placement(master,x,y){
    var p=master.custom_placement;if(!Array.isArray(p))return undefined;p=p.slice();
    for(var i=0;i<3;i++)p[12+i]+=(p[i]*x+p[4+i]*y)/25.4;return p;
  }
  function localConfig(master,r,settings){
    var box=G.bounds(r.outer),sx=master.width/master.region_basis[0],sy=master.height/master.region_basis[1];
    function shift(l){return l.map(function(p){return [(p[0]-box.x0)*sx,(p[1]-box.y0)*sy];});}
    var c=Object.assign({},settings,{_region_local:true,outline:'custom',custom_outer:shift(r.outer),custom_holes:r.holes.map(shift),
      width:(box.x1-box.x0)*sx,height:(box.y1-box.y0)*sy,thickness:master.thickness,plane:master.plane,material:master.material,
      custom_place:master.custom_place,custom_placement:placement(master,box.x0*sx,box.y0*sy),custom_fill_inner:false,custom_lock:true});
    delete c.custom_regions;delete c.region_basis;delete c.region_panel;return c;
  }
  function fromCapture(packet,seed){
    var captured=boundedCells(packet),bounds=G.bounds(captured.regions.reduce(function(a,r){return a.concat(r.outer);},[])),w=bounds.x1-bounds.x0,h=bounds.y1-bounds.y0;
    var capturedPlacement=placement({custom_placement:packet.placement},bounds.x0,bounds.y0);
    captured.regions.forEach(function(r){function shift(l){return l.map(function(p){return [p[0]-bounds.x0,p[1]-bounds.y0];});}r.outer=shift(r.outer);r.holes=r.holes.map(shift);});
    var doc=Object.assign({},seed,{outline:'custom',width:w,height:h,thickness:packet.thickness||seed.thickness,
      custom_outer:[[0,0],[w,0],[w,h],[0,h]],custom_holes:[],custom_fill_inner:false,custom_placement:capturedPlacement,
      custom_place:!!packet.placement,custom_source:packet.source,region_basis:[w,h],custom_regions:[],items:[],mode:'solid'});
    delete doc._region_local;delete doc.region_panel;delete doc.border;delete doc.custom_frame_adjust;delete doc.custom_frame_sides;
    doc.custom_regions=captured.regions.map(function(r,i){var box=G.bounds(r.outer),limit=Math.min(box.x1-box.x0,box.y1-box.y0)/4;var settings=Object.assign({},seed,{name:'Vùng '+(i+1),mode:'solid',items:[],frame_equal:true,frame:Math.min(seed.frame,limit),margin:Math.min(seed.margin,limit),equal_margins:true});delete settings.border;delete settings.custom_frame_adjust;delete settings.custom_frame_sides;delete settings.custom_regions;delete settings.region_basis;delete settings.region_panel;return Object.assign(r,{id:'region-'+(i+1),config:settings});});
    return {config:normalize(doc),ignored_lines:captured.ignored_lines};
  }
  function assets(c){
    var list=c.custom_regions?c.custom_regions.map(function(r){return r.config;}):[c];
    return Array.from(new Set(list.reduce(function(a,s){return a.concat([s.id],s.border&&s.border.enabled?[s.border.id]:[],s.items.map(function(i){return i.id;}));},[])));
  }
  function build(input,models,meshRequired){
    input=input||{};
    if(input.custom_regions===undefined)return buildOne(input,models,meshRequired);
    var c=normalize(input),layers={},regionResults=[],warnings=[],sx=c.width/c.region_basis[0],sy=c.height/c.region_basis[1];
    var wallIndex=meshRequired===false ? null : P.insertWallIndex();
    c.custom_regions.forEach(function(r){
      var box=G.bounds(r.outer),dx=box.x0*sx,dy=box.y0*sy;
      var built=buildOne(r.config,models,false,wallIndex && function(paths,z){wallIndex.record(paths,z,dx,dy);});
      regionResults.push({id:r.id,result:built,x:dx,y:dy});
      (built.clearance_warnings || []).forEach(function(message){warnings.push((r.config.name || r.id)+' · '+message);});
      built.contours.forEach(function(s){
        var key=s.z+':'+s.depth,layer=layers[key]||(layers[key]={z:s.z,depth:s.depth,paths:[]});
        var moved=s.loops.map(function(l){return l.map(function(p){return [p[0]+dx,p[1]+dy];});});
        // Every operation is bounded by the chosen region, including union,
        // background and raised motifs that previously could cross its edge.
        var boundary=shape({outer:r.outer.map(function(p){return [p[0]*sx,p[1]*sy];}),holes:r.holes.map(function(l){return l.map(function(p){return [p[0]*sx,p[1]*sy];});})});
        layer.paths=boolean(layer.paths,boolean(paths(moved),boundary,'intersection'),'union');
      });
    });
    var selective=c.custom_regions.some(function(r){return r.config.items.some(function(i){return !!i.inner_gap;});});
    var hasRing=c.custom_regions.some(function(r){return r.config.items.some(function(i){return i.even_insert || i.inner_gap_scope==='rim' || i.inner_rim_mm!==undefined || i.outer_rim_mm!==undefined;});});
    var solids=[],contours=[],points=0,holes=0,volume=0;
    Object.keys(layers).forEach(function(key){var layer=layers[key];
      P.parts(layer.paths).forEach(function(p){contours.push({loops:[p.outer].concat(p.holes),z:layer.z,depth:layer.depth});holes+=p.holes.length;});
      P.solidParts(layer.paths).forEach(function(p){
      var ls=[p.outer].concat(p.holes),n=ls.reduce(function(a,l){return a+l.length;},0),a=Math.abs(G.area(p.outer))-p.holes.reduce(function(a,h){return a+Math.abs(G.area(h));},0);
      if(a<.0001)return;points+=n;
      if(points>35000||solids.length>=1024)throw Error('Toàn bộ bản vẽ quá nhiều chi tiết. Tăng cỡ hoa văn hoặc giảm số vùng.');
      var mesh=meshRequired===false?null:G.triangulate(p.outer,p.holes);
      if(mesh){mesh.triangulate_sides=true;if(selective)mesh.alternate_short_sides=true;if(hasRing)mesh.contour_prism=true;}
      if(wallIndex)wallIndex.mark(mesh,layer.z);
      solids.push({loops:ls,mesh:mesh,z:layer.z,depth:layer.depth,area:a});volume+=a*layer.depth;
    });});
    if(!solids.length)throw Error('Các vùng không còn vật liệu.');
    return {config:c,width:c.width,height:c.height,thickness:c.thickness,solids:solids,contours:contours,holes:holes,points:points,volume:volume,tiles:0,
      base_count:solids.filter(function(s){return s.z===0;}).length,region_count:solids.length,warnings:warnings,region_results:regionResults};
  }
  // Native creation keeps one independently editable root Group per region.
  // Build each panel through the same regional clipping path, including motifs
  // crossing an edge. A one-region document retains that clipping on later edits.
  function separatePanels(input,models){
    var c=normalize(input);
    if(!c.custom_regions || c.region_panel===true)return null;
    return c.custom_regions.map(function(r){
      var local=clone(r.config),single=clone(local);
      single.region_panel=true;single.region_basis=[local.width,local.height];
      single.custom_regions=[{id:r.id,outer:clone(local.custom_outer),holes:clone(local.custom_holes),config:local}];
      var built=build(single,models,true);delete built.region_results;
      built.region_id=r.id;return built;
    });
  }
  P.normalize=normalize;P.build=build;
  root.LofiPanelRegions={capture:fromCapture,cells:boundedCells,localConfig:localConfig,assets:assets,build:build,clone:clone,separatePanels:separatePanels};
})(typeof window==='undefined'?globalThis:window);
