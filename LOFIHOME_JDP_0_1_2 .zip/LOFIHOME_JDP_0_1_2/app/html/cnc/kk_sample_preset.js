(function(){
 'use strict';
 var id='patterns__vach_anh_kk',entry=(window.LofiOriginalCNCCatalog||[]).find(function(e){return e.id===id;});
 var title=document.getElementById('panelTitle');if(!entry||!title||!window.LofiPanelUI)return;
 var applying=false,editing=false;
 function config(){return LofiPanelUI.getConfig();}
 function apply(c){if(applying)return;applying=true;try{lofiCNCReply({type:'panel_config',config:c});}finally{applying=false;}show();}
 function preset(){apply(JSON.parse(JSON.stringify(entry.panel_preset)));}
 var button=document.getElementById('sourcePanelPreset');
 if(!button){button=document.createElement('button');button.id='kkPanelPreset';button.textContent='Nạp mẫu KK đúng tỷ lệ ảnh';button.onclick=preset;title.after(button);}
 var width=document.querySelector('[data-panel="width"]'),height=document.querySelector('[data-panel="height"]');
 var box=document.createElement('div');box.id='kkRatioOptions';box.style.cssText='margin:8px 0;padding:9px;border:1px solid #bbdacf;border-radius:5px;background:#f2faf6';
 var label=document.createElement('label'),lock=document.createElement('input');lock.type='checkbox';lock.id='kkKeepRatio';label.appendChild(lock);label.appendChild(document.createTextNode(' Giữ tỷ lệ ảnh mẫu KK'));
 var note=document.createElement('small');note.style.display='block';note.textContent='Một vách nguyên mẫu. Đổi rộng/cao sẽ co giãn cùng nhau. Khung gốc đã có trong mẫu; Rộng khung dùng để thêm viền.';box.appendChild(label);box.appendChild(note);
 width.closest('.fields').after(box);
 function show(){var c=config(),active=c.id===id;box.hidden=!active;if(button.id==='kkPanelPreset')button.hidden=!active;lock.checked=c.kk_lock_ratio!==false;
  var module=document.querySelector('[data-panel="module"]');if(active){if(!module.dataset.kkPreviousDisabled)module.dataset.kkPreviousDisabled=module.disabled?'yes':'no';module.disabled=true;}else if(module.dataset.kkPreviousDisabled){module.disabled=module.dataset.kkPreviousDisabled==='yes';delete module.dataset.kkPreviousDisabled;}
 }
 lock.onchange=function(){var c=config();c.kk_lock_ratio=lock.checked;if(lock.checked)c.width=+(c.height*entry.width/entry.height).toFixed(4);apply(c);};
 document.addEventListener('input',function(e){
  if(editing||applying||(e.target!==width&&e.target!==height))return;
  var c=config();if(c.id!==id||c.kk_lock_ratio===false)return;
  var n=Number(e.target.value);if(!(n>0))return;
  var other=e.target===width?height:width,value=e.target===width?n*entry.height/entry.width:n*entry.width/entry.height;
  editing=true;try{other.value=+value.toFixed(4);other.dispatchEvent(new Event('input',{bubbles:true}));}finally{editing=false;}
 },true);
 window.addEventListener('lofi-source-select',function(e){if(e.detail.item.id===id&&!e.detail.loaded&&!applying)preset();show();});
 window.addEventListener('lofi-cnc-reply',function(e){if(e.detail.type==='panel_config')show();});
 var reset=document.getElementById('panelReset'),oldReset=reset.onclick;
 reset.onclick=function(e){if(config().id===id)preset();else if(oldReset)oldReset.call(this,e);};
 show();
})();
