/* Equal cutter channels and material bridges for a circular repeating fret.
   Work in physical XY coordinates; only replace the two recognized rows of
   voids. The outside silhouette and everything inside the band stay intact. */
(function(root){
  'use strict';
  var G=root.LofiCNCGeometry,C=root.ClipperLib,S=10000,turn=2*Math.PI;
  function wrap(a){return a-turn*Math.floor((a+Math.PI)/turn);}
  function average(values){return values.reduce(function(a,b){return a+b;},0)/values.length;}
  function bounds(loop){return G.bounds(loop);}
  function crossings(loop,r){
    var angles=[];
    loop.forEach(function(p,i){
      var q=loop[(i+1)%loop.length],dx=q[0]-p[0],dy=q[1]-p[1],a=dx*dx+dy*dy;
      if(!a)return;
      var b=p[0]*dx+p[1]*dy,c=p[0]*p[0]+p[1]*p[1]-r*r,disc=b*b-a*c;
      if(disc<=0)return;
      [-1,1].forEach(function(sign){
        var t=(-b+sign*Math.sqrt(disc))/a;
        if(t>=0 && t<1)angles.push(Math.atan2(p[1]+t*dy,p[0]+t*dx));
      });
    });
    return angles;
  }
  function midpoint(loop,r){
    var a=crossings(loop,r);
    return a.length===2?a[0]+wrap(a[1]-a[0])/2:null;
  }
  function identify(parts){
    var all=parts.flatMap(function(p){return p.outer;}),b=bounds(all),w=b.x1-b.x0,h=b.y1-b.y0;
    if(Math.abs(w-h)>.012*Math.max(w,h))return null;
    var center=[(b.x1+b.x0)/2,(b.y1+b.y0)/2],radius=(w+h)/4,rows=[];
    parts.forEach(function(p){p.holes.forEach(function(hole){
      var local=hole.map(function(v){return [v[0]-center[0],v[1]-center[1]];});
      var lengths=local.map(function(v){return Math.hypot(v[0],v[1]);});
      rows.push({hole:hole,local:local,lo:Math.min.apply(null,lengths),hi:Math.max.apply(null,lengths)});
    });});
    rows.sort(function(a,b){return b.hi-a.hi;});
    if(!rows.length || rows[0].hi<radius*.8)return null;
    var low=rows[0].lo,outer=[];
    for(var row of rows){
      if(row.hi<low-radius*.001)break;
      // Tiny contour fragments near the inner rim (078) are not fret lanes.
      if(row.hi-row.lo<radius*.006)continue;
      outer.push(row);low=Math.min(low,row.lo);
    }
    if(low<radius*.45 || outer.length<6)return null;
    var families=[];
    for(var entry of outer){
      var family=families.find(function(f){return Math.abs(f[0].lo-entry.lo)<.007*radius && Math.abs(f[0].hi-entry.hi)<.007*radius;});
      if(!family){family=[];families.push(family);}family.push(entry);
    }
    families.sort(function(a,b){return a[0].lo-b[0].lo;});
    if(families.length!==2 || families[0].length!==families[1].length || families[0].length<3)return null;
    var pitch=turn/families[0].length;
    for(var f of families){
      for(var e of f){
        e.spoke=midpoint(e.local,(e.lo+e.hi)/2);
        if(e.spoke===null)return null;
        var inset=(e.hi-e.lo)*.08;
        e.lower=midpoint(e.local,e.lo+inset);e.upper=midpoint(e.local,e.hi-inset);
        if(e.lower===null || e.upper===null)return null;
      }
      f.sort(function(a,b){return a.spoke-b.spoke;});
      var phase=average(f.map(function(e,i){return e.spoke-i*pitch;}));
      if(f.some(function(e,i){return Math.abs(wrap(e.spoke-phase-i*pitch))>pitch*.08;}))return null;
      f.phase=phase;
      f.lowerOffset=average(f.map(function(e){return wrap(e.lower-e.spoke);}));
      f.upperOffset=average(f.map(function(e){return wrap(e.upper-e.spoke);}));
    }
    return {center:center,families:families,pitch:pitch,lo:Math.min.apply(null,outer.map(function(e){return e.lo;})),hi:outer[0].hi};
  }
  function xy(center,r,t){return [center[0]+r*Math.cos(t),center[1]+r*Math.sin(t)];}
  function arc(center,r,from,to){
    var step=2*Math.acos(1-Math.min(.004/r,.1)),n=Math.max(1,Math.ceil((to-from)/step));
    return Array.from({length:n+1},function(_,i){return xy(center,r,from+(to-from)*i/n);});
  }
  function intervals(r,spoke,offset,otherPhase,pitch,dist){
    var mid=spoke+offset,start,end;
    if(otherPhase===null){
      var separation=2*Math.asin(dist/(2*r)),half=(pitch-separation)/2;
      mid=spoke+Math.max(-half,Math.min(half,offset));
      start=mid-half;end=mid+half;
    }else{
      var left=otherPhase+Math.floor((mid-otherPhase)/pitch)*pitch;
      var separation=Math.asin(dist/r);
      start=left+separation;end=left+pitch-separation;
    }
    if(!Number.isFinite(start+end) || end<=start || spoke<start-.00001 || spoke>end+.00001)return null;
    return [start,end];
  }
  function outline(center,radii,spoke,lower,upper,width){
    var off=new C.ClipperOffset(2,.002*S);
    [arc(center,radii[0],lower[0],lower[1]),arc(center,radii[1],upper[0],upper[1]),
     [xy(center,radii[0],spoke),xy(center,radii[1],spoke)]].forEach(function(line){
      off.AddPath(line.map(function(p){return {X:Math.round(p[0]*S),Y:Math.round(p[1]*S)};}),C.JoinType.jtRound,C.EndType.etOpenRound);
    });
    var out=[];off.Execute(out,width*S/2);
    return out.length===1?out[0].map(function(p){return [p.X/S,p.Y/S];}):null;
  }
  function radialRange(loop,c){
    var near=Infinity,far=0;
    loop.forEach(function(a,i){
      var b=loop[(i+1)%loop.length],x=a[0]-c[0],y=a[1]-c[1],dx=b[0]-a[0],dy=b[1]-a[1];
      var u=Math.max(0,Math.min(1,-(x*dx+y*dy)/(dx*dx+dy*dy || 1)));
      near=Math.min(near,Math.hypot(x+u*dx,y+u*dy));far=Math.max(far,Math.hypot(x,y));
    });
    return [near,far];
  }
  function bandStart(parts,info,required,bridge){
    var ring=new Set(info.families.flatMap(function(row){return row.map(function(e){return e.hole;});}));
    var host=parts.find(function(p){return p.holes.some(function(h){return ring.has(h);});});
    if(!host || !Array.from(ring).every(function(h){return host.holes.includes(h);}))return null;
    var lo=0,hi=radialRange(host.outer,info.center)[0];
    // Keep all central cuts, islands and the original outside silhouette.
    for(var hole of host.holes){
      if(ring.has(hole))continue;
      var limits=radialRange(hole,info.center);
      if(limits[1]<info.lo+.02)lo=Math.max(lo,limits[1]);
      else if(limits[0]>info.hi-.02)hi=Math.min(hi,limits[0]);
      else return null;
    }
    var spare=hi-lo-required;if(spare<.1)return null;
    var margin=Math.min(bridge,spare/2);
    return Math.max(lo+margin,Math.min(hi-margin-required,(info.lo+info.hi-required)/2));
  }
  function fretArc(c,r,from,to){
    const step=2*Math.acos(1-.004/r),n=Math.max(1,Math.ceil(Math.abs(to-from)/step));
    return Array.from({length:n+1},(_,i)=>xy(c,r,from+(to-from)*i/n).map(x=>Math.round(x*S)/S));
  }
  // A square-ended H is bounded by four pairs of concentric arcs. The sides of
  // its spoke and the neighbouring end caps are PARALLEL lines in XY. A radial
  // wedge instead would taper with radius. Intersect each line with each arc.
  function fretOutline(c,spoke,base,width,bridge,levels,ends) {
    const [bottom,top] = levels.map(k=>base+k*(width+bridge));
    const side = (r,sign)=>spoke+sign*Math.asin(width/(2*r));
    function end(row,r,i) {
      const e=ends[row];
      return e.seams[i]+(i===0?1:-1)*Math.asin(e.distance/r);
    }
    for(const [lane,r] of [[0,bottom+width],[1,top]]){
      if(!(end(lane,r,0)<side(r,-1) && side(r,1)<end(lane,r,1)))return null;
    }
    const edges = [
      fretArc(c,bottom,end(0,bottom,0),end(0,bottom,1)),
      fretArc(c,bottom+width,end(0,bottom+width,1),side(bottom+width,1)),
      fretArc(c,top,side(top,1),end(1,top,1)),
      fretArc(c,top+width,end(1,top+width,1),end(1,top+width,0)),
      fretArc(c,top,end(1,top,0),side(top,-1)),
      fretArc(c,bottom+width,side(bottom+width,-1),end(0,bottom+width,0))
    ];
    const loop=edges.flat();
    return G.area(loop)<0?loop:loop.reverse();
  }
  function squareBand(f,base,width,bridge) {
    const replaced=new Map();
    const {pitch,center,families} = f;
    // Put each spoke halfway between its two opposite neighbours. Split the
    // angular correction so the pair retains its original mean orientation.
    const phases=families.map(row=>row.phase);
    let delta=phases[1]-phases[0];delta-=pitch*Math.round(delta/pitch);
    const minPhase=Math.asin((width/2+bridge)/(base+width+bridge))+Math.asin(width/2/(base+width+bridge))+.00005;
    if(minPhase>=pitch/2)return null;
    const shift=(Math.sign(delta||1)*pitch/2-delta)/2;
    phases[0]-=shift;phases[1]+=shift;
    families.forEach((family,j)=>{
      family.forEach((row,i)=>{
        const spoke=phases[j]+i*pitch;
        const ends=[0,1].map(lane=>{
          if(lane===j) {
            return {seams:[spoke-pitch/2,spoke+pitch/2],distance:bridge/2};
          }
          const other=phases[1-j],left=other+Math.floor((spoke-other)/pitch)*pitch;
          return {seams:[left,left+pitch],distance:width/2+bridge};
        });
        replaced.set(row.hole,fretOutline(center,spoke,base,width,bridge,[j,j+2],ends));
      });
    });
    if(Array.from(replaced.values()).some(loop=>!loop))return null;
    return {map:replaced,phases:phases};
  }

  function setup(parts,info,gap,requested,kit,square){
    var width=gap+.016,bridge=requested+.008,required=4*width+3*bridge;
    var start=bandStart(parts,info,required,requested);if(start===null)return null;
    var distance=width+bridge,base=start+width/2,map=new Map();
    // As the physical band grows, the equal material bridge grows too.
    // Keep both spokes far enough apart at the innermost shared lane, and
    // distribute any phase correction symmetrically across the two rows.
    if(square){
      var band=squareBand(info,start,width,bridge);
      if(!band)return null;
      map=band.map;
    }else{
      var phase=info.families.map(function(f){return f.phase;});
      var delta=phase[1]-phase[0];delta-=info.pitch*Math.round(delta/info.pitch);
      var need=Math.asin(distance/(base+distance))+1e-8;
      if(!(need<info.pitch/2))return null;
      if(Math.abs(delta)<need){
        var shift=(delta<0?-1:1)*(need-Math.abs(delta))/2;
        phase[0]-=shift;phase[1]+=shift;
      }
      for(var family=0;family<2;family++){
        var f=info.families[family],other=phase[1-family];
        var radii=[base+family*distance,base+(family+2)*distance];
        for(var i=0;i<f.length;i++){
          var spoke=phase[family]+i*info.pitch;
          var a=intervals(radii[0],spoke,f.lowerOffset,family?other:null,info.pitch,distance);
          var b=intervals(radii[1],spoke,f.upperOffset,family?null:other,info.pitch,distance);
          if(!a||!b)return null;
          var loop=outline(info.center,radii,spoke,a,b,width);if(!loop)return null;
          map.set(f[i].hole,loop);
        }
      }
    }
    var paths=kit.toPaths(parts.flatMap(function(part){
      return [part.outer].concat(part.holes.map(function(h){var q=map.get(h);return q?(G.area(q)<0?q:q.slice().reverse()):h;}));
    }));
    // Require all original holes and islands, including the central flower.
    var built=kit.parts(paths);
    if(built.length!==parts.length || built.reduce(function(n,p){return n+p.holes.length;},0)!==parts.reduce(function(n,p){return n+p.holes.length;},0))return null;
    return {paths:paths,warnings:[],changed:map.size,bridge:requested};
  }
  function apply(paths,gap,kit,bridge,square){
    bridge=bridge===undefined?6.1:bridge;
    var parts=kit.parts(kit.bool(paths,[],'union')),info=identify(parts);
    if(info){var result=setup(parts,info,gap,bridge,kit,square);if(result)return result;}
    return {paths:paths,changed:0,warnings:[info?'Dải viền không đủ chỗ cho khe '+gap+' mm và cầu nối '+bridge+' mm ở cỡ mẫu này. Đang hiển thị nét gốc.':'Không nhận diện được hai hàng hồi văn lặp trên viền tròn của mẫu này. Đang hiển thị nét gốc; có thể chọn “Khe nhỏ trong toàn mẫu”.']};
  }
  // Measure the material outside and inside the fret band, on the very same
  // physical loops subsequently used for DXF, SKP and panel construction.
  function marginLayout(paths,kit){
    var parts=kit.parts(kit.bool(paths,[],'union'));
    if(!parts.length)return null;
    var host=parts.reduce(function(a,b){return Math.abs(G.area(a.outer))>Math.abs(G.area(b.outer))?a:b;});
    var box=bounds(host.outer),width=box.x1-box.x0,height=box.y1-box.y0;
    if(Math.abs(width-height)>.015*Math.max(width,height))return null;
    var center=[(box.x0+box.x1)/2,(box.y0+box.y1)/2],outside=radialRange(host.outer,center);
    if(outside[0]<outside[1]*.978)return null;
    var holes=host.holes.map(function(loop){return {loop:loop,r:radialRange(loop,center)};});
    holes.sort(function(a,b){return b.r[1]-a.r[1];});
    if(holes.length<4)return null;
    var outerEdge=holes[0].r[1],innerEdge=holes[0].r[0],i=0;
    while(i<holes.length && holes[i].r[1]>=innerEdge-.025){
      innerEdge=Math.min(innerEdge,holes[i].r[0]);i++;
    }
    if(i<3 || i===holes.length || innerEdge<outside[1]*.42)return null;
    var centreHoles=holes.slice(i),opening=centreHoles[0].r[1];
    if(opening<=0 || innerEdge<=opening || outerEdge>=outside[0])return null;
    return {parts:parts,host:host,c:center,band:holes.slice(0,i),centreHoles:centreHoles,
      innerEdge:innerEdge,outerEdge:outerEdge,opening:opening,outside:outside[0]};
  }
  function rayHits(loop,c,ux,uy){
    var near=Infinity,far=-Infinity;
    for(var i=0;i<loop.length;i++){
      var a=loop[i],b=loop[(i+1)%loop.length],ex=b[0]-a[0],ey=b[1]-a[1],den=ux*ey-uy*ex;
      if(Math.abs(den)<1e-10)continue;
      var x=a[0]-c[0],y=a[1]-c[1],t=(x*ey-y*ex)/den,u=(x*uy-y*ux)/den;
      if(t>=0 && u>=0 && u<1){near=Math.min(near,t);far=Math.max(far,t);}
    }
    return [near,far];
  }
  function dimensionRays(layout,measure){
    var c=layout.c,quality={inner:Infinity,outer:Infinity};
    // Prefer separated labels near the top. Choose a direction whose two
    // ticks actually hit material edges, never the middle of a solid bridge.
    for(var j=0;j<96;j++){
      var angle=(j+.37)*turn/96,ux=Math.cos(angle),uy=Math.sin(angle),low=Infinity,high=-Infinity;
      layout.band.forEach(function(h){var r=rayHits(h.loop,c,ux,uy);low=Math.min(low,r[0]);high=Math.max(high,r[1]);});
      if(!Number.isFinite(low))continue;
      var centre=-Infinity;layout.centreHoles.forEach(function(h){centre=Math.max(centre,rayHits(h.loop,c,ux,uy)[1]);});
      var exterior=rayHits(layout.host.outer,c,ux,uy)[0];
      function record(key,a,b,preferred){
        if(!Number.isFinite(a+b))return;
        var error=Math.abs((b-a)-measure[key]);if(error>.08)return;
        var score=Math.abs(wrap(angle-preferred))+error;if(score>=quality[key])return;
        quality[key]=score;measure[key+'Ray']=[xy(c,a,angle),xy(c,b,angle)];
      }
      record('inner',centre,low,turn/9);record('outer',high,exterior,turn*.35);
    }
  }
  function innerLoop(h,layout,target,kit){
    var c=layout.c,delta=target-layout.opening,tol=Math.max(.025,layout.opening*.003);
    if(h.r[1]<layout.opening-tol){
      if(h.r[1]>=target-.03)throw Error('Viền trong sẽ lấn vào chi tiết ở tâm. Giảm bề rộng viền trong.');
      return h.loop;
    }
    if(delta<0){
      // Grow material by clipping the existing opening, including the ends
      // of strokes where they join the rim. All surviving glyph edges stay put.
      if(target<=h.r[0]+.05 || (h.r[1]-h.r[0]>=6.1 && target-h.r[0]<6.1))
        throw Error('Viền trong quá rộng: khe sát vành sẽ khép hoặc hẹp dưới 6,1 mm.');
      var count=Math.max(96,Math.ceil(Math.PI/Math.acos(Math.max(-1,1-.002/target))));
      var circle=Array.from({length:count},function(_,j){return xy(c,target,turn*j/count);});
      var positive=G.area(h.loop)>0?h.loop:h.loop.slice().reverse();
      var clipped=kit.bool(kit.toPaths([positive]),kit.toPaths([circle]),'intersection');
      if(clipped.length!==1)throw Error('Viền trong sẽ làm mất hoặc tách một lỗ. Giảm bề rộng.');
      var loop=clipped[0].map(function(q){return [q.X/S,q.Y/S];});
      return G.area(loop)<0?loop:loop.reverse();
    }
    // Extend only the circular edge and its immediate joins. The interior
    // strokes, separate islands, fret slots and bridges are not rescaled.
    var moved=h.loop.map(function(p){
      var x=p[0]-c[0],y=p[1]-c[1],r=Math.hypot(x,y);
      return r>=layout.opening-tol?[c[0]+x*(1+delta/r),c[1]+y*(1+delta/r)]:p;
    });
    if(G.area(moved)*G.area(h.loop)<=0)throw Error('Viền trong không giữ được đường bao kín.');
    return moved;
  }
  function scaleCentre(layout, target, replaced) {
    var centre = layout.c, factor = target / layout.opening;
    function scale(loop) {
      replaced.set(loop, loop.map(function(p) {
        return [centre[0] + (p[0]-centre[0])*factor, centre[1] + (p[1]-centre[1])*factor];
      }));
    }
    layout.centreHoles.forEach(function(hole) { scale(hole.loop); });
    layout.parts.forEach(function(part) {
      if (part === layout.host) return;
      var range = radialRange(part.outer, centre);
      if (range[1] <= layout.opening + .0002) {
        scale(part.outer);
        part.holes.forEach(scale);
      } else if (range[0] < layout.opening - .0002) {
        throw Error('Một chi tiết vượt qua cả vùng tâm và dải viền. Chọn bề rộng khác.');
      }
    });
    return factor;
  }
  function margins(paths,inner,outer,kit,scaleInner){
    var layout=marginLayout(paths,kit),editing=inner!==undefined || outer!==undefined;
    if(!layout){
      if(editing)throw Error('Không nhận diện được viền trong và viền ngoài của họa tiết tròn.');
      return {paths:paths,dimensions:null};
    }
    var currentInner=layout.innerEdge-layout.opening,currentOuter=layout.outside-layout.outerEdge;
    var changeInner=inner!==undefined && Math.abs(inner-currentInner)>.0002;
    var changeOuter=outer!==undefined && Math.abs(outer-currentOuter)>.0002;
    var centreFactor=1;
    if(changeInner || changeOuter){
      var c=layout.c,target=layout.innerEdge-inner,replaced=new Map();
      if(changeInner){
        if(target<=.05)throw Error('Viền trong quá rộng so với phần tâm của họa tiết.');
        if (scaleInner) centreFactor=scaleCentre(layout,target,replaced);
        else layout.centreHoles.forEach(function(h){replaced.set(h.loop,innerLoop(h,layout,target,kit));});
      }
      if(changeOuter){
        var factor=(layout.outerEdge+outer)/layout.outside;
        replaced.set(layout.host.outer,layout.host.outer.map(function(p){return [c[0]+(p[0]-c[0])*factor,c[1]+(p[1]-c[1])*factor];}));
      }
      paths=kit.toPaths(layout.parts.flatMap(function(part){
        return [part.outer].concat(part.holes).map(function(l){return replaced.get(l)||l;});
      }));
      var updated=marginLayout(paths,kit);
      var inputArea=paths.reduce(function(n,p){return n+C.Clipper.Area(p)/(S*S);},0);
      var resultArea=updated && updated.parts.reduce(function(n,p){return n+Math.abs(G.area(p.outer))-p.holes.reduce(function(a,h){return a+Math.abs(G.area(h));},0);},0);
      var holeCount=function(parts){return parts.reduce(function(n,p){return n+p.holes.length;},0);};
      if(!updated || updated.parts.length!==layout.parts.length || updated.host.holes.length!==layout.host.holes.length ||
         holeCount(updated.parts)!==holeCount(layout.parts) ||
         updated.band.length!==layout.band.length || Math.abs(inputArea-resultArea)>.01 ||
         Math.abs((updated.innerEdge-updated.opening)-(changeInner?inner:currentInner))>.015 ||
         Math.abs((updated.outside-updated.outerEdge)-(changeOuter?outer:currentOuter))>.015)
        throw Error('Kích thước viền làm mất lỗ hoặc chạm họa tiết. Chọn bề rộng khác.');
      layout=updated;
    }
    var size=bounds(layout.host.outer),dimensions={inner:layout.innerEdge-layout.opening,outer:layout.outside-layout.outerEdge,
      width:size.x1-size.x0,height:size.y1-size.y0};
    dimensionRays(layout,dimensions);
    return {paths:paths,dimensions:dimensions,centreFactor:centreFactor};
  }
  root.LofiInsertRing={apply:apply,margins:margins,identify:identify,squareBand:squareBand};
})(typeof window==='undefined'?globalThis:window);
