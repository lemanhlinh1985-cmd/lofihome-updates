(function(root){
  'use strict';
  // Display-only camera. Never place zoom/pan in the panel's saved geometry.
  function create(el,hooks){
    var svg=null,bounds=null,zoom=1,offset=[0,0],pan=null,space=false,hand=false,
        swallowClick=false,lastSize='',expanded=false;
    var $=function(id){return document.getElementById(id);};
    function size(){return [Math.max(1,el.clientWidth),Math.max(1,el.clientHeight)];}
    function fitted(){
      if(!bounds)return null;
      var s=size(),w=bounds[2],h=bounds[3],ratio=s[0]/s[1];
      if(w/h<ratio)w=h*ratio;else h=w/ratio;
      return [bounds[0]+bounds[2]/2-w/2,bounds[1]+bounds[3]/2-h/2,w,h];
    }
    function apply(){
      if(!svg || !svg.isConnected || !bounds)return;
      var b=fitted(),cx=b[0]+b[2]/2+offset[0]*bounds[2],cy=b[1]+b[3]/2+offset[1]*bounds[3];
      svg.setAttribute('viewBox',[cx-b[2]/zoom/2,cy-b[3]/zoom/2,b[2]/zoom,b[3]/zoom].join(' '));
      var screen=svg.getScreenCTM();
      if(screen && screen.a>0)svg.querySelectorAll('[data-rim-screen]').forEach(function(mark){
        mark.setAttribute('transform','scale('+(1/screen.a)+')');
      });
      $('panelZoomValue').textContent=Math.round(zoom*100)+'%';
      $('panelZoomOut').disabled=zoom<=.1;
      $('panelZoomIn').disabled=zoom>=20;
    }
    function cancelEdit(){hooks.cancelEdit();}
    function svgPoint(x,y){
      var matrix=svg && svg.getScreenCTM();if(!matrix)return null;
      var p=svg.createSVGPoint();p.x=x;p.y=y;return p.matrixTransform(matrix.inverse());
    }
    function endPan(commit){
      var gesture=pan;if(!gesture)return false;
      pan=null;swallowClick=true;
      if(!commit)offset=gesture.offset.slice();
      el.classList.remove('panning');
      try{if(el.hasPointerCapture(gesture.id))el.releasePointerCapture(gesture.id);}catch(_){}
      apply();return true;
    }
    function zoomBy(factor,x,y){
      if(!svg || !svg.isConnected || !bounds)return;
      endPan(false);cancelEdit();
      var b=fitted(),old=zoom,next=Math.max(.1,Math.min(20,old*factor));
      if(next===old)return;
      var cx=b[0]+b[2]/2+offset[0]*bounds[2],cy=b[1]+b[3]/2+offset[1]*bounds[3],
          anchor=typeof x==='number'?svgPoint(x,y):{x:cx,y:cy};
      if(!anchor)return;
      offset=[(anchor.x+(cx-anchor.x)*old/next-(b[0]+b[2]/2))/bounds[2],
              (anchor.y+(cy-anchor.y)*old/next-(b[1]+b[3]/2))/bounds[3]];
      zoom=next;apply();
    }
    function fit(){endPan(false);cancelEdit();zoom=1;offset=[0,0];apply();}
    function reset(){endPan(false);zoom=1;offset=[0,0];space=false;apply();}
    function setHand(value){hand=value;el.classList.toggle('pan-mode',hand);$('panelPan').setAttribute('aria-pressed',String(hand));}
    function expand(value){
      endPan(false);cancelEdit();expanded=value;
      hooks.design.classList.toggle('panel-expanded',expanded);
      document.body.classList.toggle('panel-preview-expanded',expanded);
      $('panelExpand').textContent=expanded?'Thu gọn':'Phóng rộng';
      $('panelExpand').setAttribute('aria-pressed',String(expanded));
      apply();
    }
    $('panelZoomIn').onclick=function(){zoomBy(1.25);};
    $('panelZoomOut').onclick=function(){zoomBy(1/1.25);};
    $('panelFit').onclick=fit;
    $('panelPan').onclick=function(){endPan(false);cancelEdit();setHand(!hand);};
    $('panelExpand').onclick=function(){expand(!expanded);};
    el.addEventListener('wheel',function(event){
      if(!svg || !svg.isConnected || !event.deltaY)return;
      event.preventDefault();event.stopPropagation();
      var delta=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?el.clientHeight:1);
      zoomBy(Math.exp(-Math.max(-200,Math.min(200,delta))*.002),event.clientX,event.clientY);
    },{passive:false});
    el.addEventListener('pointerdown',function(event){
      swallowClick=false;
      if(!svg || !svg.isConnected || event.isPrimary===false || !(event.button===1 || event.button===0&&(hand||space)))return;
      event.preventDefault();event.stopImmediatePropagation();cancelEdit();
      var matrix=svg.getScreenCTM();if(!matrix)return;
      pan={id:event.pointerId,x:event.clientX,y:event.clientY,offset:offset.slice(),inverse:matrix.inverse(),button:event.button};
      el.classList.add('panning');el.focus({preventScroll:true});
      try{el.setPointerCapture(event.pointerId);}catch(_){}
    },true);
    window.addEventListener('pointermove',function(event){
      if(!pan || event.pointerId!==pan.id)return;
      if(!(event.buttons&(pan.button===1?4:1))){endPan(false);return;}
      event.preventDefault();event.stopImmediatePropagation();
      var m=pan.inverse,dx=event.clientX-pan.x,dy=event.clientY-pan.y;
      offset=[pan.offset[0]-(m.a*dx+m.c*dy)/bounds[2],pan.offset[1]-(m.b*dx+m.d*dy)/bounds[3]];apply();
    },true);
    window.addEventListener('pointerup',function(event){if(pan&&event.pointerId===pan.id){event.preventDefault();event.stopImmediatePropagation();endPan(true);}},true);
    window.addEventListener('pointercancel',function(event){if(pan&&event.pointerId===pan.id)endPan(false);},true);
    el.addEventListener('lostpointercapture',function(event){if(pan&&event.pointerId===pan.id)endPan(false);});
    el.addEventListener('click',function(event){
      if(swallowClick || hand || space){swallowClick=false;event.preventDefault();event.stopImmediatePropagation();}
    },true);
    el.addEventListener('auxclick',function(event){if(event.button===1)event.preventDefault();});
    window.addEventListener('keydown',function(event){
      if(event.key==='Escape'){
        if(endPan(false)){event.preventDefault();event.stopImmediatePropagation();return;}
        if(expanded&&!hooks.editing()){expand(false);event.preventDefault();event.stopImmediatePropagation();return;}
      }
      // A focused motif/region retains Space as its existing selection key.
      if(event.key===' ' && event.target===el){space=true;el.classList.add('space-pan');event.preventDefault();event.stopImmediatePropagation();}
      if(event.target===el && (event.key==='+'||event.key==='='||event.key==='-'||event.key==='0')){
        event.preventDefault();if(event.key==='0')fit();else zoomBy(event.key==='-'?1/1.25:1.25);
      }
    },true);
    window.addEventListener('keyup',function(event){if(event.key===' '){space=false;el.classList.remove('space-pan');}},true);
    window.addEventListener('blur',function(){endPan(false);space=false;el.classList.remove('space-pan');});
    function resize(){
      var key=size().join(':');if(key===lastSize)return;
      lastSize=key;endPan(false);cancelEdit();apply();
    }
    window.addEventListener('resize',resize);
    if(root.ResizeObserver)new ResizeObserver(resize).observe(el);
    return {
      attach:function(next,box){endPan(false);svg=next;bounds=box.slice();lastSize=size().join(':');apply();},
      reset:reset,
      projection:function(){endPan(false);offset=[0,0];},
      leave:function(){endPan(false);space=false;setHand(false);el.classList.remove('space-pan');if(expanded)expand(false);}
    };
  }
  root.LofiPanelViewport={create:create};
})(window);
