/* Measure opposed walls in the physical XY plane. Only add cutter space at
   a measured neck; the original void always remains part of the result. */
(function(root){
  'use strict';
  var G=root.LofiCNCGeometry,C=root.ClipperLib,scale=10000,tool=6;
  function positive(loop){return G.area(loop)>0?loop:loop.slice().reverse();}
  function intPoint(p){return {X:Math.round(p[0]*scale),Y:Math.round(p[1]*scale)};}
  function asMM(path){return path.map(function(p){return [p.X/scale,p.Y/scale];});}
  function disk(center,radius){
    var count=Math.max(32,Math.ceil(Math.PI/Math.acos(1-.006/radius))),r=radius/Math.cos(Math.PI/count);
    return Array.from({length:count},function(_,i){var a=2*Math.PI*i/count;return [center[0]+r*Math.cos(a),center[1]+r*Math.sin(a)];});
  }
  function rectangle(loop,gap){
    if(loop.length!==4)return null;
    var edges=loop.map(function(a,i){var b=loop[(i+1)%4],x=b[0]-a[0],y=b[1]-a[1],len=Math.hypot(x,y);return [x/len,y/len,len];});
    if(!edges.every(function(e,i){var f=edges[(i+1)%4];return Math.abs(e[0]*f[0]+e[1]*f[1])<1e-5;}))return null;
    if(Math.min(edges[0][2],edges[1][2])>=tool-1e-7)return [];
    var long=edges[0][2]>=edges[1][2]?edges[0]:edges[1],width=Math.max(gap+.0004,long[2]);
    var x=(loop[0][0]+loop[2][0])/2,y=(loop[0][1]+loop[2][1])/2;
    var contour=[[-1,-1],[1,-1],[1,1],[-1,1]].map(function(s){
      var u=s[0]*width/2,v=s[1]*(gap+.0004)/2;
      return [x+long[0]*u-long[1]*v,y+long[1]*u+long[0]*v];
    });
    var travel=(gap-Math.min(edges[0][2],edges[1][2]))/2;
    return [{path:contour.map(intPoint),shift:[-long[1]*travel,long[0]*travel]}];
  }
  // Bin short wall segments. A probe stops at the first boundary, including
  // an island, so it cannot measure through another void or across a corner.
  function wallIndex(rings){
    var grid=new Map(),edges=[];
    rings.forEach(function(loop,ring){loop.forEach(function(a,i){
      var b=loop[(i+1)%loop.length],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);
      if(length<.00001)return;
      var e={a:a,b:b,dx:dx,dy:dy,len:length,ring:ring};edges.push(e);
      var steps=Math.ceil(length/tool);
      for(var k=0;k<steps;k++){
        var p=k/steps,q=(k+1)/steps;
        var x0=Math.floor((a[0]+dx*p)/tool),x1=Math.floor((a[0]+dx*q)/tool);
        var y0=Math.floor((a[1]+dy*p)/tool),y1=Math.floor((a[1]+dy*q)/tool);
        for(var x=Math.min(x0,x1);x<=Math.max(x0,x1);x++)for(var y=Math.min(y0,y1);y<=Math.max(y0,y1);y++){
          var key=x+','+y;if(!grid.has(key))grid.set(key,new Set());grid.get(key).add(e);
        }
      }
    });});
    return {edges:edges,grid:grid};
  }
  function centerOfNeck(edge,x,y,index,radius){
    var nx=-edge.dy/edge.len,ny=edge.dx/edge.len,ex=x+nx*tool,ey=y+ny*tool;
    var nearest=tool-1e-7,other=null;
    for(var i=Math.floor(Math.min(x,ex)/tool);i<=Math.floor(Math.max(x,ex)/tool);i++){
      for(var j=Math.floor(Math.min(y,ey)/tool);j<=Math.floor(Math.max(y,ey)/tool);j++){
        var cell=index.grid.get(i+','+j);if(!cell)continue;
        cell.forEach(function(f){
          if(f===edge)return;
          var den=nx*f.dy-ny*f.dx;if(Math.abs(den)<1e-10)return;
          var ax=f.a[0]-x,ay=f.a[1]-y,t=(ax*f.dy-ay*f.dx)/den,u=(ax*ny-ay*nx)/den;
          if(t>.0001 && t<nearest && u>=0 && u<=1){nearest=t;other=f;}
        });
      }
    }
    // Adjacent perpendicular walls at the corner of a wide pocket do not
    // constitute a narrow channel. Opposed, tapering walls do.
    if(!other || edge.dx*other.dx+edge.dy*other.dy>-.60*edge.len*other.len)return null;
    var t=edge.ring?radius+.04:other.ring?nearest-radius-.04:nearest/2;
    return {point:[x+nx*t,y+ny*t],normal:[nx,ny],travel:edge.ring || other.ring?0:Math.max(0,radius-nearest/2)};
  }
  function simplify(line,tolerance){
    var keep=new Uint8Array(line.length),last=line.length-1,stack=[[0,last]];
    keep[0]=keep[last]=1;
    while(stack.length){
      var segment=stack.pop(),i=segment[0],j=segment[1],a=line[i],b=line[j];
      var dx=b[0]-a[0],dy=b[1]-a[1],length=dx*dx+dy*dy,max=tolerance*tolerance,pivot=-1;
      for(var k=i+1;k<j;k++){
        var x=line[k][0]-a[0],y=line[k][1]-a[1],u=length?Math.max(0,Math.min(1,(dx*x+dy*y)/length)):0;
        var error=(x-u*dx)*(x-u*dx)+(y-u*dy)*(y-u*dy);
        if(error>max){pivot=k;max=error;}
      }
      if(pivot!==-1){keep[pivot]=1;stack.push([i,pivot],[pivot,j]);}
    }
    return line.filter(function(_,index){return keep[index];});
  }
  function sweep(line,radius){
    if(line.length===1)return disk(line[0],radius).map(intPoint);
    // Subpixel collinear samples need only the endpoints of the run.
    var path=simplify(line,.012).map(intPoint);
    var off=new C.ClipperOffset(2,.005*scale),out=[];
    off.AddPath(path,C.JoinType.jtRound,C.EndType.etOpenRound);off.Execute(out,(radius+.021)*scale);
    return out[0] || disk(line[0],radius).map(intPoint);
  }
  function sweptPatch(samples,gap,side){
    var points=samples.map(function(s){return [s.point[0]+side*s.travel*s.normal[0],s.point[1]+side*s.travel*s.normal[1]];});
    return sweep(points,gap/2);
  }
  function candidates(hole,islands,gap){
    var loop=positive(hole),rect=!islands.length && rectangle(loop,gap);
    if(rect)return rect;
    // Circular pockets wider than the tool keep every original vertex.
    var box=G.bounds(loop),cx=(box.x0+box.x1)/2,cy=(box.y0+box.y1)/2;
    if(!islands.length && box.x1-box.x0<tool && box.y1-box.y0<tool)return [{path:disk([cx,cy],gap/2).map(intPoint)}];
    if(!islands.length && loop.length>=12){
      var radii=loop.map(function(p){return Math.hypot(p[0]-cx,p[1]-cy);});
      if(Math.max.apply(null,radii)-Math.min.apply(null,radii)<.015){
        var inradius=Math.min.apply(null,loop.map(function(a,i){var b=loop[(i+1)%loop.length],x=b[0]-a[0],y=b[1]-a[1];return Math.abs(x*(cy-a[1])-y*(cx-a[0]))/Math.hypot(x,y);}));
        return 2*inradius>=tool-1e-7?[]:[{path:disk([cx,cy],gap/2).map(intPoint)}];
      }
    }
    var rings=[loop].concat(islands.map(function(p){return positive(p.outer).reverse();}));
    var idx=wallIndex(rings),patches=[],line=[],previous=null;
    function end(){if(line.length)patches.push({path:sweptPatch(line,gap,0),samples:line});line=[];}
    idx.edges.forEach(function(e){
      if(previous && previous.ring!==e.ring)end();previous=e;
      var count=Math.max(1,Math.ceil(e.len/.65));
      for(var k=0;k<count;k++){
        var u=(k+.5)/count,p=centerOfNeck(e,e.a[0]+e.dx*u,e.a[1]+e.dy*u,idx,gap/2);
        if(!p){end();continue;}
        if(line.length){var last=line[line.length-1].point;if(Math.hypot(p.point[0]-last[0],p.point[1]-last[1])>1.6)end();}
        line.push(p);
      }
    });end();return patches;
  }
  function overlaps(a,b){return a.x0<=b.x1+.04 && b.x0<=a.x1+.04 && a.y0<=b.y1+.04 && b.y0<=a.y1+.04;}
  function boxPath(x0,y0,x1,y1){
    return [[{X:x0,Y:y0},{X:x1,Y:y0},{X:x1,Y:y1},{X:x0,Y:y1}]];
  }
  // A detailed insert may probe the same obstructed neck hundreds of times.
  // Compute the immutable keep-out area once per hole. Clip each exact test
  // to small cached tiles instead of rebuilding the whole insert per probe.
  function patchFits(h,bounds,safe,guard,islands,gap,kit){
    var box=boxPath(Math.floor(bounds.x0*scale),Math.floor(bounds.y0*scale),Math.ceil(bounds.x1*scale),Math.ceil(bounds.y1*scale));
    var outside=kit.bool(box,safe,'difference');
    var blocked=kit.bool(kit.bool(outside,guard,'union'),[h.path],'difference');
    blocked=kit.bool(blocked,islands,'union');
    var tiles=new Map(),step=Math.round(Math.max(8,gap*2)*scale);
    return function(path){
      var minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
      path.forEach(function(p){minX=Math.min(minX,p.X);maxX=Math.max(maxX,p.X);minY=Math.min(minY,p.Y);maxY=Math.max(maxY,p.Y);});
      for(var x=Math.floor(minX/step);x<=Math.floor(maxX/step);x++){
        for(var y=Math.floor(minY/step);y<=Math.floor(maxY/step);y++){
          var key=x+','+y,tile=tiles.get(key);
          if(!tile){tile=kit.bool(blocked,boxPath(x*step,y*step,(x+1)*step,(y+1)*step),'intersection');tiles.set(key,tile);}
          if(tile.length && kit.bool([path],tile,'intersection').length)return false;
        }
      }
      return true;
    };
  }
  function apply(paths,gap,kit){
    if(typeof gap!=='number' || !Number.isFinite(gap) || gap<6.1)throw Error('Với dao 6 mm, bề rộng sau nới cần từ 6,1 mm.');
    // Resolve touching subpaths using flat output first. Building a PolyTree
    // directly from raw 024 paths repeatedly reparents contours in Clipper.
    var parts=kit.parts(kit.bool(paths,[],'union')),output=[],changed=0,skipped=0;
    parts.forEach(function(part){
      output.push(positive(part.outer));
      var safe=kit.offset(kit.toPaths([positive(part.outer)]),-.03);
      var holes=part.holes.map(function(h){return {loop:positive(h),bounds:G.bounds(h),path:kit.toPaths([positive(h)])[0]};});
      holes.forEach(function(h){
        var islands=parts.filter(function(p){return p!==part && G.fits(p.outer,h.loop,.00001);});
        var patches=candidates(h.loop,islands,gap);
        if(!patches.length){output.push(h.loop.slice().reverse());return;}
        var protectedIslands=kit.toPaths(islands.map(function(p){return positive(p.outer);})),guard=[];
        var bounds=G.bounds(asMM(h.path)),pad=gap+.1;
        bounds={x0:bounds.x0-pad,x1:bounds.x1+pad,y0:bounds.y0-pad,y1:bounds.y1+pad};
        holes.forEach(function(other){if(other!==h && overlaps(bounds,other.bounds))guard.push(other.path);});
        guard=guard.length?kit.offset(guard,.03):[];
        function valid(patches){
          var added=kit.bool(patches,[h.path],'difference');
          if(protectedIslands.length && kit.bool(patches,protectedIslands,'intersection').length)return null;
          if(!added.length)return h.path;
          if(kit.bool(added,safe,'difference').length || (guard.length && kit.bool(added,guard,'intersection').length))return null;
          var merged=kit.bool([h.path],patches,'union');
          return merged.length===1?merged[0]:null;
        }
        var combined=kit.bool(patches.map(function(p){return p.path;}),[],'union'),accepted=valid(combined),partial=false;
        if(!accepted){
          var allowed=[],fits=patchFits(h,bounds,safe,guard,protectedIslands,gap,kit);
          function tryRun(samples){
            // A cutter may run off centre by at most half the extra width:
            // the original two measured walls remain inside its footprint.
            var sides=samples.some(function(s){return s.travel>0;})?[0,1,-1,.5,-.5]:[0];
            for(var i=0;i<sides.length;i++){
              var patch=sweptPatch(samples,gap,sides[i]);
              if(fits(patch)){allowed.push(patch);return;}
            }
            if(samples.length>3){
              var mid=Math.floor(samples.length/2);
              tryRun(samples.slice(0,mid+1));tryRun(samples.slice(mid));
            }else partial=true;
          }
          patches.forEach(function(p){
            if(fits(p.path))allowed.push(p.path);
            else if(p.samples)tryRun(p.samples);
            else if(p.shift){
              var shifted=[1,-1,.5,-.5].some(function(side){
                var dx=Math.round(side*p.shift[0]*scale),dy=Math.round(side*p.shift[1]*scale);
                var path=p.path.map(function(q){return {X:q.X+dx,Y:q.Y+dy};});
                if(!fits(path))return false;allowed.push(path);return true;
              });
              if(!shifted)partial=true;
            }
            else partial=true;
          });
          if(allowed.length)accepted=valid(kit.bool(allowed,[],'union'));
          if(allowed.length && !accepted)partial=true;
        }
        if(accepted){changed++;h.path=accepted;h.bounds=G.bounds(asMM(accepted));}
        if(partial)skipped++;
        output.push((accepted?asMM(accepted):h.loop).slice().reverse());
      });
    });
    var warnings=skipped?[skipped+' lỗ có đoạn hẹp chưa nới được đủ vì sát viền hoặc khe khác. Đã giữ nét gốc ở các đoạn đó.']:[];
    return {paths:changed?kit.toPaths(output):paths,warnings:warnings,changed:changed};
  }
  root.LofiItemClearance={apply:apply};
})(typeof window==='undefined'?globalThis:window);
