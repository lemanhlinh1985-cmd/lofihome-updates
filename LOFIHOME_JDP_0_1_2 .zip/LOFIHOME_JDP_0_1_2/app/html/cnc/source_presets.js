(function () {
  'use strict';
  // Optional, explicit load of a complete panel accompanying a library sample.
  // Simply choosing the pattern still preserves the user's current panel.
  var entries = window.LofiOriginalCNCCatalog || [], selected = null;
  var title = document.getElementById('panelTitle');
  if (!title || document.getElementById('sourcePanelPreset')) return;
  var button = document.createElement('button');
  button.id = 'sourcePanelPreset'; button.hidden = true;
  button.style.margin = '6px 0';
  title.after(button);
  var fitButton=document.createElement('button');
  fitButton.id='sourceFitPattern';fitButton.hidden=true;
  fitButton.textContent='Giãn hoa văn theo ngang vách';
  fitButton.title='Giảm số lần lặp ngang, giữ kích thước tấm đang chỉnh.';
  button.after(fitButton);
  function show(id) {
    selected = entries.find(function (e) { return e.id === id && e.panel_preset; }) || null;
    button.hidden = !selected;
    fitButton.hidden=!selected || selected.fit_panel_width_on_select!==true;
    if (selected) {
      var p = selected.panel_preset;
      button.textContent = 'Nạp vách mẫu ' + p.width + ' × ' + p.height + ' × ' + p.thickness + ' mm';
      button.title = 'Thay cấu hình đang xem bằng vách mẫu hoàn chỉnh; chưa thay đổi bản vẽ.';
    }
  }
  window.addEventListener('lofi-source-select', function (e) { show(e.detail.item.id); });
  window.addEventListener('lofi-cnc-reply', function (e) {
    if (e.detail.type === 'panel_config') show(e.detail.config.id);
  });
  button.onclick = function () {
    if (!selected) return;
    window.lofiCNCReply({type: 'panel_config', config: JSON.parse(JSON.stringify(selected.panel_preset))});
  };
  fitButton.onclick=function(){if(window.LofiPanelUI)LofiPanelUI.fitLibraryPattern();};
})();
