(function(root){
  'use strict';
  var G=root.LofiCNCGeometry,L=root.LofiLineCleanupGeometry;
  function normalize(value){
    if(!value || typeof value!=='object' || Array.isArray(value) || typeof value.enabled!=='boolean' ||
      typeof value.angle!=='number' || !Number.isFinite(value.angle) || value.angle<0 || value.angle>90 ||
      !Number.isInteger(value.segments) || value.segments<2 || value.segments>12)
      throw Error('Làm mịn: chọn bật/tắt, góc ngưỡng 0–90° và độ mịn nguyên 2–12 đoạn.');
    var result={enabled:value.enabled,angle:value.angle,segments:value.segments};
    // Missing mode is the exact V317.116 algorithm and saved-config format.
    if(value.mode!==undefined){
      if(['curves','round','both','arcs'].indexOf(value.mode)<0 || typeof value.radius!=='number' || !Number.isFinite(value.radius) || value.radius<=0 ||
        typeof value.tolerance!=='number' || !Number.isFinite(value.tolerance) || value.tolerance<.005 || value.tolerance>.5)
        throw Error('Làm mượt / bo góc: chọn chế độ, bán kính R lớn hơn 0 mm và độ chính xác 0,005–0,5 mm.');
      result.mode=value.mode;result.radius=value.radius;result.tolerance=value.tolerance;
    }else if(value.radius!==undefined || value.tolerance!==undefined)throw Error('Chọn chế độ làm mượt / bo góc trước khi đặt bán kính.');
    return result;
  }
  function active(value){return !!value && value.enabled===true && (value.angle>0 || value.mode==='round' || value.mode==='both');}
  function edgeDistance(p,a,b){
    var x=b[0]-a[0],y=b[1]-a[1],d=x*x+y*y,t=d?Math.max(0,Math.min(1,((p[0]-a[0])*x+(p[1]-a[1])*y)/d)):0;
    return Math.hypot(p[0]-a[0]-t*x,p[1]-a[1]-t*y);
  }
  function bounds(loop){
    return loop.reduce(function(b,p){return [Math.min(b[0],p[0]),Math.min(b[1],p[1]),Math.max(b[2],p[0]),Math.max(b[3],p[1])];},[Infinity,Infinity,-Infinity,-Infinity]);
  }
  function touches(p,edges){return edges.some(function(e){return p[0]>=e[2] && p[0]<=e[3] && p[1]>=e[4] && p[1]<=e[5] && edgeDistance(p,e[0],e[1])<.00011;});}
  function advancedLoop(input,s,edges){
    // Collinear subdivision points must not impose artificial radius limits.
    var loop=input.filter(function(p,i){var a=input[(i+input.length-1)%input.length],b=input[(i+1)%input.length],ux=p[0]-a[0],uy=p[1]-a[1],vx=b[0]-p[0],vy=b[1]-p[1];return ux*vx+uy*vy<=0 || Math.abs(ux*vy-uy*vx)>1e-9*Math.hypot(ux,uy)*Math.hypot(vx,vy);});
    var box=bounds(loop),ox=(box[0]+box[2])/2,oy=(box[1]+box[3])/2;
    var plans=loop.map(function(p,i){
      var a=loop[(i+loop.length-1)%loop.length],b=loop[(i+1)%loop.length],la=Math.hypot(p[0]-a[0],p[1]-a[1]),lb=Math.hypot(b[0]-p[0],b[1]-p[1]);
      var u=[(p[0]-a[0])/la,(p[1]-a[1])/la],v=[(b[0]-p[0])/lb,(b[1]-p[1])/lb],delta=Math.atan2(u[0]*v[1]-u[1]*v[0],u[0]*v[0]+u[1]*v[1]),turn=Math.abs(delta),degrees=turn*180/Math.PI;
      var extrema=[0,1].some(function(axis){return [box[axis],box[axis+2]].some(function(k){return Math.abs(p[axis]-k)<.00011;});});
      // Rounding an isolated extreme would change the physical motif bounds.
      // Corners on a straight extreme side may round while keeping that side.
      var isolated=[0,1].some(function(axis){return [box[axis],box[axis+2]].some(function(k){return Math.abs(p[axis]-k)<.00011 && Math.abs(a[axis]-k)>=.00011 && Math.abs(b[axis]-k)>=.00011;});});
      var rounded=(s.mode==='round' || s.mode==='both') && degrees>s.angle+1e-8;
      var curved=(s.mode==='curves' || s.mode==='both') && degrees<=s.angle+1e-8;
      var plan={p:p,u:u,v:v,la:la,lb:lb,delta:delta,turn:turn,trim:0,corner:false};
      if(degrees<.0001 || touches(p,edges) || (rounded?isolated:extrema))return plan;
      if(rounded){plan.trim=s.radius*Math.tan(turn/2);plan.radius=s.radius;plan.corner=true;}
      else if(curved){plan.trim=.45*Math.min(la,lb);}
      return plan;
    });
    // Reserve the exact requested corner radii before fitting shallow curves.
    plans.forEach(function(p,i){if(!p.corner && p.trim){var a=plans[(i+plans.length-1)%plans.length],b=plans[(i+1)%plans.length];p.trim=Math.min(p.trim,.45*Math.max(0,p.la-(a.corner?a.trim:0)),.45*Math.max(0,p.lb-(b.corner?b.trim:0)));}});
    plans.forEach(function(p,i){var next=plans[(i+1)%plans.length];if(p.trim+next.trim>p.lb-.0002 && p.trim+next.trim>0)throw Error('Bán kính bo R '+s.radius+' mm không vừa đoạn nét. Giảm R; bán kính không được tự thu nhỏ.');});
    var result=[];
    function append(p){var q=p.map(function(v){return Math.round(v*10000)/10000;}),last=result[result.length-1];if(!last || Math.hypot(q[0]-last[0],q[1]-last[1])>=.0001)result.push(q);if(result.length>35000)throw Error('Làm mịn quá 35.000 điểm. Giảm độ mịn hoặc tăng độ chính xác mm.');}
    plans.forEach(function(p){
      if(p.trim<.0001){append(p.p);return;}
      var radius=p.corner?p.radius:p.trim/Math.tan(p.turn/2),sign=p.delta>0?1:-1;
      var start=[p.p[0]-p.u[0]*p.trim,p.p[1]-p.u[1]*p.trim],end=[p.p[0]+p.v[0]*p.trim,p.p[1]+p.v[1]*p.trim];
      var center=[start[0]-sign*p.u[1]*radius,start[1]+sign*p.u[0]*radius],a=Math.atan2(start[1]-center[1],start[0]-center[0]);
      // Subdivide by physical chord error as well as the chosen quality.
      var step=2*Math.acos(Math.max(-1,1-Math.min(s.tolerance,radius)/radius));
      var n=Math.max(2,Math.ceil(p.turn*s.segments/(Math.PI/2)),Math.ceil(p.turn/step));
      if(n>256)throw Error('Cung quá nhiều đoạn. Tăng độ chính xác mm hoặc giảm R.');
      append(start);
      for(var j=1;j<n;j++)append([center[0]+radius*Math.cos(a+p.delta*j/n),center[1]+radius*Math.sin(a+p.delta*j/n)]);
      append(end);
    });
    if(result.length>1 && Math.hypot(result[0][0]-result[result.length-1][0],result[0][1]-result[result.length-1][1])<.0001)result.pop();
    L.validate(result.map(function(p){return [p[0]-ox,p[1]-oy];}));
    if(bounds(result).some(function(v,i){return Math.abs(v-box[i])>.00011;}))throw Error('Làm mượt thay đổi kích thước bao hoa văn. Giảm R hoặc góc ngưỡng.');
    return result;
  }
  function smoothLoop(loop,settings,protectedEdges,clear){
    if(settings.mode==='arcs')return L.refineArcs(loop,settings,protectedEdges,clear);
    if(settings.mode)return advancedLoop(loop,settings,protectedEdges);
    var b=bounds(loop),ox=(b[0]+b[2])/2,oy=(b[1]+b[3])/2;
    // Retain physical extrema and every contact with a protected frame. This
    // prevents smoothing from changing motif bounds, joints or frame widths.
    var fixed=loop.map(function(p){
      return Math.abs(p[0]-b[0])<.00011 || Math.abs(p[0]-b[2])<.00011 || Math.abs(p[1]-b[1])<.00011 || Math.abs(p[1]-b[3])<.00011 ||
        protectedEdges.some(function(e){return p[0]>=e[2] && p[0]<=e[3] && p[1]>=e[4] && p[1]<=e[5] && edgeDistance(p,e[0],e[1])<.00011;});
    });
    var local=loop.map(function(p){return [p[0]-ox,p[1]-oy];});
    var smoothed=L.smooth(local,settings.angle,settings.segments,function(_,i){return fixed[i];});
    var result=smoothed.map(function(p){return [Math.round((p[0]+ox)*10000)/10000,Math.round((p[1]+oy)*10000)/10000];});
    L.validate(result.map(function(p){return [p[0]-ox,p[1]-oy];}));
    return result;
  }
  function paths(input,value,protectedPaths,kit){
    if(!active(value) || !input.length)return input;
    var settings=normalize(value),curves=settings.mode==='arcs';
    var original=kit.parts(curves?kit.bool(input,[],'union'):input),edges=[],total=0;
    (protectedPaths||[]).forEach(function(path){path.forEach(function(p,i){var q=path[(i+1)%path.length],a=[p.X/10000,p.Y/10000],b=[q.X/10000,q.Y/10000];edges.push([a,b,Math.min(a[0],b[0])-.00011,Math.max(a[0],b[0])+.00011,Math.min(a[1],b[1])-.00011,Math.max(a[1],b[1])+.00011]);});});
    var clear=curves && L.separationCheck(original.flatMap(function(part){return [part.outer].concat(part.holes);}));
    var loops=[];
    original.forEach(function(part){
      var ls=[part.outer].concat(part.holes).map(function(l){var v=smoothLoop(l,settings,edges,clear);total+=v.length;if(total>35000)throw Error('Làm mịn quá 35.000 điểm. Giảm độ mịn hoặc góc ngưỡng.');return v;});
      if(!curves){var outerIndex=L.edgeIndex(ls[0]);ls.slice(1).forEach(function(h){if(!L.fitsIndexed(L.edgeIndex(h),outerIndex,.00001))throw Error('Làm mịn làm lỗ chạm đường bao. Giảm góc ngưỡng.');});}
      loops=loops.concat(ls);
    });
    var mapped=kit.toPaths(loops),united=kit.bool(mapped,[],'union'),after=kit.parts(united);
    var holes=function(ps){return ps.reduce(function(n,p){return n+p.holes.length;},0);};
    // Do not let boolean cleanup silently merge islands or erase holes.
    if(after.length!==original.length || holes(after)!==holes(original) || Math.abs(kit.area(mapped)-kit.area(united))>.001)
      throw Error('Làm mịn làm các nét chạm hoặc tách nhau. Giảm R hoặc góc ngưỡng.');
    return united;
  }
  root.LofiPanelSmoothing={normalize:normalize,active:active,paths:paths,dxfBulges:function(loops,s,inside){return L.dxfBulges(loops,s,inside);}};
})(typeof window==='undefined'?globalThis:window);
