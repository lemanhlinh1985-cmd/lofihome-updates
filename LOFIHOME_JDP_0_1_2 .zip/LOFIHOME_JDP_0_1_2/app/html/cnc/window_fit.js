(function(root){
  'use strict';
  var timer;
  function fit(force){
    var s=root.screen;
    if(!s || !root.sketchup || typeof root.sketchup.cnc_window_fit!=='function')return;
    var width=s.availWidth,height=s.availHeight,left=s.availLeft,top=s.availTop;
    if(!Number.isFinite(width) || !Number.isFinite(height) || width<320 || height<240)return;
    root.sketchup.cnc_window_fit(JSON.stringify({left:Number.isFinite(left)?left:0,top:Number.isFinite(top)?top:0,width:width,height:height,force:force===true,window_w:root.outerWidth,window_h:root.outerHeight,window_x:root.screenX,window_y:root.screenY}));
  }
  function schedule(){clearTimeout(timer);timer=setTimeout(function(){fit(false);},180);}
  root.LofiCNCWindow={fit:fit};
  function install(){
    var header=document.querySelector('header');
    if(header && !document.getElementById('cncFitWindow')){
      var button=document.createElement('button');button.id='cncFitWindow';button.textContent='Vừa màn hình';button.title='Đưa toàn bộ cửa sổ CNC vào màn hình hiện tại';button.onclick=function(){fit(true);};
      header.insertBefore(button,header.querySelector('button'));
    }
    fit(false);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
  root.addEventListener('resize',schedule);root.addEventListener('focus',schedule);
})(window);
