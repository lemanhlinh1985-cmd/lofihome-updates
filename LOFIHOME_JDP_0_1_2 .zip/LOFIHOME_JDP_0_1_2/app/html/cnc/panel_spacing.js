(function (root) {
  'use strict';
  function bounds(item,source) {
    source=root.LofiCNCPanel.itemDisplaySource(item,source);
    if (!source || !Array.isArray(source.parts)) throw Error('Chờ nạp hình xem trước xong.');
    var angle=item.angle*Math.PI/180,ca=Math.cos(angle),sa=Math.sin(angle),
        b={x0:Infinity,x1:-Infinity,y0:Infinity,y1:-Infinity};
    source.parts.forEach(function (part) {
      part.outer.forEach(function (p) {
        var u=(p[0]/source.width-.5)*item.width*(item.mirror ? -1 : 1),
            v=(p[1]/source.height-.5)*item.height,
            x=item.x+u*ca-v*sa,y=item.y+u*sa+v*ca;
        b.x0=Math.min(b.x0,x);b.x1=Math.max(b.x1,x);
        b.y0=Math.min(b.y0,y);b.y1=Math.max(b.y1,y);
      });
    });
    if (!Number.isFinite(b.x0+b.x1+b.y0+b.y1)) throw Error('Không đo được mép họa tiết.');
    return b;
  }
  function measured(config,indices,assets) {
    if (!Array.isArray(indices) || new Set(indices).size!==indices.length ||
        indices.some(function (i) {return !Number.isInteger(i) || !config.items[i];})) throw Error('Nhóm chọn không hợp lệ.');
    return indices.map(function (index) {return {index:index,box:bounds(config.items[index],assets[config.items[index].id])};});
  }
  function suggestedAxis(config,indices) {
    var xs=indices.map(function (i) {return config.items[i].x;}),ys=indices.map(function (i) {return config.items[i].y;});
    return Math.max.apply(null,xs)-Math.min.apply(null,xs)>Math.max.apply(null,ys)-Math.min.apply(null,ys) ? 'x' : 'y';
  }
  function ordered(config,indices,axis,assets) {
    if (axis!=='x' && axis!=='y') throw Error('Chọn hướng Dọc hoặc Ngang.');
    return measured(config,indices,assets).sort(function (a,b) {
      var delta=(a.box[axis+'0']+a.box[axis+'1'])-(b.box[axis+'0']+b.box[axis+'1']);
      return (axis==='y' ? -delta : delta) || a.index-b.index;
    });
  }
  function current(config,indices,axis,assets) {
    var list=ordered(config,indices,axis,assets),gaps=[];
    for(var i=1;i<list.length;i++) gaps.push(axis==='y' ? list[i-1].box.y0-list[i].box.y1 : list[i].box.x0-list[i-1].box.x1);
    var uniform=gaps.length>0 && gaps.every(function (g) {return Math.abs(g-gaps[0])<.01;});
    return {gaps:gaps,uniform:uniform,value:uniform ? gaps[0] : null};
  }
  function arrange(config,indices,axis,gap,assets) {
    if (indices.length<2) throw Error('Chọn ít nhất 2 hình trong cùng mục để chỉnh khoảng cách.');
    if (typeof gap!=='number' || !Number.isFinite(gap) || gap<0) throw Error('Khoảng cách cần là số không âm, theo mm.');
    var list=ordered(config,indices,axis,assets),lo=Infinity,hi=-Infinity,span=gap*(list.length-1);
    list.forEach(function (entry) {var b=entry.box;lo=Math.min(lo,b[axis+'0']);hi=Math.max(hi,b[axis+'1']);span+=b[axis+'1']-b[axis+'0'];});
    var next=JSON.parse(JSON.stringify(config)),cursor=(lo+hi)/2+(axis==='y' ? span/2 : -span/2);
    list.forEach(function (entry) {
      var b=entry.box,size=b[axis+'1']-b[axis+'0'],item=next.items[entry.index];
      item[axis]+=cursor-b[axis+(axis==='y' ? '1' : '0')];
      cursor+=(axis==='y' ? -1 : 1)*(size+gap);
      var moved=bounds(item,assets[item.id]),inset=root.LofiCNCPanel.supportsFrameSides(config) && item.mode==='inlay' ? root.LofiCNCPanel.frameInsets(config) : {left:0,right:0,top:0,bottom:0};
      if (moved.x0<inset.left-.001 || moved.y0<inset.bottom-.001 || moved.x1>config.width-inset.right+.001 || moved.y1>config.height-inset.top+.001) {
        throw Error('Khoảng cách này làm hình vượt khung. Giảm khoảng cách hoặc di chuyển/căn giữa nhóm trước.');
      }
    });
    return next;
  }
  function assertFits(config,indices,assets) {
    // Ask the production builder for the solid sheet and hollow frame masks;
    // this retains captured curves/holes instead of approximating them here.
    var P=root.LofiCNCPanel,C=root.ClipperLib,G=root.LofiCNCGeometry,S=10000;
    function paths(loops) {return loops.map(function (loop) {return loop.map(function (p) {return {X:Math.round(p[0]*S),Y:Math.round(p[1]*S)};});});}
    function mask(mode) {
      var draft=Object.assign({},config,{mode:mode,items:[]});
      if(config.border && config.border.enabled && (config.border.inner_frame || config.border.center_mode)) draft.border=Object.assign({},config.border,{center_mode:mode});
      var probe=P.build(draft,assets,false),loops=[];
      probe.contours.forEach(function (c) {loops=loops.concat(c.loops);});return paths(loops);
    }
    function difference(subject,clip) {
      if(!subject.length || !clip.length) return subject;
      var engine=new C.Clipper(),out=[];
      engine.AddPaths(subject,C.PolyType.ptSubject,true);engine.AddPaths(clip,C.PolyType.ptClip,true);
      if(!engine.Execute(C.ClipType.ctDifference,out,C.PolyFillType.pftNonZero,C.PolyFillType.pftNonZero)) throw Error('Không kiểm tra được giới hạn khung.');
      return out;
    }
    var boundary=mask('solid'),inner=null;
    indices.forEach(function (index) {
      var item=config.items[index],source=P.itemDisplaySource(item,assets[item.id]),a=item.angle*Math.PI/180,ca=Math.cos(a),sa=Math.sin(a),loops=[];
      source.parts.forEach(function (part) {
        [part.outer].concat(part.holes||[]).forEach(function (loop,j) {
          var moved=loop.map(function (p) {
            var u=(p[0]/source.width-.5)*item.width*(item.mirror ? -1 : 1),v=(p[1]/source.height-.5)*item.height;
            return [item.x+u*ca-v*sa,item.y+u*sa+v*ca];
          });
          if((G.area(moved)>0)!==(j===0)) moved.reverse();loops.push(moved);
        });
      });
      if(item.mode==='inlay' && inner===null) inner=difference(boundary,mask('hollow'));
      var outside=difference(paths(loops),item.mode==='inlay' ? inner : boundary);
      if(Math.abs(outside.reduce(function (sum,path) {return sum+C.Clipper.Area(path);},0))/(S*S)>.001) {
        throw Error('Khoảng cách này làm hình vượt biên hoặc khung đã vẽ. Giảm khoảng cách hoặc di chuyển nhóm trước.');
      }
    });
  }
  root.LofiPanelSpacing={bounds:bounds,suggestedAxis:suggestedAxis,current:current,arrange:arrange,assertFits:assertFits};
})(typeof window==='undefined' ? globalThis : window);
