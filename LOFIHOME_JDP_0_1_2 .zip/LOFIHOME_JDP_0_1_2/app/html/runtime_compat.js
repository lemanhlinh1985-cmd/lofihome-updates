/* DOM and WebDialog bridge for LOFIHOME. Keep ES5 for older embedded browsers. */
(function(){
 'use strict';
 window.LofiCompat={fold:function(value){var text=String(value).toLowerCase();if(String.prototype.normalize)return text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d');var groups=['àáạảãâầấậẩẫăằắặẳẵ','èéẹẻẽêềếệểễ','ìíịỉĩ','òóọỏõôồốộổỗơờớợởỡ','ùúụủũưừứựửữ','ỳýỵỷỹ','đ'],plain='aeiouyd';for(var i=0;i<groups.length;i++)text=text.replace(new RegExp('['+groups[i]+']','g'),plain.charAt(i));return text;}};
 var proto=Element.prototype;
 if(!proto.matches)proto.matches=proto.msMatchesSelector||proto.webkitMatchesSelector;
 if(!proto.closest)proto.closest=function(selector){var node=this;while(node){if(node.matches(selector))return node;node=node.parentElement;}return null;};
 function nodes(args){var fragment=document.createDocumentFragment();for(var i=0;i<args.length;i++)fragment.appendChild(args[i] instanceof Node?args[i]:document.createTextNode(String(args[i])));return fragment;}
 if(!proto.append)proto.append=function(){this.appendChild(nodes(arguments));};
 if(!proto.prepend)proto.prepend=function(){this.insertBefore(nodes(arguments),this.firstChild);};
 if(!proto.before)proto.before=function(){if(this.parentNode)this.parentNode.insertBefore(nodes(arguments),this);};
 if(!proto.after)proto.after=function(){if(this.parentNode)this.parentNode.insertBefore(nodes(arguments),this.nextSibling);};
 if(!proto.replaceChildren)proto.replaceChildren=function(){while(this.firstChild)this.removeChild(this.firstChild);this.appendChild(nodes(arguments));};
 if(!proto.remove)proto.remove=function(){if(this.parentNode)this.parentNode.removeChild(this);};
 if(!NodeList.prototype.forEach)NodeList.prototype.forEach=Array.prototype.forEach;
 if(typeof window.CustomEvent!=='function'){window.CustomEvent=function(type,options){options=options||{};var event=document.createEvent('CustomEvent');event.initCustomEvent(type,!!options.bubbles,!!options.cancelable,options.detail);return event;};}
 var grid=window.CSS&&CSS.supports&&CSS.supports('display','grid');
 if(!grid)document.documentElement.className+=' lofi-old-grid';
 if(!('open' in document.createElement('details'))){
  Object.defineProperty(HTMLElement.prototype,'open',{configurable:true,get:function(){return this.hasAttribute('open');},set:function(value){var before=this.hasAttribute('open');if(value)this.setAttribute('open','');else this.removeAttribute('open');if(before!==!!value)this.dispatchEvent(new CustomEvent('toggle'));}});
  document.addEventListener('click',function(event){var summary=event.target.closest('summary');if(summary&&summary.parentNode.tagName==='DETAILS'&&!event.target.closest('button,input,select'))summary.parentNode.open=!summary.parentNode.open;});
 }
 var numberInput=document.createElement('input');numberInput.setAttribute('type','number');
 if(numberInput.type!=='number'){
  var nativeValidity=HTMLInputElement.prototype.checkValidity;
  HTMLInputElement.prototype.checkValidity=function(){if(this.getAttribute('type')!=='number')return nativeValidity?nativeValidity.call(this):true;var n=Number(this.value),min=this.getAttribute('min'),max=this.getAttribute('max');return this.value!==''&&isFinite(n)&&(min===null||n>=Number(min))&&(max===null||n<=Number(max));};
 }
 // WebDialog sends only a sequence ID in skp: URLs. The full request remains
 // in a hidden textarea so geometry is not truncated by URL limits.
 if(!window.sketchup){
  window.sketchup={};var queue=[],busy=false,sequence=0;
  function pump(){if(busy||!queue.length||!document.body)return;var field=document.getElementById('lofiCompatMessage');if(!field){field=document.createElement('textarea');field.id='lofiCompatMessage';field.style.display='none';document.body.appendChild(field);}busy=true;field.value=JSON.stringify(queue[0]);window.location.href='skp:lofi_compat_call@'+queue[0].id;}
  window.LofiLegacyBridge={done:function(id){if(queue.length&&queue[0].id===String(id)){queue.shift();busy=false;setTimeout(pump,0);}},register:function(names){for(var i=0;i<names.length;i++)(function(name){window.sketchup[name]=function(){queue.push({id:String(++sequence),name:name,args:Array.prototype.slice.call(arguments)});pump();};}(names[i]));}};
  /* LOFI_CALLBACK_NAMES */
  LofiLegacyBridge.register(["cnc_action","dc_library_folder","dc_library_thumbnails","dc_library_browser","clean_selected_ornament","paint_uniform_selection","dc_library_refresh","dc_library_save","dc_library_insert","dc_library_options","load_component_parameters","apply_component_parameters","component_group_to_component","run_profile","cut_4_corners","run_face_profile","add_profile_face","add_exact_lam","import_profile_file","import_external_model","import_external_folder","insert_external_model","load_bundled_tes3_lam","delete_user_profile","clear_user_profiles","transform_finished","rotate_finished_angle","load_finished_lam","update_finished_lam","scale_finished_lam_45","merge_coplanar_surfaces","explode_keep_map","set_map_source","save_map_sample","measure_map_2pt","measure_map_two_points","apply_map_keep_scale","diagnose_map_scale","rotate_map","align_map_to_lam_direction","align_map_miter_45","library_ready","make_external_thumb","rename_external_model","pick_external_model","run_external_edge","change_external_folder"]);
  document.addEventListener('DOMContentLoaded',pump);
 }
}());
