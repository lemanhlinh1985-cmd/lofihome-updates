(function(root){
  'use strict';
  var base=new URL('.',document.currentScript.src).href;
  var files=['cnc/vendor/earcut.min.js','cnc/vendor/clipper.js','cnc/geometry.js','line_cleanup_geometry.js','cnc/panel_border.js','cnc/panel_smoothing.js','cnc/insert_ring.js','cnc/item_clearance.js','cnc/panel_geometry.js','cnc/panel_regions.js'];
  function workerMain(){
    var previous=null;
    self.onmessage=function(event){
      var d=event.data;
      try{
        self.LofiGeometryProgress=function(text){self.postMessage({id:d.id,type:'progress',message:text});};
        self.LofiGeometryProgress('Đang tính hoa văn và kiểm tra các lỗ…');
        var key=JSON.stringify([d.kind,d.config,d.rows,d.angle,d.segments,d.mesh,d.measure]),assets=d.assets||{};
        // One bounded result per dialog. Assets are compared by exact serialized
        // value so replacing a library sample never reuses a stale contour.
        var assetKey=JSON.stringify(assets),result;
        if(previous && previous.key===key && previous.assets===assetKey)result=previous.result;
        else{
          if(d.kind==='cleanup'){
            var count=0;result=d.rows.map(function(row,i){
              self.postMessage({id:d.id,type:'progress',message:'Đang làm mịn đối tượng '+(i+1)+' / '+d.rows.length+'…'});
              var mesh=LofiLineCleanupGeometry.build(row,d.angle,d.segments);count+=mesh.points.length;
              if(count>35000)throw Error('Kết quả quá 35.000 điểm. Giảm độ mịn hoặc chọn ít đối tượng hơn.');
              return mesh;
            });
          }else if(d.kind==='panel'){
            result=LofiCNCPanel.build(d.config,assets,d.mesh===true);
            var config=result.config;
            if(d.measure && config.custom_regions && d.measure.region>=0)config=config.custom_regions[d.measure.region].config;
            var item=d.measure && (config.items||[])[d.measure.index];
            if(item && item.mode!=='cut' && assets[item.id]){
              LofiCNCPanel.rimDimensions(item,assets[item.id]);
              LofiCNCPanel.itemDisplaySource(item,assets[item.id]);
            }
            result._worker_item_cache={};
            Object.keys(assets).forEach(function(id){var entries=LofiCNCPanel.workerItemCache(assets[id]);if(entries.length)result._worker_item_cache[id]=entries;});
          }
          else throw Error('Lệnh tính hình học không hợp lệ.');
          previous={key:key,assets:assetKey,result:result};
        }
        // The native bridge takes JSON. Encode large planar meshes here rather
        // than blocking the dialog again while stringifying tens of thousands
        // of vertices on its UI thread.
        self.postMessage({id:d.id,type:'result',result:d.kind==='cleanup'?{meshes_json:JSON.stringify(result)}:result});
      }catch(e){self.postMessage({id:d.id,type:'error',message:e.message||String(e)});}
    };
  }
  function create(){
    var worker=null,url=null,pending=null,sequence=0,idle=null;
    function dispose(){clearTimeout(idle);idle=null;if(worker)worker.terminate();worker=null;if(url)URL.revokeObjectURL(url);url=null;}
    function cancel(){
      var old=pending;pending=null;dispose();
      if(old){var error=Error('Đã hủy. Hình cũ được giữ nguyên.');error.cancelled=true;old.reject(error);}
    }
    function ensure(){
      if(worker)return;
      if(!root.Worker)throw Error('Giao diện chưa hỗ trợ tính toán nền. Đóng và mở lại LOFIHOME.');
      var imports=files.map(function(f){return new URL(f,base).href;});
      url=URL.createObjectURL(new Blob(['importScripts.apply(null,'+JSON.stringify(imports)+');('+workerMain.toString()+')();'],{type:'text/javascript'}));
      worker=new Worker(url);
      var instance=worker;
      worker.onmessage=function(event){
        if(worker!==instance)return;
        var data=event.data;if(!pending || data.id!==pending.id)return;
        if(data.type==='progress'){if(pending.progress)pending.progress(data.message);return;}
        var job=pending;pending=null;
        if(data.type==='result')job.resolve(data.result);else job.reject(Error(data.message||'Không tính được đường cong.'));
        idle=setTimeout(dispose,30000);
      };
      worker.onerror=function(event){
        if(worker!==instance)return;
        var job=pending;pending=null;dispose();
        if(job)job.reject(Error('Không khởi động được tính toán nền. '+(event.message||'Đóng và mở lại bảng LOFIHOME.')));
      };
    }
    return {cancel:cancel,busy:function(){return !!pending;},run:function(packet,progress){
      if(pending)cancel();else{clearTimeout(idle);idle=null;}
      return new Promise(function(resolve,reject){
        try{ensure();pending={id:++sequence,resolve:resolve,reject:reject,progress:progress};worker.postMessage(Object.assign({},packet,{id:sequence}));}
        catch(e){pending=null;dispose();reject(e);}
      });
    }};
  }
  root.LofiGeometryJobs={create:create};
})(window);
