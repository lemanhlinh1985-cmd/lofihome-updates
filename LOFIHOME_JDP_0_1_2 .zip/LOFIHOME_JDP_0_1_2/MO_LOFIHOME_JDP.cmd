@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0app"
if not exist "LOFIHOME.JDP.exe" (
  echo Khong tim thay app\LOFIHOME.JDP.exe.
  echo Hay giai nen TOAN BO tep ZIP truoc khi mo.
  pause
  exit /b 1
)
start "LOFIHOME JDPaint" "%~dp0app\LOFIHOME.JDP.exe"
exit /b 0
